const CACHE='cong-el-calafate-v1.7.5-work';
const APP_PREFIX='cong-el-calafate-';
const ASSETS=['./','./index.html','./styles.css','./premium-v170.css','./app.js','./manifest.webmanifest','./territory-data.js','./territory-map-2026.png','./congregacion-home.jpg','./icons/icon-192.png','./icons/icon-512.png'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith(APP_PREFIX)&&key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET')return;
  const url=new URL(event.request.url);
  if(url.origin!==self.location.origin)return;
  const refresh=caches.open(CACHE).then(cache=>fetch(event.request).then(response=>{
    if(response&&response.ok)cache.put(event.request,response.clone()).catch(()=>{});
    return response;
  }));
  event.waitUntil(refresh.then(()=>{},()=>{}));
  event.respondWith(caches.open(CACHE).then(cache=>cache.match(event.request)).then(cached=>cached||refresh.catch(()=>caches.match('./index.html'))));
});
