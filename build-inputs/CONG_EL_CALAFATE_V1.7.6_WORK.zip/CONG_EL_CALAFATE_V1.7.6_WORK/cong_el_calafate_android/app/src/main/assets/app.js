const resources = [
  // REUNIONES
  {id:'programa-1', title:'Programa de reuniones · 1', type:'Programa', icon:'▦', desc:'Programa de reuniones publicado por la congregación.', url:'https://drive.google.com/file/d/18I6DUZvIu_rfu_ERO0sYxtXNDSVZc1qh/view?usp=drive_link', section:'reuniones', category:'Reuniones'},
  {id:'programa-2', title:'Programa de reuniones · 2', type:'Programa', icon:'▦', desc:'Programa de reuniones publicado por la congregación.', url:'https://drive.google.com/file/d/18Zr0iwu3Pr3PXTa_B5dy4XIWIptjYW7k/view?usp=drive_link', section:'reuniones', category:'Reuniones'},
  {id:'programa-3', title:'Programa de reuniones · 3', type:'Programa', icon:'▦', desc:'Programa de reuniones publicado por la congregación.', url:'https://drive.google.com/file/d/1JC7zg0G6Xzt4DvqWXJm--3i_vbdSANvC/view?usp=drive_link', section:'reuniones', category:'Reuniones'},
  {id:'programa-4', title:'Programa de reuniones · 4', type:'Programa', icon:'▦', desc:'Programa de reuniones publicado por la congregación.', url:'https://drive.google.com/file/d/1WXWqYUUeHjPo5gIP7A8OJgjy4EH2rcWj/view?usp=drive_link', section:'reuniones', category:'Reuniones'},
  {id:'calendario', title:'Calendario personal', type:'Calendario', icon:'◷', desc:'Calendario compartido de la congregación.', url:'https://calendar.google.com/calendar/u/0?cid=Y29uZ2NhbGFmYXRlQGdtYWlsLmNvbQ', section:'reuniones', category:'Reuniones'},
  {id:'jw', title:'JW.ORG', type:'Sitio oficial', icon:'◎', desc:'Sitio oficial jw.org en español, abierto dentro del visor del app.', url:'https://www.jw.org/es/', section:'reuniones', category:'Reuniones'},

  // TERRITORIOS
  {id:'territorios-personales-info', title:'Cómo usar territorios personales', type:'Información', icon:'⌖', desc:'Instrucciones incorporadas directamente en la aplicación.', details:[
    'Cada publicador se comunica con Marcelo López para recibir un número de territorio asignado.',
    'El estado del territorio debe registrarse como EN CURSO o COMPLETADO.',
    'La congregación trabaja con territorios numerados del 1 al 102.'
  ], section:'territorios', category:'Territorios'},
  {id:'territorios-personales-sheet', title:'Territorios personales · planilla', type:'Google Sheets', icon:'▦', desc:'Planilla compartida para seguimiento de territorios.', sheetId:'1gLPJ8AXiADvFoztBJC0Wf-umVAS4GpN9RF0fGXlE7kk', url:'https://docs.google.com/spreadsheets/d/1gLPJ8AXiADvFoztBJC0Wf-umVAS4GpN9RF0fGXlE7kk/edit?usp=sharing', section:'territorios', category:'Territorios'},
  {id:'registro-territorios', title:'Registro de territorios', type:'Procedimiento', icon:'✎', desc:'Datos que debe registrar el conductor después de una salida designada.', details:[
    'Número de territorio: 1 a 102.',
    'Nombre del conductor.',
    'Fecha de la salida.',
    'Indicar si el territorio fue terminado: Sí / No.',
    'El registro sirve para mantener actualizado el uso de los territorios de la congregación.'
  ], section:'territorios', category:'Territorios'},
  {id:'mapa-calafate-online', title:'Mapa en línea · El Calafate', type:'Google Maps', icon:'⌖', desc:'Mapa online del territorio de El Calafate.', url:'https://goo.gl/maps/X8qpenTJuL6a9W289?g_st=ac', section:'territorios', category:'Mapas'},
  {id:'mapa-chalten-online', title:'Mapa en línea · El Chaltén', type:'Google Maps', icon:'⌖', desc:'Mapa online del territorio de El Chaltén.', url:'https://goo.gl/maps/kQB7SjdyiU1DxAwf7', section:'territorios', category:'Mapas'},
  {id:'mapa-tres-lagos-online', title:'Mapa en línea · Tres Lagos', type:'Google Maps', icon:'⌖', desc:'Mapa online del territorio de Tres Lagos.', url:'https://goo.gl/maps/tUTyzepiLNX8ZNPd8', section:'territorios', category:'Mapas'},
  {id:'carrito-anfiteatro', title:'Carrito · Anfiteatro', type:'Predicación pública', icon:'□', desc:'Planilla de organización del carrito del Anfiteatro.', sheetId:'1SfJQfHRblwVM891QvDnu6fbZewb_l1gx0iYoHIU5YNg', url:'https://docs.google.com/spreadsheets/d/1SfJQfHRblwVM891QvDnu6fbZewb_l1gx0iYoHIU5YNg/edit?usp=sharing', section:'territorios', category:'Carritos'},
  {id:'carrito-anonima', title:'Carrito · La Anónima', type:'Predicación pública', icon:'□', desc:'Planilla de organización del carrito de La Anónima.', sheetId:'1K4BowT0kvU1zlbMw0M9cFA8ToMp9CaTHSqag64x7UWc', url:'https://docs.google.com/spreadsheets/d/1K4BowT0kvU1zlbMw0M9cFA8ToMp9CaTHSqag64x7UWc/edit?usp=sharing', section:'territorios', category:'Carritos'},
  {id:'carrito-terminal', title:'Carrito · Terminal de Ómnibus', type:'Predicación pública', icon:'□', desc:'Para hermanos y hermanas aprobados por el comité de servicio.', sheetId:'1tnW0uSGdfcsO2ldEyyUpLAMO2mI9ttABnzmgSQc2OUE', url:'https://docs.google.com/spreadsheets/d/1tnW0uSGdfcsO2ldEyyUpLAMO2mI9ttABnzmgSQc2OUE/edit?usp=sharing', section:'territorios', category:'Carritos'},

  // FORMULARIOS / ORGANIZACIÓN
  {id:'form-datos', title:'Datos de las familias', type:'Google Forms', icon:'✎', desc:'Formulario solicitado a las familias de la congregación.', url:'https://forms.gle/CKtLekHu5LMaBDEFA', category:'Formularios'},
  {id:'plan-evacuacion', title:'Plan de evacuación', type:'Seguridad', icon:'↗', desc:'Plan de evacuación e información del Salón del Reino incorporados como galería.', gallery:[
    'https://sites.google.com/sitesv-images-rt/AMxu72vYLxDYFfkf6pOTgV9RJbtOtnrrYgI40OpCyKOYC6J_gdKTGKCNyr_HQj7_Sh1QV1QXPfTcHw7B-6-7ANsBRXnbvE3N61oGPpbQyUdRBODlTXN3QeYkfzL15yrNZcMZLpzunNNd3KPU6Lp7gihojsS4WnJiO6S-QVHvDRacEOqfpSbYzCUjjWfxpga8phVyDTIYzvXccy__mb7JO_CV8yP3ZUb2nijumvdfSdc-5Pg=w1280',
    'https://sites.google.com/sitesv-images-rt/AMxu72syVK-agu-msLtx04pjnakPs0WeoWiko_WUO727DfwMhUOeDjqraIJsPbr_62hquc2pSjMueMLIJrEe7q6qprtZKLvb1C0JIp2IoCf6cv_qu8gwDw8Rxoc7DS1dtZZ5aqbOxDaMQhnKYzdXz-g2VffYZrkrxLvoqf7GwLHmGgI_wKqNw3csAX2nHn3-PDjCpyO8QwrNwFq0Ho9JDHeFw4LgJf2nYblnN8KoiFT71mI=w1280',
    'https://sites.google.com/sitesv-images-rt/AMxu72vaNmyLBy-NjSJcSHSATgd8hqQ-GYeFwafU1DkPX_3yt_aWrCKDOMlUring2gRjnG5uNcmB6WRIJRSci0ksoDaszqPbs5NLG7CXKGHEIXTVIEcWJil1mNCC08dY-KnaVGGgayCrjeIsbDvSW7_QXxXMmkQ8dAWLuySOisv46XGMQQE0e4ziLtFyXyKhKmwofEaNBfHtEIPsxMeUULd_dEb9zxvS06goznU0AChK=w1280'
  ], category:'Organización'},
  {id:'organigrama', title:'Cartas y organigrama', type:'Organización', icon:'▤', desc:'Organigrama, grupos, visitas, anuncios y material gráfico de la congregación.', gallery:[
    'https://sites.google.com/sitesv-images-rt/AMxu72sTdqZH57FxIBr_34jYLCIijXQYWrMWq_cVwnnTTBnlQVQRqvjGpULv1ZVELPGzR86mWdb6nfLJnAPwXiOVgfdeyz7-PGMDCrM_oJYUCYyADF3c8XdSTifaqNq0PebQ0K4RzKHTGHqDwYT-DIXDDI-wKVBh7sv9qgf716zr-gy3CY-3B8I8PZFNKSpNq5o=w1280',
    'https://sites.google.com/sitesv-images-rt/AMxu72stSo4_CZpfxpunMZ3Inui9aM6Hzfl3Ov5tst9qkNciCK6ReAh425AJmyPj_gg0sJs-m9njZ8gPH2XkWM9Vezc56ha_yFFBTRKN1zPKTZHW1ezWIDswlyTXQtc9vYcwTuAdTONOmFbW2ZnOZ94Q2LopxQBuiQLWMVwCucqC7W5Em3T8wibVwnXraFqhAns=w1280',
    'https://sites.google.com/sitesv-images-rt/AMxu72vsOSK4zenF_h_Y5C-w_lDtMIioqT5L0loqFpauR5GRUdZMW644jeXJrREFuxsuj_EHx1Xr-uOnj4sy2bfNKOwJqi2HtHHIwnJpothGyeFyElSphRAn9c-LE-1Gmpqyoggidw2FTZ8Mh9Ru_T3U4aDRrJYmxdJqBjLCSacJ53TFpujC5nAjmDYeWI4_GficyisSj-TDIOEEADlJRuTbXReCUj8x1u1175Uw7IUi=w1280',
    'https://sites.google.com/sitesv-images-rt/AMxu72sDuZ9f3ymWyMZGcZjo_7Pl5nF6Ki1c1vMNWWUl8g1Q-CWSt9hJi0OguU6y3QVfAdXxLZJIdK6id5BvHquIwb0xI0Slqqp1l8JVcz8NJMZmgFz7HbT24g9yhXr_91uidqvQMtUt2RdOOnC4R8qk58sNHY-OqsXPvcfx8iXoh43r59a6NNYDAcJsHi-_dxFzenNG6kCsae3itpAjkNKSrK4O6CM0IRoPuPpOV4b-G8c=w1280',
    'https://sites.google.com/sitesv-images-rt/AMxu72u449-DC9lZ3R3pYBLociQ3yFyFS8qAzkSAB-UeWvvP6SAU_qD8sWY3DkXsWcTOB__dCmLcw0RCBGOnlKcfNquvjPqpirJJxA4q9XSxZk-MkEeWLOZ7CDPlZWo7d9t3XbhIHADO2xJxtdz4CYZ6D6IYfQpZOVfT3K6TV6JiWKMqwRb9PA5WUJlO1uuaSBLeIbuk1EGX2zsUiFnt1DFnhHaQASjovzM8YTJtYE3QgSY=w1280',
    'https://sites.google.com/sitesv-images-rt/AMxu72so1mL2GCpU4mjVRWEXRhprxc4MeQtc1nEWNc5x9LVcWaYsjVNcfoLRlix7U0o7bw5jXlqCs2zGnYLo_m7sJ_xLQv3ncpvUTMs1GoDOo5Ueil6saGLDxJvUB1IHo3sYOYX7GvNRRtnAL6_H3xseHl1XrNCJWBc2PBND08-G_43r4i2Hv3VHEJwTyjG_v9OxRCm29vtvgLlbQcMsx4fvHYlzGDVlTYKQ0H9sI996i6A=w1280',
    'https://sites.google.com/sitesv-images-rt/AMxu72s4DBt8sGwLf93MqONhTbKlBUTvFthzvfR4Tv7UfoeGd269g4sVUbU91fQ77e-1t5eJTVwCTXUC1wwxDA7d9VIs8jPZc-8jkReyzsaoWUqB_6YlFtZfViX8vsRO7-hT78L_MAwbO16T9HG9RJXczPYPHOoMrSejFqvaYwDi6uoRrVmk5Q9hBwLavhVtHr1hrZkWl4PkuPxx_ML11HyWDh5uOZo9kplqL90SOEzG31c=w1280',
    'https://sites.google.com/sitesv-images-rt/AMxu72vzYooJRnjpDRePKHnr74Lb3qwdo9BybwOgMG_tHAfx50E1ee4HlHOIgtzp2LUxck_m0rbk9-AcEqZDaN7_oU7w8tvNARE4-rH114qXNcF5SB8fJwlOzlyV1zIiwvxPCXUbh-SboJzbYE5QVJf7a3UGUcmgyiPuVdyjFBhkzxtXh7rcGHDDigwxPOHD6O4hV8j7jsrY6nB1JyJ3G8j9RgUGmmEiaPXPUzL0DZVrap8=w1280',
    'https://sites.google.com/sitesv-images-rt/AMxu72vrb5FFb5sUuKApHDSrdVG94UoNpcMn9dezW___MPoNdgOansVp6EbwpoRsuMoVAZBbHCS1aMZ7ShRS1xzWwrom-vkSZWJ5coQY2IN55muWwuyQ2BIFHPsGlYsYoJiuPRsYsXACoUvhUSJpRyLBm6LreANmiJAMnBcT6DJLmmeivqZHW9gO7-eCCZ6YRnBGEdV_6rMDBLQZT1E4C9VKXQu3gXdYALMHHbnNHk5f8Ls=w1280',
    'https://sites.google.com/sitesv-images-rt/AMxu72sVu5RJOXLq3Hek3SMD1DYJMPilgEntAZmySHrVEWcMmPh39xbls92-GdaiD0V5HNT-Ys3NGsTQHDw2Z8zkJJ9kiOo4VfYud3RpKxAjLEl5jNdStZ5CsOgqkfr97BO61dvvlSNiYvwWIWswHuNLrkh_LRk28JA1Os0g6u4cPo_FcPg-3vgyaG-d5i8L=w1280',
    'https://sites.google.com/sitesv-images-rt/AMxu72sYxwmUi9pITrpAlSHzVHRYpDajiJ1565LP5Getx161SylWnAQfWvS9KT8ksCERlibPxe8oXn_corIBxTO65mhcyypTG1Wydq0ht_HoLA5pURArZSUTemGMOblVlC-GkC5FRsx2-dn7pqPEvqXXn79w1RSsOzTcZf6Ip9GndgO0sjDZypjF9poGEDrK=w1280',
    'https://sites.google.com/sitesv-images-rt/AMxu72t_32bpUz9M-8rYycEwrEUwYpCt6LD6VHEEaeel1IB7-JhAHDH4F9AUIFvR6tT2wW1L9SfMSeqUcszQH-ogwnf7502nKgJjr_3FyBmBhS4kNXHMycPZPd4S6EhjqLKCJuip9A-8Nz7c39TocprhSipYM8bI91anWRatEILXs4ycp0RMXuT5F_dooEcssII=w1280',
    'https://sites.google.com/sitesv-images-rt/AMxu72v_-BOrKInxX7tXIHM1y8HjzJHX77RRhQNY3Wh5lVebcspeHF9wNQhZorI5-U_5io3LhZu-EGeB-FfhOCGl3JGGracivOkcT5ggImhOXkCqb0BNebPx6P3iF0XusduJjTmdbIT-ZBOAEXzm0ytahKhtRwoUAHGo2m7CFXH0P3bhwi6JmOSVc-dS-iAaUg25hJW3QOsXXi9XjXrK1rSqqnMVJTENH4THTTgt0mojydc=w1280',
    'https://sites.google.com/sitesv-images-rt/AMxu72vHNA-ktRmKbusBlEGwlhFD-H3akPoM15xrw_4y42O7XW322Ww3enhPHo_mTsOb-HjMIIqKjJZWFv3aAj9xUZutqYoezn1b5M7_2Jjqb4yON4KjDvcRZ3A0pQK4Mx29RVof9BPQwTGRm2wraf24-rcFVD3FaqHNGXe1X0G8F3sd9v21RX3SxpnO_tK3JQFuo3TPQ19R8mTHzh8l6BlgLvgblq9N-2Ih1TGz2fsE=w1280',
    'https://sites.google.com/sitesv-images-rt/AMxu72ukLrDsfEKYF7i90cbt0XSLZ4n8cjn0gbDiLS5ZrLZiItpL4TLW3QGBXaEeuvgbpOUaUqLCNkIleZFMqtE9FBr6Ymz0vCe1wr95JYmHWQX7fI6dirCLWVK8yIZqlskEqwzQVc0thyiLU3PeVZ_A4Tv5ayPTJnapRpcdFsk9rhv6yuqeE88wX-yTGSrIdbrMMa45jwwFdAX1zVgkaT0t2ozKzZzK02wPVMUf-bYckRQ=w1280',
    'https://sites.google.com/sitesv-images-rt/AMxu72uiZ0KrhdpnHOVeo9cuf7TuEACqZhP7mi5NSCSHjIlA7OTC1cm4GMP7kLj4jA6oKJ_tVzAkPgvLFQZX-jZDtSv3lvHxqRAPpicKruJdw5FpN6HDs1dalsq3aYdLaYWceEhZb2pP7hmvhzYdzrA-8nYcIckN6YiJecv9ildD3M_8_Yompr26jzybkOdMy-E6AL5nAEOrmpxz0ghjWeDjyHgLZb4avW2GIgMEGBg3=w1280',
    'https://sites.google.com/sitesv-images-rt/AMxu72v_idCD4L1dderNppOWNT8BxzQfxYuhYSB_6ks8MzOWdA9czDIBmWLOlHn3abkFhjtxzYIie2xy1MMSEULC_hnw1Zvdvkfm25S6-JQL3DijiJPHK1ecmo31W12Y5KD7TA3tNLUdfbm89U37z7Xh1Lm-QTqFYuM6Sw8AVGcdZe5Bykh0YB0pzmro4ml2qM4=w1280',
    'https://sites.google.com/sitesv-images-rt/AMxu72uzB1uUND8MurBJyLL2MSxp94bySknhWlQYBzunhIM2iC9JzzRQqv72OGKmVas-7rqa41ZZxcVqpjGT1q2aSN81akhOoBG0wAsp1lodsywgRX0J1Z0XXuZkNlazxxffujiKUP9LFaXezwe7spZmulvP50FJZhedqhX9SfZcNMiLeRiALErmfuzarxPS=w16383'
  ], category:'Organización'},

  // MANTENIMIENTO
  {id:'mantenimiento-info', title:'Mantenimiento del Salón', type:'Calendario', icon:'◇', desc:'Resumen del calendario de mantenimiento incorporado en el app.', details:[
    'Meses publicados: octubre, noviembre y diciembre de 2026.',
    'Proyectos: Depósito, Jardines, Sistema de Seguridad y Dispensadores.',
    'Cada mes incluye una sección de proyecto a realizar e información adicional.'
  ], category:'Mantenimiento'},
  {id:'mwb', title:'mwb16.01-S · mantenimiento', type:'Documento', icon:'▤', desc:'Documento de referencia para mantenimiento.', url:'https://drive.google.com/file/d/1KsTDrCyHKozFgE5OmIkSzC4nTZuNkW_M/view?usp=sharing', category:'Mantenimiento'},
  {id:'mwb-jw', title:'Lugares de reunión · JW.ORG', type:'Referencia', icon:'◎', desc:'Referencia oficial relacionada con lugares de reunión.', url:'https://www.jw.org/es/biblioteca/guia-actividades-reunion-testigos-jehova/guia-enero-2016/programa-reunion-4-10-enero/lugares-de-reunion/', category:'Mantenimiento'},
  {id:'limpieza-profunda', title:'Limpieza profunda semanal', type:'Instrucción', icon:'◇', desc:'Instrucción para la limpieza profunda semanal.', url:'https://drive.google.com/file/d/1yUoBhuzIqvzpnrwVKoENpE58BlbkVi-J/view?usp=drivesdk', category:'Mantenimiento'},
  {id:'limpieza-reunion', title:'Limpieza luego de cada reunión', type:'Instrucción', icon:'◇', desc:'Instrucción para la limpieza luego de cada reunión.', url:'https://drive.google.com/file/d/1B1K82gZLuuH1pEjasKL4akvD561yWVHi/view?usp=drivesdk', category:'Mantenimiento'},

  // CONTABILIDAD
  {id:'contabilidad-info', title:'Contabilidad · informe visible', type:'Información', icon:'▦', desc:'Resumen del informe mensual publicado.', details:[
    'INFORME MENSUAL DE LAS CUENTAS DE LA CONGREGACIÓN (S-30).',
    'Local: El Calafate, Santa Cruz (12310).',
    'Mes visible en el portal auditado: agosto de 2026.',
    'Donaciones para la congregación (cajas): $491.500,00.',
    'Donaciones para la congregación (transferencias electrónicas): $1.655.600,00.',
    'Fondos al comienzo del mes: $0,00.'
  ], category:'Contabilidad'},

  // TELEFÓNICA Y CARTAS
  {id:'telefonica', title:'Predicación telefónica', type:'Google Sheets', icon:'☎', desc:'Planilla principal de predicación telefónica.', sheetId:'1SjYd-8pDMTshIQATZaYapMhhavhrNJ5tj7PKt7bu0NA', url:'https://docs.google.com/spreadsheets/d/1SjYd-8pDMTshIQATZaYapMhhavhrNJ5tj7PKt7bu0NA/edit?usp=sharing', category:'Telefónica y cartas'},
  {id:'comercios', title:'Comercios', type:'Google Sheets', icon:'▦', desc:'Territorios para negocios en El Calafate.', sheetId:'1AamlWyb8Kuh1Ou4ib0cxD-E740x-v8_VjMCcwEOmf0c', url:'https://docs.google.com/spreadsheets/d/1AamlWyb8Kuh1Ou4ib0cxD-E740x-v8_VjMCcwEOmf0c/edit?usp=sharing', category:'Telefónica y cartas'},
  {id:'cartas-tres-lagos', title:'Cartas · Tres Lagos', type:'Google Sheets', icon:'✉', desc:'Correos electrónicos y registro para predicación por cartas.', sheetId:'1F9U5PgnoCBr50g_3rRDPbQExzMdNKhepFIjz67XaoNc', url:'https://docs.google.com/spreadsheets/d/1F9U5PgnoCBr50g_3rRDPbQExzMdNKhepFIjz67XaoNc/edit?usp=sharing', category:'Telefónica y cartas'},
  {id:'cartas-chalten', title:'Cartas · El Chaltén', type:'Google Sheets', icon:'✉', desc:'Correos electrónicos y registro para predicación por cartas.', sheetId:'1MjKoX4IHKKarkk0wl7IHCITY9mDIzqvQTZhO_DE6rlk', url:'https://docs.google.com/spreadsheets/d/1MjKoX4IHKKarkk0wl7IHCITY9mDIzqvQTZhO_DE6rlk/edit?usp=sharing', category:'Telefónica y cartas'},
  {id:'cartas-calafate', title:'Cartas · El Calafate', type:'Google Sheets', icon:'✉', desc:'Correos electrónicos y registro para predicación por cartas.', sheetId:'1BD346D9zBPeKGC4cyV0dkzv3e6BBwYaVYN_Hs3Xe9KQ', url:'https://docs.google.com/spreadsheets/d/1BD346D9zBPeKGC4cyV0dkzv3e6BBwYaVYN_Hs3Xe9KQ/edit?usp=sharing', category:'Telefónica y cartas'},

  // SOLICITUDES E INVITACIONES
  {id:'invitacion', title:'Invitación para reuniones', type:'Documento', icon:'▤', desc:'Invitación para reuniones.', url:'https://drive.google.com/file/d/1Cy2ZDuSlUnJo1MovftG-t2kUHjg0-219/view?usp=drivesdk', category:'Solicitudes'},
  {id:'mapa-calafate', title:'Mapa del territorio · El Calafate', type:'Mapa', icon:'⌖', desc:'Mapa del territorio de El Calafate.', url:'https://drive.google.com/file/d/1Z42IZqr9QxwFxgW9h-KliD3JI1swI2K7/view', category:'Solicitudes'},
  {id:'precursor', title:'Solicitud · Precursor auxiliar', type:'Formulario', icon:'✎', desc:'Solicitud para precursor auxiliar.', url:'https://drive.google.com/file/d/1hDcwuPVg_p4-F0c3Q67LPCHd1boR5BGV/view?usp=drivesdk', category:'Solicitudes'},
  {id:'mapa-chalten', title:'Mapa del territorio · El Chaltén', type:'Mapa', icon:'⌖', desc:'Mapa del territorio de El Chaltén.', url:'https://drive.google.com/file/d/1XY3k2D7H8m4NNMncHquTTtFsTH1C3kEw/view', category:'Solicitudes'},
  {id:'informe', title:'Informe de predicación', type:'Formulario', icon:'✎', desc:'Formulario de informe de predicación.', url:'https://drive.google.com/file/d/1hsR4R7Urj2vTZRpe7RKS0sF0HW6KptPz/view?usp=drivesdk', category:'Solicitudes'},
  {id:'identidad-menor', title:'Tarjeta de identidad · menor de edad', type:'Documento', icon:'▤', desc:'Tarjeta de identidad para menores de edad.', url:'https://drive.google.com/file/d/1-3t4XOZvsoFH9ln2JLFiD91n74cziwHu/view?usp=drivesdk', category:'Solicitudes'}
];

const moreResources = [
  {id:'mantenimiento-info', title:'Mantenimiento del Salón', type:'Dentro del app', icon:'◇', desc:'Calendario y proyectos incorporados.'},
  {id:'organigrama', title:'Cartas y organigrama', type:'Dentro del app', icon:'▤', desc:'Galería completa incorporada.'},
  {id:'contabilidad-info', title:'Contabilidad', type:'Dentro del app', icon:'▦', desc:'Resumen del informe mensual publicado.'},
  {id:'telefonica', title:'Telefónica y cartas', type:'Dentro del app', icon:'☎', desc:'Planillas de trabajo organizadas.'},
  {id:'plan-evacuacion', title:'Plan de evacuación', type:'Dentro del app', icon:'↗', desc:'Plano e información de seguridad.'},
  {id:'jw', title:'JW.ORG', type:'Sitio oficial', icon:'◎', desc:'Se abre dentro del visor del app.'}
];

const quick = [
  {title:'Reuniones', subtitle:'4 programas y calendario', icon:'▦', target:'reuniones'},
  {title:'Territorios', subtitle:'Mapas, carritos y registro', icon:'⌖', target:'territorios'},
  {title:'Solicitudes', subtitle:'Documentos y formularios', icon:'✎', target:'recursos', filter:'Solicitudes'},
  {title:'Mantenimiento', subtitle:'Calendario e instrucciones', icon:'◇', target:'recursos', filter:'Mantenimiento'}
];

let deferredPrompt;
let activeFilter = 'Todos';
let currentResource = null;
const favorites = new Set(JSON.parse(localStorage.getItem('cec_favorites') || '[]'));

const TERRITORY_STORAGE_KEY = 'cec_territory_control_v1';
const STREET_CATALOG_KEY = 'cec_el_calafate_street_catalog_v1';
let territoryState = loadTerritoryState();
let streetCatalog = JSON.parse(localStorage.getItem(STREET_CATALOG_KEY) || '[]');
let activeSheetResource = null;
let activeSheetRows = [];
let activeSheetFilteredRows = [];

const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];

function escapeHTML(value=''){
  return String(value).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
}

function resourceCard(r){
  const fav = favorites.has(r.id) ? '★' : '›';
  return `<button class="resource-card" data-resource="${escapeHTML(r.id)}">
    <span class="resource-icon">${escapeHTML(r.icon || '▤')}</span>
    <span><strong>${escapeHTML(r.title)}</strong><small>${escapeHTML(r.type)} · ${escapeHTML(r.desc)}</small></span>
    <span class="resource-arrow">${fav}</span>
  </button>`;
}

function render(){
  $('#quickGrid').innerHTML = quick.map(q => `<button class="quick-card" data-quick-target="${q.target}" ${q.filter?`data-quick-filter="${q.filter}"`:''}>
      <span class="quick-card-icon">${q.icon}</span>
      <span><strong>${q.title}</strong><small>${q.subtitle}</small></span>
    </button>`).join('');

  $('#meetingResources').innerHTML = resources.filter(r=>r.section==='reuniones').map(resourceCard).join('');
  $('#territoryResources').innerHTML = resources.filter(r=>r.section==='territorios').map(resourceCard).join('');
  $('#moreResources').innerHTML = moreResources.map(resourceCard).join('');

  const categories = ['Todos','Favoritos',...new Set(resources.filter(r=>r.category).map(r=>r.category))];
  $('#resourceFilters').innerHTML = categories.map(c=>`<button class="filter-btn ${c===activeFilter?'active':''}" data-filter="${escapeHTML(c)}">${escapeHTML(c)}</button>`).join('');
  renderResourceSearch();
}

function renderResourceSearch(){
  const query = ($('#resourceSearch')?.value || '').trim().toLowerCase();
  let list = resources.filter(r=>r.category);
  if(activeFilter === 'Favoritos') list = list.filter(r=>favorites.has(r.id));
  else if(activeFilter !== 'Todos') list = list.filter(r=>r.category===activeFilter);
  if(query) list = list.filter(r => `${r.title} ${r.type} ${r.desc} ${r.category||''} ${(r.details||[]).join(' ')}`.toLowerCase().includes(query));
  $('#allResources').innerHTML = list.map(resourceCard).join('');
  $('#emptySearch').hidden = list.length !== 0;
}

function navigate(target){
  $$('.view').forEach(v=>v.classList.toggle('active', v.dataset.view===target));
  $$('.nav-item').forEach(n=>n.classList.toggle('active', n.dataset.target===target));
  window.scrollTo({top:0,behavior:'smooth'});
}

function findResource(id){
  return resources.find(r=>r.id===id) || moreResources.map(m=>resources.find(r=>r.id===m.id) || m).find(r=>r.id===id);
}

function openResource(r){
  if(r.sheetId){ openSheet(r); return; }
  currentResource = r;
  $('#dialogIcon').textContent = r.icon || '▤';
  $('#dialogType').textContent = r.type || 'Recurso';
  $('#dialogTitle').textContent = r.title;
  $('#dialogDescription').textContent = r.desc || '';

  const details = $('#dialogDetails');
  if(r.details?.length){
    details.hidden = false;
    details.innerHTML = r.details.map(d=>`<div class="detail-line">${escapeHTML(d)}</div>`).join('');
  } else {
    details.hidden = true;
    details.innerHTML = '';
  }

  const gallery = $('#dialogGallery');
  if(r.gallery?.length){
    gallery.hidden = false;
    gallery.innerHTML = r.gallery.map((src,i)=>`<figure><img loading="lazy" src="${escapeHTML(src)}" alt="${escapeHTML(r.title)} · imagen ${i+1}"><figcaption>${escapeHTML(r.title)} · ${i+1}/${r.gallery.length}</figcaption></figure>`).join('');
  } else {
    gallery.hidden = true;
    gallery.innerHTML = '';
  }

  const open = $('#dialogOpen');
  if(r.url){
    open.hidden = false;
    open.href = r.url;
    open.textContent = 'Abrir dentro del app';
  } else {
    open.hidden = true;
    open.removeAttribute('href');
  }

  updateFavoriteButton();
  const dialog = $('#resourceDialog');
  if(typeof dialog.showModal === 'function') dialog.showModal();
}

function updateFavoriteButton(){
  if(!currentResource) return;
  const on = favorites.has(currentResource.id);
  $('#dialogFavorite').textContent = on ? '★ Quitar de favoritos' : '☆ Guardar en favoritos';
}

function toggleFavorite(){
  if(!currentResource) return;
  if(favorites.has(currentResource.id)) favorites.delete(currentResource.id);
  else favorites.add(currentResource.id);
  localStorage.setItem('cec_favorites', JSON.stringify([...favorites]));
  updateFavoriteButton();
  render();
}


function loadTerritoryState(){
  try{
    const raw = JSON.parse(localStorage.getItem(TERRITORY_STORAGE_KEY) || '{}');
    return raw && typeof raw === 'object' ? raw : {};
  }catch(_){ return {}; }
}

function saveTerritoryState(){
  localStorage.setItem(TERRITORY_STORAGE_KEY, JSON.stringify(territoryState));
}

function territoryNumber(){
  return String($('#territorySelect')?.value || '1');
}

function ensureTerritory(number=territoryNumber()){
  if(!territoryState[number]) territoryState[number] = {driver:'', date:'', notes:'', streets:[], updatedAt:''};
  if(!Array.isArray(territoryState[number].streets)) territoryState[number].streets = [];
  return territoryState[number];
}

function touchTerritory(t){
  t.updatedAt = new Date().toISOString();
  saveTerritoryState();
}

function renderTerritorySelector(){
  const select = $('#territorySelect');
  if(!select) return;
  const current = select.value || '1';
  select.innerHTML = Array.from({length:102},(_,i)=>`<option value="${i+1}">Territorio ${i+1}</option>`).join('');
  select.value = current;
}

function loadTerritoryIntoForm(){
  const t = ensureTerritory();
  $('#territoryDriver').value = t.driver || '';
  $('#territoryDate').value = t.date || '';
  $('#territoryNotes').value = t.notes || '';
  $('#territoryStreetSearch').value = '';
  renderTerritoryStreetList();
}

function territoryProgress(t=ensureTerritory()){
  const total = t.streets.length;
  const done = t.streets.filter(s=>s.done).length;
  const pct = total ? Math.round(done*100/total) : 0;
  return {total,done,pct};
}
function renderTerritoryStreetList(){
  const t = ensureTerritory();
  const query = ($('#territoryStreetSearch')?.value || '').trim().toLowerCase();
  const list = t.streets.map((street,index)=>({...street,index})).filter(s=>!query || s.name.toLowerCase().includes(query));
  const root = $('#territoryStreetList');
  if(root){
    root.innerHTML = list.map(s=>`<div class="street-row ${s.done?'done':''}">
      <label class="street-check"><input type="checkbox" data-street-check="${s.index}" ${s.done?'checked':''}><span class="street-check-ui"></span><span class="street-name">${escapeHTML(s.name)}</span></label>
      <button class="street-remove" type="button" data-street-remove="${s.index}" aria-label="Eliminar ${escapeHTML(s.name)}">×</button>
    </div>`).join('');
  }
  $('#territoryEmpty').hidden = t.streets.length !== 0;
  const {total,done,pct}=territoryProgress(t);
  $('#territoryProgressLabel').textContent = `${done} de ${total} ${total===1?'calle/tramo':'calles/tramos'}`;
  $('#territoryProgressText').textContent = `${pct}%`;
  $('#territoryProgressBar').style.width = `${pct}%`;
  const badge = $('#territoryStatusBadge');
  badge.textContent = total===0 ? 'Sin iniciar' : pct===100 ? 'Completado' : done ? 'En curso' : 'Pendiente';
  badge.dataset.state = total===0?'empty':pct===100?'done':done?'active':'pending';
  $('#territoryUpdatedAt').textContent = t.updatedAt ? `Último cambio: ${new Date(t.updatedAt).toLocaleString('es-AR')}` : '';
}

function addStreetFromInput(){
  const input = $('#streetInput');
  const name = (input.value || '').trim().replace(/\s+/g,' ');
  if(!name) return;
  const t = ensureTerritory();
  if(!t.streets.some(s=>s.name.toLowerCase()===name.toLowerCase())){
    t.streets.push({name,done:false});
    touchTerritory(t);
  }
  input.value='';
  renderTerritoryStreetList();
}

function updateTerritoryMeta(){
  const t = ensureTerritory();
  t.driver = $('#territoryDriver').value.trim();
  t.date = $('#territoryDate').value;
  t.notes = $('#territoryNotes').value.trim();
  touchTerritory(t);
  renderTerritoryStreetList();
}

function renderStreetSuggestions(){
  const list = $('#streetSuggestions');
  if(!list) return;
  list.innerHTML = streetCatalog.slice(0,700).map(name=>`<option value="${escapeHTML(name)}"></option>`).join('');
  const btn=$('#loadOsmStreetsBtn');
  if(btn && streetCatalog.length) btn.textContent=`✓ ${streetCatalog.length} calles reales cargadas`;
}

function requestStreetCatalog(){
  const btn=$('#loadOsmStreetsBtn');
  if(btn){btn.disabled=true;btn.textContent='Cargando calles...';}
  if(window.AndroidBridge?.loadElCalafateStreets){
    window.AndroidBridge.loadElCalafateStreets();
  }else{
    if(btn){btn.disabled=false;btn.textContent='Disponible en el APK Android';}
  }
}

window.__cecReceiveStreetCatalog = function(payload){
  try{
    const arr = typeof payload === 'string' ? JSON.parse(payload) : payload;
    streetCatalog = [...new Set((arr||[]).filter(Boolean).map(String))].sort((a,b)=>a.localeCompare(b,'es'));
    localStorage.setItem(STREET_CATALOG_KEY, JSON.stringify(streetCatalog));
    renderStreetSuggestions();
  }catch(_){ }
  const btn=$('#loadOsmStreetsBtn'); if(btn) btn.disabled=false;
};

window.__cecStreetCatalogError = function(message){
  const btn=$('#loadOsmStreetsBtn');
  if(btn){btn.disabled=false;btn.textContent='Reintentar cargar calles reales';}
  if(message) console.warn(message);
};

function sheetResourceById(id){return resources.find(r=>r.id===id);}

function openSheet(resource){
  activeSheetResource = resource;
  activeSheetRows = [];
  activeSheetFilteredRows = [];
  $('#sheetTitle').textContent = resource.title;
  $('#sheetSearch').value='';
  $('#sheetError').hidden=true;
  $('#sheetError').textContent='';
  $('#sheetStatus').textContent='Cargando datos actuales...';
  $('#sheetRowCount').textContent='';
  $('#sheetTable').innerHTML='';
  $('#sheetOpenOriginal').href=resource.url || '#';
  $('#sheetScreen').hidden=false;
  document.body.classList.add('sheet-open');
  if(location.hash !== '#sheet') history.pushState({cecSheet:true}, '', '#sheet');
  loadSheetData(resource, false);
}

function closeSheet(fromHistory=false){
  $('#sheetScreen').hidden=true;
  document.body.classList.remove('sheet-open');
  activeSheetResource=null;
  if(!fromHistory && location.hash==='#sheet') history.back();
}

function loadSheetData(resource, force){
  if(!resource?.sheetId) return;
  const cacheKey=`cec_sheet_cache_${resource.id}`;
  if(!force){
    try{
      const cache=JSON.parse(localStorage.getItem(cacheKey)||'null');
      if(cache?.csv){
        receiveSheetCsv(resource.id, cache.csv, true, cache.savedAt);
      }
    }catch(_){ }
  }
  $('#sheetStatus').textContent = force ? 'Actualizando...' : 'Buscando datos actuales...';
  if(window.AndroidBridge?.loadSheet){
    window.AndroidBridge.loadSheet(resource.id, resource.sheetId);
  }else{
    $('#sheetStatus').textContent='La lectura directa está disponible dentro del APK Android.';
  }
}

window.__cecReceiveSheet = function(resourceId, base64){
  try{
    const bytes=Uint8Array.from(atob(base64),c=>c.charCodeAt(0));
    const csv=new TextDecoder('utf-8').decode(bytes);
    receiveSheetCsv(resourceId,csv,false,new Date().toISOString());
    localStorage.setItem(`cec_sheet_cache_${resourceId}`,JSON.stringify({csv,savedAt:new Date().toISOString()}));
  }catch(err){window.__cecSheetError(resourceId,'No se pudieron interpretar los datos de la planilla.');}
};

window.__cecSheetError = function(resourceId, message){
  if(activeSheetResource?.id!==resourceId) return;
  $('#sheetStatus').textContent='No se pudo actualizar. Si existe una copia guardada, se mantiene visible.';
  $('#sheetError').hidden=false;
  $('#sheetError').textContent=message || 'La planilla no respondió o requiere una autorización de Google.';};

function receiveSheetCsv(resourceId,csv,fromCache,savedAt){
  if(activeSheetResource?.id!==resourceId) return;
  const rows=parseCSV(csv).filter(row=>row.some(cell=>String(cell).trim()!==''));
  activeSheetRows=rows;
  activeSheetFilteredRows=rows;
  renderSheetTable();
  const when=savedAt?new Date(savedAt).toLocaleString('es-AR'):'';
  $('#sheetStatus').textContent=fromCache?`Mostrando copia guardada${when?' · '+when:''}. Actualizando en segundo plano...`:`Datos actualizados${when?' · '+when:''}.`;
  $('#sheetError').hidden=true;
}

function parseCSV(text){
  const rows=[]; let row=[],cell='',quoted=false;
  for(let i=0;i<text.length;i++){
    const ch=text[i];
    if(quoted){
      if(ch==='"' && text[i+1]==='"'){cell+='"';i++;}
      else if(ch==='"') quoted=false;
      else cell+=ch;
    }else{
      if(ch==='"') quoted=true;
      else if(ch===','){row.push(cell);cell='';}
      else if(ch==='\n'){row.push(cell.replace(/\r$/,''));rows.push(row);row=[];cell='';}
      else cell+=ch;
    }
  }
  if(cell!==''||row.length){row.push(cell.replace(/\r$/,''));rows.push(row);}
  return rows;
}

function filterSheetRows(){
  const q=($('#sheetSearch').value||'').trim().toLowerCase();
  if(!q){activeSheetFilteredRows=activeSheetRows;}
  else if(activeSheetRows.length){
    activeSheetFilteredRows=[activeSheetRows[0],...activeSheetRows.slice(1).filter(row=>row.join(' ').toLowerCase().includes(q))];
  }
  renderSheetTable();
}

function renderSheetTable(){
  const rows=activeSheetFilteredRows||[];
  const table=$('#sheetTable');
  if(!rows.length){table.innerHTML='<tbody><tr><td class="sheet-empty-cell">Sin datos visibles.</td></tr></tbody>';$('#sheetRowCount').textContent='0 filas';return;}
  const maxCols=Math.max(...rows.map(r=>r.length));
  const normalized=rows.map(r=>Array.from({length:maxCols},(_,i)=>r[i]??''));
  const head=normalized[0];
  const body=normalized.slice(1,1001);
  table.innerHTML=`<thead><tr>${head.map(c=>`<th>${escapeHTML(c||'—')}</th>`).join('')}</tr></thead><tbody>${body.map(row=>`<tr>${row.map(c=>`<td>${escapeHTML(c)}</td>`).join('')}</tr>`).join('')}</tbody>`;
  $('#sheetRowCount').textContent=`${Math.max(0,normalized.length-1)} filas${normalized.length>1001?' · mostrando primeras 1000':''}`;
}

function initIntegratedFeatures(){
  renderTerritorySelector();
  renderStreetSuggestions();
  loadTerritoryIntoForm();
}

document.addEventListener('click', e=>{
  const nav = e.target.closest('.nav-item');
  if(nav) return navigate(nav.dataset.target);

  const q = e.target.closest('[data-quick-target]');
  if(q){
    navigate(q.dataset.quickTarget);
    if(q.dataset.quickFilter){activeFilter=q.dataset.quickFilter;render();}
    return;
  }

  const filter = e.target.closest('[data-filter]');
  if(filter){activeFilter=filter.dataset.filter;render();return;}

  const card = e.target.closest('[data-resource]');
  if(card){const r=findResource(card.dataset.resource); if(r) openResource(r); return;}

  const streetCheck = e.target.closest('[data-street-check]');
  if(streetCheck){
    const t=ensureTerritory(); const i=Number(streetCheck.dataset.streetCheck);
    if(t.streets[i]){t.streets[i].done=streetCheck.checked;touchTerritory(t);renderTerritoryStreetList();}
    return;
  }
  const streetRemove=e.target.closest('[data-street-remove]');
  if(streetRemove){
    const t=ensureTerritory(); const i=Number(streetRemove.dataset.streetRemove);
    if(t.streets[i]){t.streets.splice(i,1);touchTerritory(t);renderTerritoryStreetList();}
  }
});

$('#resourceSearch').addEventListener('input', renderResourceSearch);
$('#dialogClose').addEventListener('click', ()=>$('#resourceDialog').close());
$('#dialogFavorite').addEventListener('click', toggleFavorite);
$('#resourceDialog').addEventListener('click', e=>{if(e.target===$('#resourceDialog')) $('#resourceDialog').close();});
$('#dialogOpen').addEventListener('click', ()=>$('#resourceDialog').close());


$('#territorySelect').addEventListener('change', loadTerritoryIntoForm);
$('#territoryDriver').addEventListener('change', updateTerritoryMeta);
$('#territoryDate').addEventListener('change', updateTerritoryMeta);
$('#territoryNotes').addEventListener('change', updateTerritoryMeta);
$('#territoryStreetSearch').addEventListener('input', renderTerritoryStreetList);
$('#streetInput').addEventListener('keydown', e=>{if(e.key==='Enter'){e.preventDefault();addStreetFromInput();}});
$('#addStreetBtn').addEventListener('click', addStreetFromInput);
$('#loadOsmStreetsBtn').addEventListener('click', requestStreetCatalog);
$('#markAllStreetsBtn').addEventListener('click', ()=>{const t=ensureTerritory();t.streets.forEach(s=>s.done=true);touchTerritory(t);renderTerritoryStreetList();});
$('#unmarkAllStreetsBtn').addEventListener('click', ()=>{const t=ensureTerritory();t.streets.forEach(s=>s.done=false);touchTerritory(t);renderTerritoryStreetList();});
$('#clearTerritoryBtn').addEventListener('click', ()=>{const n=territoryNumber();if(confirm(`¿Reiniciar el territorio ${n}? Se borrarán calles, observaciones y progreso guardado en este dispositivo.`)){delete territoryState[n];saveTerritoryState();loadTerritoryIntoForm();}});

$('#sheetBack').addEventListener('click', closeSheet);
$('#sheetRefresh').addEventListener('click', ()=>{if(activeSheetResource) loadSheetData(activeSheetResource,true);});
$('#sheetSearch').addEventListener('input', filterSheetRows);
$('#sheetOpenOriginal').addEventListener('click', ()=>{ /* permanece dentro del WebView nativo */ });
window.addEventListener('popstate', ()=>{if(!$('#sheetScreen').hidden) closeSheet(true);});

window.addEventListener('beforeinstallprompt', e=>{
  e.preventDefault();
  deferredPrompt=e;
  $('#installBtn').hidden=false;
});
$('#installBtn').addEventListener('click', async()=>{
  if(!deferredPrompt) return;
  deferredPrompt.prompt();
  await deferredPrompt.userChoice;
  deferredPrompt=null;
  $('#installBtn').hidden=true;
});
window.addEventListener('appinstalled', ()=>{$('#installBtn').hidden=true;});

if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));}

render();
initIntegratedFeatures();

;(function(){
  'use strict';

  const VERSION='1.4.0';
  const LOCATIONS={
    'carrito-anonima':{label:'La Anónima',subtitle:'Centro',sheetId:'1K4BowT0kvU1zlbMw0M9cFA8ToMp9CaTHSqag64x7UWc'},
    'carrito-anfiteatro':{label:'Anfiteatro',subtitle:'Predicación pública',sheetId:'1SfJQfHRblwVM891QvDnu6fbZewb_l1gx0iYoHIU5YNg'},
    'carrito-terminal':{label:'Terminal de Ómnibus',subtitle:'Predicación pública',sheetId:'1tnW0uSGdfcsO2ldEyyUpLAMO2mI9ttABnzmgSQc2OUE'}
  };
  const DAY_ORDER=['lunes','martes','miercoles','jueves','viernes','sabado','domingo'];
  const DAY_LABEL={lunes:'Lunes',martes:'Martes',miercoles:'Miércoles',jueves:'Jueves',viernes:'Viernes',sabado:'Sábado',domingo:'Domingo'};
  const OVERRIDES_KEY='cec_carritos_v140_overrides';
  const RECENT_KEY='cec_carritos_v140_recent';
  const CACHE_PREFIX='cec_carritos_v140_csv_';
  const CACHE_FRESH_MS=180000;
  const cacheTimeKey=id=>CACHE_PREFIX+'updated_'+id;

  let currentLocation='carrito-anonima';
  let currentDay=todayKey();
  let currentData=null;
  let currentPicker=null;

  function $(sel,root=document){return root.querySelector(sel);}
  function $$(sel,root=document){return Array.from(root.querySelectorAll(sel));}
  function norm(v){return String(v==null?'':v).replace(/\s+/g,' ').trim();}
  function key(v){return norm(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();}
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
  function todayKey(){const d=new Date().getDay();return({1:'lunes',2:'martes',3:'miercoles',4:'jueves',5:'viernes',6:'sabado',0:'domingo'})[d]||'lunes';}
  function safeJson(text,fallback){try{return JSON.parse(text);}catch(_){return fallback;}}
  function getOverrides(){return safeJson(localStorage.getItem(OVERRIDES_KEY)||'{}',{});}
  function setOverrides(v){localStorage.setItem(OVERRIDES_KEY,JSON.stringify(v));}
  function getRecent(){return safeJson(localStorage.getItem(RECENT_KEY)||'[]',[]);}
  function rememberName(name){const n=norm(name);if(!n)return;const arr=[n,...getRecent().filter(x=>key(x)!==key(n))].slice(0,8);localStorage.setItem(RECENT_KEY,JSON.stringify(arr));}

  function parseCsv(text){
    const rows=[];let row=[],cell='',quoted=false;text=String(text||'').replace(/^\uFEFF/,'');
    for(let i=0;i<text.length;i++){
      const ch=text[i];
      if(quoted){if(ch==='"'&&text[i+1]==='"'){cell+='"';i++;}else if(ch==='"')quoted=false;else cell+=ch;}
      else{if(ch==='"')quoted=true;else if(ch===','){row.push(cell);cell='';}else if(ch==='\n'){row.push(cell.replace(/\r$/,''));rows.push(row);row=[];cell='';}else cell+=ch;}
    }
    if(cell!==''||row.length){row.push(cell.replace(/\r$/,''));rows.push(row);}return rows;
  }

  function dayFromText(v){const k=key(v);if(k.includes('lunes'))return'lunes';if(k.includes('martes'))return'martes';if(k.includes('miercoles'))return'miercoles';if(k.includes('jueves'))return'jueves';if(k.includes('viernes'))return'viernes';if(k.includes('sabado'))return'sabado';if(k.includes('domingo'))return'domingo';return'';}

  function parseCarritoCsv(csv,resourceId){
    const rows=parseCsv(csv);
    let headerIndex=rows.findIndex(r=>key(r[0])==='hora'&&r.some(c=>key(c).startsWith('publicador 1')));
    if(headerIndex<0)headerIndex=rows.findIndex(r=>r.some(c=>key(c)==='hora'));
    if(headerIndex<0)throw new Error('No se encontró la estructura de horarios.');
    const header=rows[headerIndex]||[],dayRow=rows[Math.max(0,headerIndex-1)]||[],groups=[];
    for(let c=0;c<header.length;c++)if(key(header[c]).startsWith('publicador 1')){
      let rawDay=norm(dayRow[c]);
      if(!rawDay)for(let p=c;p>=Math.max(0,c-2);p--)if(norm(dayRow[p])){rawDay=norm(dayRow[p]);break;}
      const dk=dayFromText(rawDay)||DAY_ORDER[groups.length]||('dia'+groups.length);
      groups.push({day:dk,label:DAY_LABEL[dk]||rawDay||`Día ${groups.length+1}`,cols:[c,c+1,c+2]});
    }
    if(!groups.length)throw new Error('No se encontraron días en la escala.');
    const shiftsByDay={};groups.forEach(g=>shiftsByDay[g.day]=[]);
    for(let r=headerIndex+1;r<rows.length;r++){
      const time=norm(rows[r]?.[0]);if(!time){if(r>headerIndex+7)break;continue;}if(!/\d{1,2}:?\d{0,2}/.test(time))continue;
      groups.forEach(g=>{const slots=g.cols.map((col,idx)=>{const value=norm(rows[r]?.[col])||'LIBRE';return{slot:idx+1,value,free:key(value)==='libre',optional:idx===2};});shiftsByDay[g.day].push({time,slots,row:r+1});});
    }
    const namesMap=new Map();
    Object.values(shiftsByDay).flat().forEach(shift=>shift.slots.forEach(s=>{if(!s.free&&norm(s.value).length>2)namesMap.set(key(s.value),norm(s.value));}));
    const startNames=Math.min(rows.length,Math.max(headerIndex+25,45));
    for(let r=startNames;r<rows.length;r++){
      const candidate=norm(rows[r]?.[1]),k=key(candidate);
      if(!candidate||k==='libre'||candidate.length<3)continue;
      if(/pautas|predicacion publica|lugar dnde|publicador/i.test(candidate))continue;
      namesMap.set(k,candidate);
    }
    const names=Array.from(namesMap.values()).sort((a,b)=>a.localeCompare(b,'es',{sensitivity:'base'}));
    const pickup=norm(rows[4]?.[1]||'');
    return{resourceId,location:LOCATIONS[resourceId],groups,shiftsByDay,names,pickup,loadedAt:new Date().toISOString()};
  }

  function injectStyles(){
    if($('#cecCarritosStyle'))return;const style=document.createElement('style');style.id='cecCarritosStyle';style.textContent=`
#cecCarritosScreen{position:fixed;inset:0;z-index:5000;background:#f4f8fa;color:#173042;display:none;overflow:auto;-webkit-overflow-scrolling:touch;padding-bottom:28px}#cecCarritosScreen.open{display:block}
.cec-c-head{position:sticky;top:0;z-index:5;background:#0b4f6c;color:#fff;display:flex;align-items:center;gap:10px;padding:10px 12px;min-height:58px;box-shadow:0 2px 10px rgba(0,0,0,.08)}.cec-c-back{width:44px;height:44px;border:0;border-radius:14px;background:rgba(255,255,255,.12);color:#fff;font-size:28px;line-height:1}.cec-c-head-title{min-width:0;flex:1}.cec-c-head-title small{display:block;font-size:10px;letter-spacing:.1em;opacity:.75;font-weight:800}.cec-c-head-title strong{display:block;font-size:18px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.cec-c-refresh{height:42px;border:0;border-radius:13px;background:#fff;color:#0b4f6c;padding:0 13px;font-weight:800}
.cec-c-wrap{max-width:760px;margin:0 auto;padding:14px}.cec-c-summary{background:linear-gradient(135deg,#0b4f6c,#14759a);color:#fff;border-radius:24px;padding:18px;margin-bottom:13px;box-shadow:0 12px 28px rgba(11,79,108,.17)}.cec-c-summary .ey{font-size:11px;letter-spacing:.12em;font-weight:900;opacity:.78}.cec-c-summary h2{font-size:24px;margin:4px 0 3px}.cec-c-summary p{margin:0;opacity:.82;font-size:13px}
.cec-c-locations,.cec-c-days{display:flex;gap:8px;overflow:auto;padding:3px 1px 10px;scrollbar-width:none}.cec-c-locations::-webkit-scrollbar,.cec-c-days::-webkit-scrollbar{display:none}.cec-chip{border:1px solid #d4e2e8;background:#fff;color:#315164;border-radius:999px;padding:10px 14px;font-size:13px;font-weight:800;white-space:nowrap;min-height:42px}.cec-chip.active{background:#0b4f6c;color:#fff;border-color:#0b4f6c}
.cec-c-tools{display:flex;gap:8px;margin:2px 0 12px}.cec-c-search{flex:1;min-width:0;border:1px solid #d5e2e8;background:#fff;border-radius:15px;padding:0 13px;height:46px;font-size:16px}.cec-c-toggle{border:1px solid #d5e2e8;background:#fff;border-radius:15px;padding:0 12px;font-weight:800;color:#315164}.cec-c-toggle.active{background:#e6f4f8;border-color:#88bcca;color:#0b4f6c}.cec-c-status{font-size:12px;color:#647b88;padding:0 3px 9px}.cec-c-status.error{color:#9b2d30}.cec-c-status.ok{color:#246a4d}
.cec-shifts{display:grid;gap:10px}.cec-shift{background:#fff;border:1px solid #dae6eb;border-radius:20px;padding:14px}.cec-shift-top{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:10px}.cec-shift-time{font-size:18px;font-weight:900;color:#143d52}.cec-shift-count{font-size:11px;font-weight:900;border-radius:999px;padding:6px 9px;background:#edf4f7;color:#57707d}.cec-shift-count.has-free{background:#e7f6ee;color:#26724e}.cec-slots{display:grid;gap:8px}.cec-slot{min-height:50px;border-radius:15px;border:1px solid #e1eaee;display:flex;align-items:center;gap:10px;padding:9px 11px;background:#fbfdfe}.cec-slot-num{width:30px;height:30px;border-radius:10px;background:#edf3f6;display:grid;place-items:center;font-weight:900;color:#607784;flex:0 0 auto}.cec-slot-body{min-width:0;flex:1}.cec-slot-body strong{display:block;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.cec-slot-body small{display:block;color:#7b8f99;font-size:11px;margin-top:2px}.cec-slot-free{border-style:dashed;border-color:#9ecbbc;background:#f2fbf7}.cec-slot-free .cec-slot-num{background:#dff3e9;color:#26724e}.cec-claim{border:0;border-radius:12px;background:#0b6b4f;color:white;font-weight:900;padding:10px 12px;min-height:40px}.cec-local-tag{font-size:10px;background:#fff2ce;color:#725a16;border-radius:999px;padding:4px 7px;font-weight:800}.cec-clear-local{border:0;background:transparent;color:#8a5555;font-size:18px;padding:6px}
.cec-empty{background:#fff;border:1px dashed #cbdce3;border-radius:18px;padding:24px;text-align:center;color:#647b88}.cec-c-footnote{font-size:11px;color:#718792;line-height:1.45;margin:14px 3px 0}.cec-picker{position:fixed;inset:0;z-index:6000;background:rgba(9,35,48,.56);display:none;align-items:flex-end}.cec-picker.open{display:flex}.cec-picker-sheet{background:#fff;width:100%;max-height:86%;border-radius:25px 25px 0 0;padding:15px;display:flex;flex-direction:column;gap:10px}.cec-picker-head{display:flex;align-items:center;gap:10px}.cec-picker-head div{min-width:0;flex:1}.cec-picker-head small{color:#6a808c}.cec-picker-head strong{display:block;font-size:19px}.cec-picker-close{width:44px;height:44px;border:0;border-radius:13px;background:#eef3f5;font-size:24px}.cec-picker-search{height:48px;border:1px solid #cbdde4;border-radius:15px;padding:0 14px;font-size:16px}.cec-name-list{overflow:auto;display:grid;gap:7px;padding-bottom:10px}.cec-name{border:1px solid #dce7eb;background:#fff;border-radius:14px;text-align:left;padding:12px 13px;font-size:14px;font-weight:750;color:#243e4c}.cec-name.recent:after{content:'Reciente';float:right;font-size:10px;color:#6b7f8a;font-weight:700}.cec-picker-meta{font-size:12px;color:#6d828e}
.cec-home-carritos{width:100%;border:0;text-align:left;background:linear-gradient(135deg,#0b4f6c,#14759a);color:#fff;border-radius:20px;padding:15px;display:flex;align-items:center;gap:12px;box-shadow:0 10px 24px rgba(11,79,108,.14)}.cec-home-carritos .ic{width:44px;height:44px;border-radius:14px;background:rgba(255,255,255,.13);display:grid;place-items:center;font-size:22px}.cec-home-carritos strong{display:block;font-size:15px}.cec-home-carritos small{display:block;opacity:.78;margin-top:2px}.cec-home-carritos .arr{margin-left:auto;font-size:24px}@media(min-width:650px){.cec-picker{align-items:center;justify-content:center}.cec-picker-sheet{max-width:520px;border-radius:25px;max-height:80%}}
`;
    document.head.appendChild(style);
  }

  function injectUi(){
    if($('#cecCarritosScreen'))return;
    const screen=document.createElement('section');screen.id='cecCarritosScreen';screen.setAttribute('aria-label','Carritos');screen.innerHTML=`
<header class="cec-c-head"><button type="button" class="cec-c-back" aria-label="Volver">‹</button><div class="cec-c-head-title"><small>CARRITOS · ESCALA</small><strong>Predicación pública</strong></div><button type="button" class="cec-c-refresh">Actualizar</button></header>
<div class="cec-c-wrap"><section class="cec-c-summary"><div class="ey">ORGANIZACIÓN</div><h2 id="cecCarritosLocationTitle">Carritos</h2><p id="cecCarritosPickup">Elegí un lugar para ver los turnos.</p></section><div id="cecCarritosLocations" class="cec-c-locations"></div><div id="cecCarritosDays" class="cec-c-days"></div><div class="cec-c-tools"><input id="cecCarritosSearch" class="cec-c-search" type="search" placeholder="Buscar nombre u horario..."><button id="cecOnlyFree" type="button" class="cec-c-toggle">Solo libres</button></div><div id="cecCarritosStatus" class="cec-c-status">Preparando escala...</div><div id="cecCarritosShifts" class="cec-shifts"></div><p class="cec-c-footnote">La escala se lee de la planilla original. Los nombres añadidos desde esta versión quedan guardados en este teléfono y se muestran junto a la escala actual.</p></div>`;document.body.appendChild(screen);
    const picker=document.createElement('div');picker.id='cecCarritosPicker';picker.className='cec-picker';picker.innerHTML=`<div class="cec-picker-sheet" role="dialog" aria-modal="true" aria-labelledby="cecPickerTitle"><div class="cec-picker-head"><div><small id="cecPickerMeta">Vaga</small><strong id="cecPickerTitle">¿Quién se ofrece?</strong></div><button type="button" class="cec-picker-close" aria-label="Cerrar">×</button></div><input id="cecPickerSearch" class="cec-picker-search" type="search" placeholder="Buscar publicador..." autocomplete="off"><div id="cecPickerCount" class="cec-picker-meta"></div><div id="cecPickerNames" class="cec-name-list"></div></div>`;document.body.appendChild(picker);
    $('.cec-c-back',screen).addEventListener('click',closeCarritos);$('.cec-c-refresh',screen).addEventListener('click',()=>loadLocation(currentLocation,true));$('#cecCarritosSearch').addEventListener('input',renderShifts);$('#cecOnlyFree').addEventListener('click',e=>{e.currentTarget.classList.toggle('active');renderShifts();});$('.cec-picker-close',picker).addEventListener('click',closePicker);picker.addEventListener('click',e=>{if(e.target===picker)closePicker();});$('#cecPickerSearch').addEventListener('input',renderNameList);
  }

  function injectEntrypoints(){
    const grid=$('#quickGrid');if(grid&&!$('#cecHomeCarritos')){const b=document.createElement('button');b.type='button';b.id='cecHomeCarritos';b.className='cec-home-carritos';b.innerHTML='<span class="ic">▦</span><span><strong>Carritos · ocupar turnos</strong><small>Ver La Anónima, Anfiteatro y Terminal</small></span><span class="arr">›</span>';b.addEventListener('click',()=>openCarritos('carrito-anonima'));grid.prepend(b);}
    const title=$('.territory-resources-title');if(title&&!$('#cecTerritoryCarritos')){const b=document.createElement('button');b.type='button';b.id='cecTerritoryCarritos';b.className='cec-home-carritos';b.style.margin='0 0 16px';b.innerHTML='<span class="ic">▦</span><span><strong>Escala de carritos</strong><small>Turnos, vacantes y lista de publicadores</small></span><span class="arr">›</span>';b.addEventListener('click',()=>openCarritos('carrito-anonima'));title.parentNode.insertBefore(b,title);}
    const about=$('.about-card strong');if(about)about.textContent='Aplicación v1.4.0 · carritos como app, no como planilla';const aboutP=$('.about-card p');if(aboutP)aboutP.textContent='Carritos ahora se visualiza como una agenda de turnos con vacantes y selección de publicadores. Las planillas quedan como fuente de datos.';
  }

  function openCarritos(resourceId){if(!LOCATIONS[resourceId])resourceId='carrito-anonima';currentLocation=resourceId;$('#cecCarritosScreen').classList.add('open');document.body.style.overflow='hidden';renderLocationChips();renderDayChips();if(location.hash!=='#carritos')history.pushState({cecCarritos:true},'','#carritos');loadLocation(resourceId,false);}
  function closeCarritos(){if(location.hash==='#carritos'){history.back();return;}hideCarritos();}
  function hideCarritos(){$('#cecCarritosScreen')?.classList.remove('open');document.body.style.overflow='';closePicker();}
  function renderLocationChips(){const root=$('#cecCarritosLocations');if(!root)return;root.innerHTML=Object.entries(LOCATIONS).map(([id,c])=>`<button type="button" class="cec-chip ${id===currentLocation?'active':''}" data-cec-location="${id}">${esc(c.label)}</button>`).join('');$$('[data-cec-location]',root).forEach(b=>b.addEventListener('click',()=>{currentLocation=b.dataset.cecLocation;renderLocationChips();loadLocation(currentLocation,false);}));}
  function renderDayChips(){const root=$('#cecCarritosDays');if(!root)return;root.innerHTML=DAY_ORDER.map(d=>`<button type="button" class="cec-chip ${d===currentDay?'active':''}" data-cec-day="${d}">${DAY_LABEL[d]}</button>`).join('');$$('[data-cec-day]',root).forEach(b=>b.addEventListener('click',()=>{currentDay=b.dataset.cecDay;renderDayChips();renderShifts();}));}

  function loadLocation(resourceId,force){
    const cfg=LOCATIONS[resourceId];if(!cfg)return;currentData=null;$('#cecCarritosLocationTitle').textContent=cfg.label;$('#cecCarritosPickup').textContent=cfg.subtitle;setStatus(force?'Actualizando escala...':'Cargando escala...','');$('#cecCarritosShifts').innerHTML='<div class="cec-empty">Leyendo horarios y nombres...</div>';
    if(!force){const cached=localStorage.getItem(CACHE_PREFIX+resourceId);if(cached)try{receiveCsv(resourceId,cached,true);}catch(_){}const savedAt=Number(localStorage.getItem(cacheTimeKey(resourceId))||0);if(currentData&&savedAt&&Date.now()-savedAt<CACHE_FRESH_MS){setStatus('Datos guardados recientes · se evita una recarga innecesaria.','ok');return;}}
    if(window.AndroidBridge&&typeof window.AndroidBridge.loadSheet==='function')window.AndroidBridge.loadSheet(resourceId,cfg.sheetId);else if(!currentData)setStatus('La actualización automática está disponible en el APK Android.','error');
  }

  function receiveCsv(resourceId,csv,fromCache){
    if(!LOCATIONS[resourceId])return false;
    try{const data=parseCarritoCsv(csv,resourceId);if(!fromCache){localStorage.setItem(CACHE_PREFIX+resourceId,csv);localStorage.setItem(cacheTimeKey(resourceId),String(Date.now()));}if(resourceId===currentLocation&&$('#cecCarritosScreen')?.classList.contains('open')){currentData=data;const availableDays=data.groups.map(g=>g.day);if(!availableDays.includes(currentDay))currentDay=availableDays[0]||'lunes';renderDayChips();$('#cecCarritosPickup').textContent=data.pickup?`Retiro del carrito: ${data.pickup}`:LOCATIONS[resourceId].subtitle;setStatus(fromCache?'Mostrando la última copia guardada; actualizando...':`Actualizado · ${data.names.length} publicadores disponibles`,'ok');renderShifts();}return true;}catch(err){if(resourceId===currentLocation)setStatus('No se pudo interpretar esta escala. '+norm(err.message),'error');return true;}
  }

  function overrideId(resourceId,day,time,slot){return[resourceId,day,key(time),slot].join('|');}
  function effectiveSlot(day,time,slotObj){const ovs=getOverrides(),id=overrideId(currentLocation,day,time,slotObj.slot),ov=ovs[id];if(ov&&ov.name)return{...slotObj,value:ov.name,free:false,local:true,overrideId:id};return{...slotObj,local:false,overrideId:id};}
  function renderShifts(){
    const root=$('#cecCarritosShifts');if(!root)return;if(!currentData){root.innerHTML='<div class="cec-empty">Cargando escala...</div>';return;}
    const query=key($('#cecCarritosSearch')?.value||''),onlyFree=$('#cecOnlyFree')?.classList.contains('active');let shifts=(currentData.shiftsByDay[currentDay]||[]).map(s=>({...s,slots:s.slots.map(x=>effectiveSlot(currentDay,s.time,x))}));if(onlyFree)shifts=shifts.filter(s=>s.slots.some(x=>x.free));if(query)shifts=shifts.filter(s=>key(s.time).includes(query)||s.slots.some(x=>key(x.value).includes(query)));if(!shifts.length){root.innerHTML='<div class="cec-empty">No hay turnos que coincidan con este filtro.</div>';return;}
    root.innerHTML=shifts.map(shift=>{const free=shift.slots.filter(s=>s.free).length;return`<article class="cec-shift"><div class="cec-shift-top"><span class="cec-shift-time">${esc(shift.time)}</span><span class="cec-shift-count ${free?'has-free':''}">${free?free+' '+(free===1?'vacante':'vacantes'):'Completo'}</span></div><div class="cec-slots">${shift.slots.map(s=>renderSlot(shift,s)).join('')}</div></article>`;}).join('');$$('[data-claim]',root).forEach(b=>b.addEventListener('click',()=>openPicker(b.dataset.day,b.dataset.time,Number(b.dataset.slot))));$$('[data-clear-local]',root).forEach(b=>b.addEventListener('click',()=>clearLocal(b.dataset.clearLocal)));
  }
  function renderSlot(shift,s){const optional=s.optional?' · opcional':'';if(s.free)return`<div class="cec-slot cec-slot-free"><span class="cec-slot-num">${s.slot}</span><div class="cec-slot-body"><strong>Vacante disponible</strong><small>Publicador ${s.slot}${optional}</small></div><button type="button" class="cec-claim" data-claim="1" data-day="${currentDay}" data-time="${esc(shift.time)}" data-slot="${s.slot}">Ocupar</button></div>`;return`<div class="cec-slot"><span class="cec-slot-num">${s.slot}</span><div class="cec-slot-body"><strong>${esc(s.value)}</strong><small>Publicador ${s.slot}${optional} ${s.local?'<span class="cec-local-tag">este teléfono</span>':''}</small></div>${s.local?`<button type="button" class="cec-clear-local" data-clear-local="${esc(s.overrideId)}" aria-label="Quitar asignación local">×</button>`:''}</div>`;}

  function openPicker(day,time,slot){if(!currentData)return;currentPicker={day,time,slot};$('#cecPickerMeta').textContent=`${DAY_LABEL[day]||day} · ${time} · lugar ${slot}`;$('#cecPickerSearch').value='';$('#cecCarritosPicker').classList.add('open');renderNameList();setTimeout(()=>$('#cecPickerSearch')?.focus(),80);}
  function closePicker(){$('#cecCarritosPicker')?.classList.remove('open');currentPicker=null;}
  function renderNameList(){const root=$('#cecPickerNames');if(!root||!currentData)return;const q=key($('#cecPickerSearch')?.value||''),recent=getRecent(),recentKeys=new Set(recent.map(key));let names=currentData.names.filter(n=>!q||key(n).includes(q));names.sort((a,b)=>{const ar=recentKeys.has(key(a))?0:1,br=recentKeys.has(key(b))?0:1;return ar-br||a.localeCompare(b,'es',{sensitivity:'base'});});$('#cecPickerCount').textContent=`${names.length} ${names.length===1?'nombre':'nombres'}`;root.innerHTML=names.slice(0,160).map(n=>`<button type="button" class="cec-name ${recentKeys.has(key(n))?'recent':''}" data-name="${esc(n)}">${esc(n)}</button>`).join('')||'<div class="cec-empty">No se encontró ese nombre.</div>';$$('[data-name]',root).forEach(b=>b.addEventListener('click',()=>claimLocal(b.dataset.name)));}
  function claimLocal(name){if(!currentPicker||!currentData)return;const canonical=currentData.names.find(n=>key(n)===key(name));if(!canonical){setStatus('Ese nombre no pertenece a la lista válida de publicadores.','error');return;}const{day,time,slot}=currentPicker,remoteShift=(currentData.shiftsByDay[day]||[]).find(s=>key(s.time)===key(time)),remoteSlot=remoteShift?.slots.find(s=>s.slot===slot);if(remoteSlot&&!remoteSlot.free){closePicker();setStatus(`La vacante ya figura ocupada por ${remoteSlot.value}.`,'error');renderShifts();return;}const ovs=getOverrides(),id=overrideId(currentLocation,day,time,slot);ovs[id]={name:canonical,savedAt:new Date().toISOString()};setOverrides(ovs);rememberName(canonical);closePicker();setStatus(`${canonical} quedó anotado en ${DAY_LABEL[day]} ${time}.`,'ok');renderShifts();}
  function clearLocal(id){const ovs=getOverrides();if(ovs[id]){delete ovs[id];setOverrides(ovs);setStatus('Asignación local eliminada.','ok');renderShifts();}}
  function setStatus(text,kind){const el=$('#cecCarritosStatus');if(!el)return;el.textContent=text||'';el.className='cec-c-status'+(kind?' '+kind:'');}

  const originalReceive=window.__cecReceiveSheet;window.__cecReceiveSheet=function(resourceId,base64){if(LOCATIONS[resourceId]){try{const bytes=Uint8Array.from(atob(base64),c=>c.charCodeAt(0)),csv=new TextDecoder('utf-8').decode(bytes);receiveCsv(resourceId,csv,false);}catch(_){setStatus('No se pudieron interpretar los datos del carrito.','error');}return;}if(typeof originalReceive==='function')return originalReceive.apply(this,arguments);};
  const originalError=window.__cecSheetError;window.__cecSheetError=function(resourceId,message){if(LOCATIONS[resourceId]){if(resourceId===currentLocation)setStatus(message||'No se pudo actualizar la escala.','error');return;}if(typeof originalError==='function')return originalError.apply(this,arguments);};
  document.addEventListener('click',function(e){const target=e.target.closest&&e.target.closest('[data-resource]');if(!target)return;const id=target.getAttribute('data-resource');if(!LOCATIONS[id])return;e.preventDefault();e.stopImmediatePropagation();openCarritos(id);},true);
  window.addEventListener('popstate',()=>{if(location.hash!=='#carritos'&&$('#cecCarritosScreen')?.classList.contains('open'))hideCarritos();});
  injectStyles();injectUi();injectEntrypoints();setTimeout(injectEntrypoints,500);window.CongElCalafateCarritos={version:VERSION,open:openCarritos,parse:parseCarritoCsv};
})();

;(function(){
  'use strict';

  const VERSION='1.4.1';
  const LOCATIONS={
    'carrito-anonima':{label:'La Anónima',subtitle:'Centro',sheetId:'1K4BowT0kvU1zlbMw0M9cFA8ToMp9CaTHSqag64x7UWc'},
    'carrito-anfiteatro':{label:'Anfiteatro',subtitle:'Predicación pública',sheetId:'1SfJQfHRblwVM891QvDnu6fbZewb_l1gx0iYoHIU5YNg'},
    'carrito-terminal':{label:'Terminal de Ómnibus',subtitle:'Predicación pública',sheetId:'1tnW0uSGdfcsO2ldEyyUpLAMO2mI9ttABnzmgSQc2OUE'}
  };
  const DAY_LABEL={lunes:'Lunes',martes:'Martes',miercoles:'Miércoles',jueves:'Jueves',viernes:'Viernes',sabado:'Sábado',domingo:'Domingo'};
  const summaries={};
  let activeId='carrito-anonima';

  function $(s,r=document){return r.querySelector(s);}
  function $$(s,r=document){return Array.from(r.querySelectorAll(s));}
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
  function todayKey(){const d=new Date().getDay();return({1:'lunes',2:'martes',3:'miercoles',4:'jueves',5:'viernes',6:'sabado',0:'domingo'})[d]||'lunes';}
  function parseStart(time){const m=String(time||'').match(/(\d{1,2}):(\d{2})/);if(!m)return null;return Number(m[1])*60+Number(m[2]);}
  function nowMinutes(){const d=new Date();return d.getHours()*60+d.getMinutes();}

  function ensureStyles(){
    if($('#cecV141Style'))return;
    const s=document.createElement('style');s.id='cecV141Style';s.textContent=`
      #cecCarritosLocations{display:none!important}
      .cec-c-summary{display:none!important}
      #cecV141Overview{display:grid;gap:8px;margin:0 0 10px}
      .cec-v141-bar{width:100%;border:1px solid #d7e4e9;background:#fff;border-radius:16px;padding:11px 12px;display:grid;grid-template-columns:minmax(0,1fr) auto;gap:10px;align-items:center;text-align:left;color:#173042;min-height:66px;box-shadow:0 3px 10px rgba(28,73,91,.05)}
      .cec-v141-bar.active{border-color:#76aebe;background:#f7fbfc;box-shadow:0 6px 16px rgba(11,79,108,.09)}
      .cec-v141-main{min-width:0;display:flex;align-items:center;gap:10px}
      .cec-v141-icon{width:38px;height:38px;border-radius:12px;background:#eaf3f6;color:#0b4f6c;display:grid;place-items:center;font-weight:900;font-size:17px;flex:0 0 auto}
      .cec-v141-bar.active .cec-v141-icon{background:#0b4f6c;color:#fff}
      .cec-v141-copy{min-width:0}.cec-v141-copy strong{display:block;font-size:15px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.cec-v141-copy small{display:block;color:#758994;font-size:11px;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      .cec-v141-side{display:flex;align-items:center;gap:8px}.cec-v141-count{min-width:54px;text-align:center;border-radius:12px;padding:7px 8px;background:#eef4f6;color:#536d7a;font-size:10px;font-weight:800;line-height:1.1}.cec-v141-count b{display:block;font-size:15px;color:#264c60;margin-bottom:2px}.cec-v141-count.free{background:#e9f7ef;color:#307457}.cec-v141-count.free b{color:#176c48}.cec-v141-count.full{background:#eef3f5;color:#61727b}
      .cec-v141-chevron{font-size:20px;color:#6c818d;line-height:1;transform:rotate(-90deg)}.cec-v141-bar.active .cec-v141-chevron{transform:rotate(0deg);color:#0b4f6c}
      .cec-v141-subline{grid-column:1/-1;display:none;border-top:1px solid #e8eff2;padding-top:8px;margin-top:1px;font-size:11px;color:#657b87;gap:10px;flex-wrap:wrap}.cec-v141-bar.active .cec-v141-subline{display:flex}
      .cec-v141-stat{display:inline-flex;align-items:center;gap:4px}.cec-v141-dot{width:6px;height:6px;border-radius:50%;background:#89a2ad}.cec-v141-dot.free{background:#3a956b}.cec-v141-dot.busy{background:#5b7180}
      @media(max-width:380px){.cec-v141-count{min-width:48px;padding:6px}.cec-v141-side{gap:5px}.cec-v141-copy strong{font-size:14px}}
    `;document.head.appendChild(s);
  }

  function ensureOverview(){
    const days=$('#cecCarritosDays');if(!days||$('#cecV141Overview'))return;
    const root=document.createElement('div');root.id='cecV141Overview';root.setAttribute('aria-label','Resumen de carritos');days.parentNode.insertBefore(root,days);
    renderOverview();
  }

  function summarize(data){
    const day=todayKey(),shifts=data?.shiftsByDay?.[day]||[];
    let free=0,busy=0;
    shifts.forEach(sh=>sh.slots.forEach(slot=>slot.free?free++:busy++));
    const now=nowMinutes();
    let next=shifts.find(sh=>{const st=parseStart(sh.time);return st!=null&&st>=now;});
    if(!next)next=shifts[0]||null;
    return{free,busy,total:free+busy,next:next?next.time:'Sin turnos',pickup:data?.pickup||'',day:DAY_LABEL[day]||day};
  }

  function barHtml(id){
    const cfg=LOCATIONS[id],sum=summaries[id];
    const isActive=id===activeId;
    const free=sum?sum.free:null,busy=sum?sum.busy:null;
    const status=free==null?'Cargando':free===0?'Completo':`${free} libre${free===1?'':'s'}`;
    const countClass=free===0?'full':'free';
    const next=sum?`Próx. ${sum.next}`:'Leyendo escala...';
    const pickup=sum?.pickup?` · ${sum.pickup}`:'';
    return `<button type="button" class="cec-v141-bar ${isActive?'active':''}" data-v141-location="${id}" aria-expanded="${isActive?'true':'false'}">
      <span class="cec-v141-main"><span class="cec-v141-icon">▦</span><span class="cec-v141-copy"><strong>${esc(cfg.label)}</strong><small>${esc(next)}</small></span></span>
      <span class="cec-v141-side"><span class="cec-v141-count ${countClass}"><b>${free==null?'…':free}</b>${free==null?'vagas':free===0?'completo':'vagas'}</span><span class="cec-v141-chevron">⌄</span></span>
      <span class="cec-v141-subline"><span class="cec-v141-stat"><i class="cec-v141-dot free"></i>${esc(status)}</span><span class="cec-v141-stat"><i class="cec-v141-dot busy"></i>${busy==null?'…':busy} ocupada${busy===1?'':'s'}</span><span class="cec-v141-stat">${sum?esc(sum.day):'Hoje'}${esc(pickup)}</span></span>
    </button>`;
  }

  function renderOverview(){
    const root=$('#cecV141Overview');if(!root)return;
    root.innerHTML=Object.keys(LOCATIONS).map(barHtml).join('');
    $$('[data-v141-location]',root).forEach(b=>b.addEventListener('click',()=>selectLocation(b.dataset.v141Location)));
  }

  function selectLocation(id){
    if(!LOCATIONS[id])return;activeId=id;renderOverview();
    if(window.CongElCalafateCarritos&&typeof window.CongElCalafateCarritos.open==='function')window.CongElCalafateCarritos.open(id);
  }

  function decodeCsv(base64){const bytes=Uint8Array.from(atob(base64),c=>c.charCodeAt(0));return new TextDecoder('utf-8').decode(bytes);}
  function consume(resourceId,base64){
    if(!LOCATIONS[resourceId])return;
    try{
      const csv=decodeCsv(base64);
      const parser=window.CongElCalafateCarritos&&window.CongElCalafateCarritos.parse;
      if(typeof parser!=='function')return;
      const data=parser(csv,resourceId);summaries[resourceId]=summarize(data);renderOverview();
    }catch(_){/* keep header usable even if one source fails */}
  }

  function refreshAll(){
    if(!(window.AndroidBridge&&typeof window.AndroidBridge.loadSheet==='function'))return;
    Object.entries(LOCATIONS).forEach(([id,c])=>window.AndroidBridge.loadSheet(id,c.sheetId));
  }

  function installReceiver(){
    const prev=window.__cecReceiveSheet;
    window.__cecReceiveSheet=function(resourceId,base64){const result=typeof prev==='function'?prev.apply(this,arguments):undefined;consume(resourceId,base64);return result;};
  }

  function observeScreen(){
    const screen=$('#cecCarritosScreen');if(!screen)return;
    const obs=new MutationObserver(()=>{if(screen.classList.contains('open')){ensureOverview();const active=$('#cecCarritosLocations .cec-chip.active');if(active?.dataset?.cecLocation)activeId=active.dataset.cecLocation;renderOverview();refreshAll();}});
    obs.observe(screen,{attributes:true,attributeFilter:['class']});
  }

  function patchVersionText(){
    const run=()=>{const strong=$('.about-card strong');if(strong)strong.textContent='Aplicación v1.4.1 · carritos compactos y comparables';const p=$('.about-card p');if(p)p.textContent='Los tres carritos aparecen como barras compactas con vacantes, ocupados y próximo turno. Solo el carrito seleccionado despliega la agenda completa.';};
    run();setTimeout(run,700);
  }

  ensureStyles();ensureOverview();installReceiver();observeScreen();patchVersionText();refreshAll();
  window.CongElCalafateCarritosCompact={version:VERSION,refresh:refreshAll};
})();

;(function(){
  'use strict';
  const VERSION='1.4.2';
  let busy=false;

  function $(s,r=document){return r.querySelector(s);}
  function $$(s,r=document){return Array.from(r.querySelectorAll(s));}

  function injectStyles(){
    if($('#cecV142Style'))return;
    const s=document.createElement('style');s.id='cecV142Style';s.textContent=`
      .cec-shifts{gap:8px!important}
      .cec-shift{padding:0!important;border-radius:16px!important;overflow:hidden;box-shadow:0 2px 8px rgba(28,73,91,.04);transition:border-color .18s ease,box-shadow .18s ease;background:#fff}
      .cec-shift.expanded{border-color:#9abfcb;box-shadow:0 6px 18px rgba(11,79,108,.08)}
      .cec-shift-top{margin:0!important;min-height:60px;padding:10px 12px!important;cursor:pointer;user-select:none;display:grid!important;grid-template-columns:minmax(0,1fr) auto auto;gap:8px!important;align-items:center!important}
      .cec-shift-top:active{background:#f5f9fb}
      .cec-v142-timebox{min-width:0;display:flex;flex-direction:column;gap:2px}
      .cec-shift-time{font-size:17px!important;line-height:1.1}
      .cec-v142-meta{font-size:11px;color:#718690;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      .cec-shift-count{margin:0!important;white-space:nowrap;padding:7px 10px!important;font-size:10px!important}
      .cec-v142-chevron{width:30px;height:30px;border-radius:10px;background:#eef4f6;display:grid;place-items:center;color:#5f7783;font-size:18px;font-weight:900;transition:transform .18s ease,background .18s ease;color .18s ease}
      .cec-shift.expanded .cec-v142-chevron{transform:rotate(180deg);background:#0b4f6c;color:#fff}
      .cec-slots{display:none!important;padding:0 12px 12px!important;gap:7px!important;border-top:1px solid #edf2f4}
      .cec-shift.expanded .cec-slots{display:grid!important;padding-top:10px!important}
      .cec-slot{min-height:46px!important;border-radius:13px!important;padding:7px 9px!important}
      .cec-slot-num{width:28px!important;height:28px!important;border-radius:9px!important}
      .cec-slot-body strong{font-size:13px!important}.cec-slot-body small{font-size:10px!important}
      .cec-claim{min-height:38px!important;padding:8px 11px!important;border-radius:11px!important}
      @media(max-width:380px){.cec-shift-top{grid-template-columns:minmax(0,1fr) auto auto;padding:9px 10px!important}.cec-shift-time{font-size:16px!important}.cec-v142-meta{font-size:10px}.cec-shift-count{padding:6px 8px!important}.cec-v142-chevron{width:28px;height:28px}}
    `;document.head.appendChild(s);
  }

  function decorateShift(article){
    if(!article||article.dataset.v142Done==='1')return;
    const top=$('.cec-shift-top',article),time=$('.cec-shift-time',article),count=$('.cec-shift-count',article),slots=$$('.cec-slot',article);
    if(!top||!time||!count||!slots.length)return;
    article.dataset.v142Done='1';
    article.classList.remove('expanded');
    const free=slots.filter(x=>x.classList.contains('cec-slot-free')).length;
    const occupied=Math.max(0,slots.length-free);
    const timeBox=document.createElement('span');timeBox.className='cec-v142-timebox';
    const meta=document.createElement('span');meta.className='cec-v142-meta';meta.textContent=`${occupied} ocupado${occupied===1?'':'s'} · ${free} vacante${free===1?'':'s'}`;
    time.parentNode.insertBefore(timeBox,time);timeBox.appendChild(time);timeBox.appendChild(meta);
    const chev=document.createElement('span');chev.className='cec-v142-chevron';chev.setAttribute('aria-hidden','true');chev.textContent='⌄';top.appendChild(chev);
    top.setAttribute('role','button');top.setAttribute('tabindex','0');top.setAttribute('aria-expanded','false');
    const toggle=()=>{
      const open=!article.classList.contains('expanded');
      $$('.cec-shift.expanded',article.parentNode).forEach(x=>{if(x!==article){x.classList.remove('expanded');$('.cec-shift-top',x)?.setAttribute('aria-expanded','false');}});
      article.classList.toggle('expanded',open);top.setAttribute('aria-expanded',open?'true':'false');
    };
    top.addEventListener('click',e=>{if(e.target.closest('button'))return;toggle();});
    top.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();toggle();}});
  }

  function decorateAll(){
    if(busy)return;busy=true;
    try{$$('.cec-shift').forEach(decorateShift);}finally{busy=false;}
  }

  function observe(){
    const root=$('#cecCarritosShifts');if(!root)return setTimeout(observe,100);
    const obs=new MutationObserver(()=>queueMicrotask(decorateAll));obs.observe(root,{childList:true,subtree:true});decorateAll();
  }

  function patchVersion(){
    const run=()=>{const strong=$('.about-card strong');if(strong)strong.textContent='Aplicación v1.4.2 · carritos y horarios compactos';const p=$('.about-card p');if(p)p.textContent='Los carritos y cada franja horaria se muestran minimizados. Tocá un horario para ver publicadores, vacantes y ocupar un lugar.';};run();setTimeout(run,700);
  }

  injectStyles();observe();patchVersion();
  window.CongElCalafateCarritosCompactShifts={version:VERSION,refresh:decorateAll};
})();
window.CongTerritoryOfficialData={"data":{"1":{"type":"manzanas","items":["Mz 89c","Mz 104","Mz 105","Mz 106","Mz 109","Mz 110","Mz 110a","Mz 127a","Mz 8903"]},"2":{"type":"manzanas","items":["Mz 1","Mz 115","Mz 116","Mz 117","Mz 118","Mz 119","Mz 120","Mz 131","Mz 135","Mz 513"]},"3":{"type":"manzanas","items":["Mz 9","Mz 98","Mz 99","Mz 121","Mz 122","Mz 123b"]},"4":{"type":"manzanas","items":["Mz 65b","Mz 65c","Mz 67a","Mz 68a","Mz 73a","Mz 73b","Mz 75a","Mz 75b"]},"5":{"type":"manzanas","items":["Mz 7","Mz 8","Mz 78","Mz 80","Mz 81","Mz 82"]},"6":{"type":"manzanas","items":["Mz 1","Mz 5","Mz 8"]},"7":{"type":"manzanas","items":["Mz 100","Mz 101","Mz 102","Mz 103a","Mz 103b","Mz 103c"]},"8":{"type":"manzanas","items":["Mz 6","Mz 7","Mz 45a","Mz 50","Mz 51","Mz 52","Mz 53","Mz 54","Mz 69b","Mz 72","Mz 74"]},"9":{"type":"manzanas","items":["Mz 5","Mz 6","Mz 60c"]},"10":{"type":"manzanas","items":["Mz 2","Mz 4"]},"11":{"type":"manzanas","items":["Mz 2","Mz 223","Mz 234","Mz 235","Mz 236","Mz 238"]},"12":{"type":"manzanas","items":["Mz 2","Mz 210","Mz 211","Mz 213","Mz 216","Mz 219","Mz 220","Mz 224","Mz 225","Mz 228","Mz 230"]},"13":{"type":"manzanas","items":["Mz 4","Mz 433"]},"14":{"type":"manzanas","items":["Mz 4","Mz 7","Mz 711","Mz 713"]},"15":{"type":"manzanas","items":["Mz 4","Mz 7"]},"16":{"type":"manzanas","items":["Mz 4","Mz 7"]},"17":{"type":"manzanas","items":["Mz 3","Mz 4","Mz 414"]},"18":{"type":"manzanas","items":["Mz 467c"]},"19":{"type":"manzanas","items":["Mz 451b","Mz 451c","Mz 451d","Mz 452","Mz 452b","Mz 454"]},"20":{"type":"manzanas","items":["Mz 400","Mz 401","Mz 402","Mz 403","Mz 404","Mz 405","Mz 406","Mz 408"]},"21":{"type":"manzanas","items":["Mz 4","Mz 477","Mz 478"]},"22":{"type":"manzanas","items":["Mz 4","Mz 48","Mz 484"]},"23":{"type":"manzanas","items":["Mz 437","Mz 439","Mz 444","Mz 470","Mz 471","Mz 472"]},"24":{"type":"manzanas","items":["Mz 4","Mz 5","Mz 491d"]},"25":{"type":"manzanas","items":["Mz 4","Mz 5"]},"26":{"type":"manzanas","items":["Mz 5","Mz 51","Mz 508","Mz 526","Mz 527","Mz 528"]},"27":{"type":"manzanas","items":["Mz 5"]},"28":{"type":"manzanas","items":["Mz 5","Mz 502","Mz 504","Mz 504a","Mz 519","Mz 519a","Mz 519b","Mz 519c","Mz 519d","Mz 556"]},"29":{"type":"manzanas","items":["Mz 6","Mz 43","Mz 63a","Mz 64b","Mz 77"]},"30":{"type":"manzanas","items":["Mz 537","Mz 538","Mz 539","Mz 540","Mz 541","Mz 542","Mz 543","Mz 544","Mz 599"]},"31":{"type":"manzanas","items":["Mz 1427","Mz 1428","Mz 1429","Mz 1430","Mz 1434"]},"32":{"type":"manzanas","items":["Mz 1431","Mz 1432","Mz 1502","Mz 1503","Mz 1504b"]},"33":{"type":"manzanas","items":["Mz 1","Mz 3"]},"34":{"type":"manzanas","items":["Mz 1004","Mz 1005","Mz 1006","Mz 1007","Mz 1014","Mz 1015"]},"35":{"type":"manzanas","items":["Mz 1"]},"36":{"type":"manzanas","items":["Mz 0","Mz 3"]},"37":{"type":"manzanas","items":["Mz 1039","Mz 1040","Mz 1041","Mz 1046","Mz 1047","Mz 1048","Mz 1049","Mz 1050","Mz 1051"]},"38":{"type":"manzanas","items":["Mz 1038"]},"39":{"type":"manzanas","items":["Mz 1"]},"40":{"type":"manzanas","items":["Mz 1500"]},"41":{"type":"manzanas","items":["Mz 147","Mz 1472","Mz 1514"]},"42":{"type":"manzanas","items":["Mz 1","Mz 1066","Mz 1067"]},"43":{"type":"manzanas","items":["Mz 1069","Mz 1070","Mz 1071","Mz 1073","Mz 1085","Mz 1086","Mz 1087","Mz 1089","Mz 1090"]},"44":{"type":"manzanas","items":["Mz 1074","Mz 1075","Mz 1076","Mz 1077","Mz 1078","Mz 1079","Mz 1080","Mz 1081","Mz 1082","Mz 1083","Mz 1084","Mz 1091","Mz 1092","Mz 1093","Mz 1094"]},"45":{"type":"manzanas","items":["Mz 1","Mz 14","Mz 148","Mz 1476"]},"46":{"type":"manzanas","items":["Mz 1","Mz 14","Mz 145","Mz 1412pa","Mz 1451"]},"47":{"type":"manzanas","items":["Mz 1","Mz 1492"]},"48":{"type":"manzanas","items":["Mz 1","Mz 14","Mz 1398","Mz 1399","Mz 1420","Mz 1422","Mz 1423","Mz 1424","Mz 1439","Mz 1440","Mz 1442"]},"49":{"type":"manzanas","items":["Mz 3","Mz 8","Mz 30","Mz 84","Mz 88","Mz 298","Mz 299","Mz 302","Mz 305","Mz 306d","Mz 306g"]},"50":{"type":"manzanas","items":["Mz 3","Mz 6","Mz 330a","Mz 330b"]},"51":{"type":"manzanas","items":["Mz 689"]},"52":{"type":"manzanas","items":["Mz 1","Mz 6","Mz 678","Mz 679","Mz 1408","Mz 1458","Mz 1459","Mz 1462"]},"53":{"type":"manzanas","items":["Mz 6","Mz 14","Mz 66","Mz 670"]},"54":{"type":"manzanas","items":["Mz 6","Mz 621a","Mz 622b","Mz 623a","Mz 624c","Mz 661","Mz 662","Mz 665","Mz 666","Mz 667"]},"55":{"type":"manzanas","items":["Mz 6","Mz 65","Mz 620","Mz 622","Mz 624","Mz 646a","Mz 646b","Mz 657","Mz 660"]},"56":{"type":"manzanas","items":["Mz 6"]},"57":{"type":"manzanas","items":["Mz 3","Mz 37","Mz 38","Mz 38b","Mz 38c","Mz 38d","Mz 39","Mz 40","Mz 41"]},"58":{"type":"manzanas","items":["Mz 1","Mz 2","Mz 3","Mz 8","Mz 9","Mz 10","Mz 11","Mz 12","Mz 13","Mz 19","Mz 20","Mz 21"]},"59":{"type":"manzanas","items":["Mz 4","Mz 5","Mz 5c","Mz 5d","Mz 6","Mz 7","Mz 14","Mz 15","Mz 16a","Mz 17","Mz 18"]},"60":{"type":"manzanas","items":["Mz 2","Mz 3","Mz 4","Mz 22","Mz 23","Mz 35","Mz 36"]},"61":{"type":"manzanas","items":["Mz 1","Mz 2","Mz 3","Mz 26","Mz 27","Mz 31","Mz 32a"]},"62":{"type":"manzanas","items":["Mz 1","Mz 7","Mz 9","Mz 999"]},"63":{"type":"manzanas","items":["Mz 1"]},"64":{"type":"manzanas","items":["Mz 1","Mz 1180","Mz 1181","Mz 1182","Mz 1185","Mz 1186","Mz 1189","Mz 1190","Mz 1192"]},"65":{"type":"manzanas","items":["Mz 1008","Mz 1009","Mz 1010","Mz 1011","Mz 1012","Mz 1013","Mz 1014"]},"66":{"type":"manzanas","items":["Mz 1002","Mz 1003","Mz 1004","Mz 1005","Mz 1006","Mz 1007"]},"67":{"type":"manzanas","items":["Mz 1198","Mz 1199","Mz 1200","Mz 1201","Mz 1202","Mz 1203"]},"68":{"type":"manzanas","items":["Mz 1","Mz 7","Mz 1138","Mz 1142"]},"69":{"type":"manzanas","items":["Mz 1","Mz 3","Mz 188"]},"70":{"type":"manzanas","items":["Mz 1104","Mz 1107","Mz 1118","Mz 1129"]},"71":{"type":"manzanas","items":["Mz 1","Mz 1108","Mz 1109","Mz 1110","Mz 1112","Mz 1120"]},"72":{"type":"manzanas","items":["Mz 1304","Mz 1305","Mz 1306","Mz 1307","Mz 1308","Mz 1309","Mz 1310"]},"73":{"type":"manzanas","items":["Mz 1","Mz 192","Mz 1303"]},"74":{"type":"manzanas","items":["Mz 191","Mz 192","Mz 193","Mz 194"]},"75":{"type":"manzanas","items":["Mz 1","Mz 2","Mz 169","Mz 170","Mz 171","Mz 176"]},"76":{"type":"manzanas","items":["Mz 1","Mz 4","Mz 153","Mz 177"]},"77":{"type":"manzanas","items":["Mz 82","Mz 818","Mz 819","Mz 820","Mz 821","Mz 827"]},"78":{"type":"manzanas","items":["Mz 1"]},"79":{"type":"manzanas","items":["Mz 8"]},"80":{"type":"manzanas","items":["Mz 1607","Mz 1637"]},"81":{"type":"manzanas","items":["Mz 161","Mz 1634","Mz 1649"]},"82":{"type":"manzanas","items":["Mz 1","Mz 16","Mz 1670"]},"83":{"type":"manzanas","items":["Mz 1617","Mz 1618","Mz 1619","Mz 1620","Mz 1621","Mz 1622","Mz 1623","Mz 1624","Mz 1625","Mz 1626","Mz 1627","Mz 1628","Mz 1629","Mz 1630","Mz 1661","Mz 1662","Mz 1663","Mz 1664","Mz 1665","Mz 1666","Mz 1667","Mz 1668","Mz 1680"]},"84":{"type":"manzanas","items":["Mz 946","Mz 947","Mz 948","Mz 949","Mz 950","Mz 951","Mz 952","Mz 953","Mz 954","Mz 955","Mz 956","Mz 957","Mz 958","Mz 959"]},"85":{"type":"manzanas","items":["Mz 934","Mz 935","Mz 936","Mz 937","Mz 938","Mz 939","Mz 940","Mz 941","Mz 942","Mz 943","Mz 944","Mz 945"]},"86":{"type":"manzanas","items":["Mz 916","Mz 918","Mz 920","Mz 921","Mz 922","Mz 923","Mz 925","Mz 927","Mz 928","Mz 930","Mz 932","Mz 933"]},"87":{"type":"manzanas","items":["Mz 847","Mz 848","Mz 849","Mz 857","Mz 861"]},"88":{"type":"manzanas","items":["Mz 868","Mz 869","Mz 871","Mz 872","Mz 873","Mz 877","Mz 878","Mz 879","Mz 880"]},"89":{"type":"manzanas","items":["Mz 881","Mz 882","Mz 883","Mz 884","Mz 891","Mz 892","Mz 893","Mz 894"]},"90":{"type":"manzanas","items":["Mz 812","Mz 813","Mz 839","Mz 840","Mz 841","Mz 842","Mz 843","Mz 844","Mz 845","Mz 846","Mz 901","Mz 914","Mz 915"]},"91":{"type":"manzanas","items":["Mz 850","Mz 851","Mz 852","Mz 853","Mz 854","Mz 855","Mz 862","Mz 863","Mz 864"]},"92":{"type":"manzanas","items":["Mz 865","Mz 866","Mz 866a","Mz 867","Mz 874","Mz 875","Mz 876","Mz 885","Mz 886","Mz 887","Mz 888","Mz 889","Mz 890"]},"93":{"type":"manzanas","items":["Mz 6","Mz 805","Mz 806","Mz 807"]},"94":{"type":"manzanas","items":["Mz 3","Mz 802","Mz 803","Mz 809"]},"95":{"type":"manzanas","items":["Mz 6","Mz 62b","Mz 62c","Mz 62h"]},"96":{"type":"manzanas","items":["Mz 0","Mz 3","Mz 5"]},"97":{"type":"manzanas","items":["Mz 3","Mz 353","Mz 354","Mz 355"]},"98":{"type":"manzanas","items":["Mz 42c","Mz 341"]},"99":{"type":"manzanas","items":["Mz 358","Mz 359","Mz 366"]},"100":{"type":"tramos","items":["Avda. Costanera Pte. Néstor Carlos Kirchner","Calle 280","Calle 96","Calle 207","Calle 205","Calle S/NOMBRE"]},"101":{"type":"manzanas","items":["Mz 896"]},"102":{"type":"manzanas","items":["Mz 2","Mz 5","Mz 149","Mz 150","Mz 152","Mz 158","Mz 168a"]}},"hotspots":{"1":{"x":57.1786,"y":24.6038},"2":{"x":60.1796,"y":23.2026},"3":{"x":59.8622,"y":25.9271},"4":{"x":56.7087,"y":27.9391},"5":{"x":59.6802,"y":28.49},"6":{"x":64.7765,"y":25.8014},"7":{"x":56.1246,"y":23.9511},"8":{"x":51.5913,"y":28.6936},"9":{"x":48.7511,"y":26.3822},"10":{"x":48.4312,"y":22.6038},"11":{"x":51.2672,"y":19.0708},"12":{"x":47.5381,"y":18.4122},"13":{"x":50.2048,"y":14.987},"14":{"x":50.8355,"y":13.508},"15":{"x":50.9667,"y":12.011},"16":{"x":51.1445,"y":10.5798},"17":{"x":51.2672,"y":9.0768},"19":{"x":51.5974,"y":6.0948},"18":{"x":47.009,"y":5.1666},"20":{"x":52.7106,"y":11.1906},"21":{"x":55.0683,"y":6.9571},"22":{"x":54.954,"y":8.4062},"23":{"x":55.208,"y":11.4421},"24":{"x":59.572,"y":10.9271},"25":{"x":55.2545,"y":4.5499},"26":{"x":57.3413,"y":17.1607},"27":{"x":60.372,"y":19.5439},"28":{"x":62.3445,"y":20.981},"29":{"x":58.2683,"y":30.3762},"30":{"x":66.645,"y":14.2505},"31":{"x":68.1815,"y":14.6397},"32":{"x":70.2852,"y":14.1187},"33":{"x":70.9667,"y":18.3223},"34":{"x":72.918,"y":13.4361},"35":{"x":76.1688,"y":18.0888},"36":{"x":76.9603,"y":14.1906},"38":{"x":79.5339,"y":15.7954},"37":{"x":82.1201,"y":11.3104},"39":{"x":84.2831,"y":13.2205},"40":{"x":73.8111,"y":20.969},"41":{"x":78.882,"y":20.7595},"42":{"x":82.3191,"y":21.0708},"43":{"x":84.609,"y":25.5798},"44":{"x":86.5688,"y":29.6517},"45":{"x":78.3487,"y":26.9331},"46":{"x":77.4598,"y":29.5259},"47":{"x":71.2926,"y":22.8493},"48":{"x":68.0164,"y":23.5199},"49":{"x":68.1095,"y":27.2744},"50":{"x":75.081,"y":32.7595},"51":{"x":76.7572,"y":36.5139},"52":{"x":83.5042,"y":36.0409},"53":{"x":87.3773,"y":42.7535},"54":{"x":86.8947,"y":55.1786},"55":{"x":82.5603,"y":62.4601},"56":{"x":72.6386,"y":71.5738},"57":{"x":52.8672,"y":32.2086},"58":{"x":50.5349,"y":32.2145},"59":{"x":47.1826,"y":33.6397},"60":{"x":52.8164,"y":30.3163},"61":{"x":43.8979,"y":24.7475},"62":{"x":39.8725,"y":19.1846},"63":{"x":39.5593,"y":16.2684},"64":{"x":38.9963,"y":13.011},"65":{"x":37.0662,"y":10.6876},"66":{"x":36.2281,"y":15.7415},"67":{"x":32.2492,"y":14.975},"68":{"x":36.8587,"y":23.1906},"69":{"x":37.3498,"y":26.484},"70":{"x":33.8196,"y":29.1966},"71":{"x":35.9233,"y":29.7714},"72":{"x":33.5868,"y":33.8074},"73":{"x":36.3762,"y":33.0529},"74":{"x":38.827,"y":30.4062},"75":{"x":42.0101,"y":29.7654},"76":{"x":41.4725,"y":35.7774},"77":{"x":37.1593,"y":37.1966},"78":{"x":31.1021,"y":38.5199},"79":{"x":37.0704,"y":40.6816},"80":{"x":26.7085,"y":38.9391},"81":{"x":19.9191,"y":41.49},"82":{"x":14.0312,"y":44.1187},"83":{"x":7.9487,"y":46.4122},"84":{"x":27.9995,"y":45.3942},"85":{"x":29.2185,"y":45.3762},"86":{"x":30.7593,"y":45.5439},"87":{"x":33.3455,"y":46.1607},"88":{"x":32.7656,"y":49.8253},"89":{"x":32.5963,"y":54.3223},"90":{"x":34.446,"y":42.6577},"91":{"x":36.3889,"y":47.4241},"92":{"x":35.5,"y":53.3463},"93":{"x":38.6789,"y":49.6337},"94":{"x":38.8101,"y":54.8972},"95":{"x":56.5201,"y":32.2505},"96":{"x":66.9159,"y":30.4421},"97":{"x":48.9773,"y":39.8792},"98":{"x":52.9392,"y":40.993},"99":{"x":52.2238,"y":42.7535},"100":{"x":46.2278,"y":45.9032},"101":{"x":42.1601,"y":52.975},"102":{"x":45.2373,"y":35.2205}},"refs":{"1":["JW","FLIA RODRIGUEZ","PUNTA BANDERA","RIO SANTA CRUZ","LAGO ARGENTINO","REIMUNDO FREILE","AVDA. GENERAL JUAN DOMINGO PERON","CTE. LUIS PIEDRABUENA","CERRO CALAFATE","AVDA. 17 DE OCTUBRE"],"100":["PLANTA TRATAMIENTO","Qta. 64","Qta. 69","QTA 11a","QTA 11b","Avda. Costanera Pte. Néstor Carlos Kirchner","Calle 96","Calle 207","Calle 209","Calle 205","Calle S/NOMBRE"],"102":["ALMIRANTE GUILLERMO BROWN","CALLE 409","CALLE LAGO POSADAS","CORONEL DE MARINA LEONARDO ROSALES","LAS HERAS (EX 406)","PUERTO DESEADO","Psje. Peatonal N° 115","CALETA OLIVIA"]},"source":{"mapFile":"MAPA - CONG CALAFATE 2026","territoryRange":"1-102","embeddedLabel":"MAPA DE TERRITORIO 2023 - CONG CALAFATE 12310"}};
/* V1.5.0 · Territorios oficiales interactivos · fuente: planos originales */
(()=>{
'use strict';
const CEC_TERRITORY_V150=true;
const OFFICIAL=window.CongTerritoryOfficialData||{};
const DATA=OFFICIAL.data||{};
const HOT=OFFICIAL.hotspots||{};
const SOURCE_REFS=OFFICIAL.refs||{};
const STATE_KEY='cec_territory_official_v150';
const OLD_KEY='cec_territory_control_v1';
const MAP_ASSET='territory-map-2026.png';
const SOURCE_FOLDER='https://drive.google.com/drive/folders/1HBsAoYwTSjm5hyrltsPDbI3ayuGhxK1m';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let state=loadState(),current='1',zoom=1,expanded=null;

function loadState(){
  let out={};
  try{out=JSON.parse(localStorage.getItem(STATE_KEY)||'{}')||{};}catch(_){out={};}
  if(!localStorage.getItem(STATE_KEY)){
    try{
      const old=JSON.parse(localStorage.getItem(OLD_KEY)||'{}')||{};
      Object.entries(old).forEach(([n,t])=>{
        out[n]=out[n]||{};
        out[n].driver=t.driver||'';
        out[n].date=t.date||'';
        out[n].notes=t.notes||'';
        out[n].extras=(t.streets||[]).map(x=>({name:x.name||'Tramo anterior',done:!!x.done}));
      });
    }catch(_){}
    save(out);
  }
  return out;
}
function save(v=state){localStorage.setItem(STATE_KEY,JSON.stringify(v));}
function ts(n=current){
  if(!state[n]) state[n]={driver:'',date:'',notes:'',done:{},labels:{},extras:[],updatedAt:''};
  const t=state[n];
  t.done=t.done||{}; t.labels=t.labels||{}; t.extras=Array.isArray(t.extras)?t.extras:[];
  return t;
}
function touch(t=ts()){t.updatedAt=new Date().toISOString();save();}
function sideKey(item,side){return item+'::'+side;}
function metrics(n=current){
  const d=DATA[n],t=ts(n); if(!d)return{done:0,total:0,pct:0};
  let keys=[];
  if(d.type==='tramos') keys=d.items.map(x=>sideKey(x,'territorio'));
  else d.items.forEach(x=>['N','E','S','O'].forEach(s=>keys.push(sideKey(x,s))));
  const done=keys.filter(k=>!!t.done[k]).length,total=keys.length;
  return{done,total,pct:total?Math.round(done*100/total):0};
}
function installStyle(){
  if(document.getElementById('cec-v150-style'))return;
  const s=document.createElement('style');
  s.id='cec-v150-style';
  s.textContent=`
.territory-control-card.cec-v150{padding:0!important;background:transparent!important;border:0!important;box-shadow:none!important}
.cec-t15{display:grid;gap:14px}
.cec-t15-top,.cec-map-card,.cec-territory-panel{background:#fff;border:1px solid #dbe7ec;border-radius:24px;box-shadow:0 8px 24px rgba(18,61,78,.06)}
.cec-t15-top,.cec-territory-panel{padding:16px}
.cec-t15-head{display:flex;justify-content:space-between;align-items:flex-start;gap:12px}.cec-t15-head h2{margin:2px 0 0;font-size:22px;color:#133d52}
.cec-t15-badge{padding:7px 11px;border-radius:999px;font-weight:800;font-size:12px;background:#eef3f5;color:#5a707a;white-space:nowrap}.cec-t15-badge[data-state="active"]{background:#fff2d8;color:#8a5b00}.cec-t15-badge[data-state="done"]{background:#dff4e8;color:#176b45}
.cec-t15-fields{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:12px}.cec-t15-fields label:first-child{grid-column:1/-1}.cec-t15-fields label span,.cec-t15-notes span{display:block;font-size:11px;font-weight:800;letter-spacing:.04em;color:#6e8792;margin:0 0 5px}.cec-t15-fields input,.cec-t15-fields select,.cec-t15-notes textarea{width:100%;border:1px solid #d9e5ea;border-radius:13px;padding:11px 12px;background:#fbfdfe;color:#15394a;font:inherit;box-sizing:border-box}
.cec-t15-progress{margin-top:12px}.cec-t15-progress-meta{display:flex;justify-content:space-between;font-size:12px;color:#58727e;margin-bottom:6px}.cec-t15-track{height:9px;background:#edf3f5;border-radius:99px;overflow:hidden}.cec-t15-track i{display:block;height:100%;width:0;background:#147a5b;border-radius:99px;transition:.25s}
.cec-map-card{overflow:hidden}.cec-map-tools{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:12px 14px;border-bottom:1px solid #e4edf1}.cec-map-tools strong{color:#153f54}.cec-map-tools small{display:block;color:#78909a;margin-top:2px}.cec-zoom{display:flex;gap:6px}.cec-zoom button{width:38px;height:38px;border:1px solid #d4e2e8;background:#f7fafb;border-radius:12px;font-weight:900;font-size:20px;color:#24536a}
.cec-map-scroll{height:390px;overflow:auto;background:#f3f7f8;overscroll-behavior:contain}.cec-map-stage{position:relative;width:100%;min-width:100%;transition:width .2s}.cec-map-stage img{display:block;width:100%;height:auto;user-select:none}
.cec-hot{position:absolute;transform:translate(-50%,-50%);min-width:29px;height:29px;padding:0 5px;border:2px solid rgba(255,255,255,.95);border-radius:999px;background:#667c86;color:#fff;font-size:11px;font-weight:900;box-shadow:0 2px 5px rgba(0,0,0,.25);display:flex;align-items:center;justify-content:center}.cec-hot.partial{background:#d08a18}.cec-hot.done{background:#16835d}.cec-hot.selected{background:#0b5fa5;outline:3px solid rgba(11,95,165,.23);z-index:3}
.cec-map-legend{display:flex;gap:12px;flex-wrap:wrap;padding:9px 14px;border-top:1px solid #e5eef1;font-size:11px;color:#667d87}.cec-map-legend span:before{content:'';display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:4px;background:#667c86}.cec-map-legend .lpart:before{background:#d08a18}.cec-map-legend .ldone:before{background:#16835d}.cec-map-note{padding:0 14px 12px;font-size:11px;color:#78909a}
.cec-territory-title{display:flex;justify-content:space-between;gap:10px;align-items:center;margin-bottom:10px}.cec-territory-title h3{margin:0;color:#163d51;font-size:18px}.cec-territory-title span{font-size:12px;color:#78909a}
.cec-ref-box{background:#f5faf8;border:1px solid #d9ece4;border-radius:16px;padding:10px 12px;margin:10px 0}.cec-ref-box strong{font-size:12px;color:#1e664e}.cec-ref-chips{display:flex;gap:6px;flex-wrap:wrap;margin-top:7px}.cec-ref-chips span{padding:5px 8px;border-radius:999px;background:#fff;border:1px solid #d7e9e2;font-size:11px;color:#41675a}
.cec-mz-list{display:grid;gap:8px}.cec-mz{border:1px solid #dce7ec;border-radius:16px;overflow:hidden;background:#fbfdfe}.cec-mz-head{width:100%;border:0;background:transparent;padding:12px;display:flex;align-items:center;justify-content:space-between;text-align:left;color:#15394a;font-weight:800}.cec-mz-head span{display:flex;align-items:center;gap:9px}.cec-mz-head em{font-style:normal;font-size:11px;color:#6b838e;font-weight:700}.cec-mz-body{padding:0 10px 10px;display:none}.cec-mz.open .cec-mz-body{display:grid;gap:7px}
.cec-side{display:grid;grid-template-columns:42px 1fr auto;gap:8px;align-items:center;border:1px solid #e0e9ed;border-radius:13px;padding:8px;background:#fff}.cec-side.done{background:#eef9f4;border-color:#b9e3d2}.cec-side b{font-size:12px;color:#49636e}.cec-side input[type=text]{min-width:0;border:0;background:transparent;outline:0;color:#284b5a;font-size:12px;padding:7px}.cec-side button{border:0;border-radius:10px;padding:8px 10px;background:#eaf1f4;color:#47616c;font-weight:800}.cec-side.done button{background:#16835d;color:#fff}
.cec-tramo{display:grid;grid-template-columns:1fr auto;gap:8px;align-items:center;border:1px solid #dce7ec;border-radius:14px;padding:11px;background:#fbfdfe}.cec-tramo.done{background:#eef9f4;border-color:#b9e3d2}.cec-tramo strong{color:#173e52;font-size:13px}.cec-tramo small{display:block;color:#758c96;margin-top:2px}.cec-tramo button{border:0;border-radius:11px;padding:9px 11px;background:#eaf1f4;color:#47616c;font-weight:800}.cec-tramo.done button{background:#16835d;color:#fff}
.cec-extra{margin-top:12px;border-top:1px solid #e6eef1;padding-top:12px}.cec-extra-add{display:grid;grid-template-columns:1fr auto;gap:8px}.cec-extra-add input{border:1px solid #d9e5ea;border-radius:12px;padding:10px}.cec-extra-add button{border:0;border-radius:12px;background:#164f68;color:#fff;font-weight:800;padding:0 13px}.cec-extra-list{display:grid;gap:6px;margin-top:8px}.cec-extra-row{display:flex;gap:8px;align-items:center;border:1px solid #e1e9ed;border-radius:12px;padding:8px 10px}.cec-extra-row span{flex:1;font-size:12px;color:#3e5c69}.cec-extra-row button{border:0;background:transparent;font-weight:900;color:#7c919a}
.cec-t15-notes{display:block;margin-top:12px}.cec-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}.cec-actions button,.cec-source-btn{border:1px solid #d5e2e8;background:#f8fbfc;border-radius:12px;padding:9px 11px;font-weight:800;color:#345a6b;text-decoration:none;font-size:12px}.cec-actions .danger{color:#9a3b3b;background:#fff7f7;border-color:#efd5d5}.cec-local-note{font-size:11px;color:#78909a;margin:9px 2px 0}
@media(max-width:520px){.cec-map-scroll{height:340px}.cec-t15-fields{grid-template-columns:1fr}.cec-t15-fields label:first-child{grid-column:auto}.cec-side{grid-template-columns:38px 1fr auto}}
`;
  document.head.appendChild(s);
}
function mount(){
  const card=document.querySelector('.territory-control-card'); if(!card)return;
  installStyle(); card.classList.add('cec-v150');
  card.innerHTML=`<div class="cec-t15">
    <section class="cec-t15-top">
      <div class="cec-t15-head"><div><p class="section-kicker">MAPA OFICIAL · CONTROL POR LADO</p><h2>Territorios 1–102</h2></div><span id="t15Badge" class="cec-t15-badge">Sin iniciar</span></div>
      <div class="cec-t15-fields"><label><span>Territorio</span><select id="t15Select"></select></label><label><span>Conductor</span><input id="t15Driver" autocomplete="off" placeholder="Nombre"></label><label><span>Fecha</span><input id="t15Date" type="date"></label></div>
      <div class="cec-t15-progress"><div class="cec-t15-progress-meta"><span id="t15ProgressLabel"></span><strong id="t15Pct">0%</strong></div><div class="cec-t15-track"><i id="t15Bar"></i></div></div>
    </section>
    <section class="cec-map-card">
      <div class="cec-map-tools"><div><strong>Mapa de territorios</strong><small>Fuente original de la congregación · archivo disponible en 2026</small></div><div class="cec-zoom"><button id="t15Minus" aria-label="Alejar">−</button><button id="t15Plus" aria-label="Acercar">+</button></div></div>
      <div id="t15MapScroll" class="cec-map-scroll"><div id="t15MapStage" class="cec-map-stage"><img src="${MAP_ASSET}" alt="Mapa oficial de territorios de El Calafate"><div id="t15Hotspots"></div></div></div>
      <div class="cec-map-legend"><span>Sin iniciar</span><span class="lpart">En curso</span><span class="ldone">Completado</span></div>
      <div class="cec-map-note">El archivo disponible en la carpeta 2026 conserva dentro del plano el rótulo “Mapa de territorio 2023”. No se altera el original.</div>
    </section>
    <section class="cec-territory-panel">
      <div class="cec-territory-title"><h3 id="t15Title">Territorio 1</h3><span id="t15Count"></span></div>
      <div id="t15Refs"></div><div id="t15Items"></div>
      <div class="cec-extra"><strong style="font-size:12px;color:#345a6b">Lado/tramo especial</strong><div class="cec-extra-add"><input id="t15ExtraInput" placeholder="Ej.: lado de calle sin nombre / vivienda aislada"><button id="t15ExtraAdd">Añadir</button></div><div id="t15ExtraList" class="cec-extra-list"></div></div>
      <label class="cec-t15-notes"><span>Observaciones</span><textarea id="t15Notes" rows="3" placeholder="Referencias, viviendas pendientes, horario para volver..."></textarea></label>
      <div class="cec-actions"><a class="cec-source-btn" href="${SOURCE_FOLDER}">Ver originales</a><button id="t15MarkAll">Marcar todo</button><button id="t15Unmark">Desmarcar</button><button id="t15Reset" class="danger">Reiniciar territorio</button></div>
      <p class="cec-local-note">Guardado en este teléfono. En calles que limitan con otro territorio, se registra únicamente el lado perteneciente al territorio seleccionado.</p>
    </section>
  </div>`;
  const sel=document.getElementById('t15Select');
  sel.innerHTML=Array.from({length:102},(_,i)=>`<option value="${i+1}">Territorio ${i+1}</option>`).join('');
  sel.value=current;
  sel.addEventListener('change',()=>select(sel.value,true));
  document.getElementById('t15Driver').addEventListener('input',e=>{const t=ts();t.driver=e.target.value;touch(t)});
  document.getElementById('t15Date').addEventListener('change',e=>{const t=ts();t.date=e.target.value;touch(t)});
  document.getElementById('t15Notes').addEventListener('input',e=>{const t=ts();t.notes=e.target.value;touch(t)});
  document.getElementById('t15Plus').onclick=()=>setZoom(zoom+.25);
  document.getElementById('t15Minus').onclick=()=>setZoom(zoom-.25);
  document.getElementById('t15ExtraAdd').onclick=addExtra;
  document.getElementById('t15MarkAll').onclick=()=>markAll(true);
  document.getElementById('t15Unmark').onclick=()=>markAll(false);
  document.getElementById('t15Reset').onclick=reset;
  renderHot(); select(current,false);
  const oldTitle=document.querySelector('.territory-resources-title .section-kicker');
  if(oldTitle)oldTitle.textContent='Documentos, planillas y otros recursos';
}
function renderHot(){
  const root=document.getElementById('t15Hotspots');
  root.innerHTML=Object.entries(HOT).map(([n,p])=>`<button class="cec-hot" data-territory="${n}" style="left:${p.x}%;top:${p.y}%">${n}</button>`).join('');
  root.querySelectorAll('button').forEach(b=>b.onclick=()=>select(b.dataset.territory,true));
  updateHot();
}
function updateHot(){
  document.querySelectorAll('.cec-hot').forEach(b=>{
    const m=metrics(b.dataset.territory);
    b.className='cec-hot'+(m.pct===100?' done':m.done?' partial':'')+(b.dataset.territory===current?' selected':'');
  });
}
function setZoom(v){zoom=Math.max(1,Math.min(3,v));const stage=document.getElementById('t15MapStage');if(stage)stage.style.width=(zoom*100)+'%';}
function focusMap(){
  const b=document.querySelector(`.cec-hot[data-territory="${current}"]`),sc=document.getElementById('t15MapScroll');
  if(!b||!sc)return;
  setTimeout(()=>sc.scrollTo({left:Math.max(0,b.offsetLeft-sc.clientWidth/2),top:Math.max(0,b.offsetTop-sc.clientHeight/2),behavior:'smooth'}),80);
}
function select(n,focus){
  current=String(n); expanded=null;
  document.getElementById('t15Select').value=current;
  const t=ts();
  document.getElementById('t15Driver').value=t.driver||'';
  document.getElementById('t15Date').value=t.date||'';
  document.getElementById('t15Notes').value=t.notes||'';
  render();
  if(focus){setZoom(1.75);focusMap();}
}
function render(){
  const d=DATA[current],m=metrics();
  document.getElementById('t15Title').textContent='Territorio '+current;
  document.getElementById('t15Count').textContent=d.type==='tramos'?`${d.items.length} tramos oficiales`:`${d.items.length} manzanas · ${m.total} lados`;
  document.getElementById('t15ProgressLabel').textContent=`${m.done} de ${m.total} lados/tramos`;
  document.getElementById('t15Pct').textContent=m.pct+'%';
  document.getElementById('t15Bar').style.width=m.pct+'%';
  const badge=document.getElementById('t15Badge');
  badge.textContent=m.pct===100?'Completado':m.done?'En curso':'Sin iniciar';
  badge.dataset.state=m.pct===100?'done':m.done?'active':'empty';
  renderRefs(); renderItems(); renderExtras(); updateHot();
}
function renderRefs(){
  const root=document.getElementById('t15Refs'),r=SOURCE_REFS[current]||[];
  root.innerHTML=`<div class="cec-ref-box"><strong>Referencias del original</strong><div class="cec-ref-chips">${r.length?r.map(x=>`<span>${esc(x)}</span>`).join(''):'<span>Las referencias se conservan visibles en el plano oficial.</span>'}</div></div>`;
}
function renderItems(){
  const root=document.getElementById('t15Items'),d=DATA[current],t=ts();
  if(d.type==='tramos'){
    root.className='cec-mz-list';
    root.innerHTML=d.items.map(item=>{
      const k=sideKey(item,'territorio'),done=!!t.done[k];
      return `<div class="cec-tramo ${done?'done':''}"><div><strong>${esc(item)}</strong><small>Marcar únicamente el lado que pertenece al Territorio 100.</small></div><button data-tramo="${esc(item)}">${done?'✓ Hecho':'Marcar'}</button></div>`;
    }).join('');
    root.querySelectorAll('[data-tramo]').forEach(b=>b.onclick=()=>toggle(sideKey(b.dataset.tramo,'territorio')));
    return;
  }
  root.className='cec-mz-list';
  root.innerHTML=d.items.map((item,idx)=>{
    let done=0;['N','E','S','O'].forEach(s=>done+=t.done[sideKey(item,s)]?1:0);
    const open=expanded===idx;
    return `<div class="cec-mz ${open?'open':''}"><button class="cec-mz-head" data-open="${idx}"><span>${esc(item)} <em>${done}/4 lados</em></span><b>${open?'⌃':'⌄'}</b></button><div class="cec-mz-body">${['N','E','S','O'].map(s=>sideRow(item,s)).join('')}</div></div>`;
  }).join('');
  root.querySelectorAll('[data-open]').forEach(b=>b.onclick=()=>{const i=Number(b.dataset.open);expanded=expanded===i?null:i;renderItems();});
  root.querySelectorAll('[data-side-toggle]').forEach(b=>b.onclick=()=>toggle(b.dataset.sideToggle));
  root.querySelectorAll('[data-label-key]').forEach(inp=>inp.onchange=()=>{t.labels[inp.dataset.labelKey]=inp.value.trim();touch(t)});
}
function sideRow(item,s){
  const t=ts(),k=sideKey(item,s),done=!!t.done[k],label=t.labels[k]||'',names={N:'Norte',E:'Este',S:'Sur',O:'Oeste'};
  return `<div class="cec-side ${done?'done':''}"><b>${names[s]}</b><input type="text" data-label-key="${esc(k)}" value="${esc(label)}" placeholder="Calle / referencia de este lado"><button data-side-toggle="${esc(k)}">${done?'✓':'Marcar'}</button></div>`;
}
function toggle(k){const t=ts();t.done[k]=!t.done[k];touch(t);render();}
function markAll(v){
  const d=DATA[current],t=ts();
  if(d.type==='tramos')d.items.forEach(x=>t.done[sideKey(x,'territorio')]=v);
  else d.items.forEach(x=>['N','E','S','O'].forEach(s=>t.done[sideKey(x,s)]=v));
  touch(t);render();
}
function addExtra(){
  const input=document.getElementById('t15ExtraInput'),name=(input.value||'').trim().replace(/\s+/g,' ');
  if(!name)return;
  const t=ts();t.extras.push({name,done:false});input.value='';touch(t);renderExtras();
}
function renderExtras(){
  const root=document.getElementById('t15ExtraList'),t=ts();
  root.innerHTML=t.extras.map((x,i)=>`<div class="cec-extra-row"><input type="checkbox" data-extra-check="${i}" ${x.done?'checked':''}><span>${esc(x.name)}</span><button data-extra-remove="${i}">×</button></div>`).join('');
  root.querySelectorAll('[data-extra-check]').forEach(x=>x.onchange=()=>{t.extras[+x.dataset.extraCheck].done=x.checked;touch(t)});
  root.querySelectorAll('[data-extra-remove]').forEach(x=>x.onclick=()=>{t.extras.splice(+x.dataset.extraRemove,1);touch(t);renderExtras()});
}
function reset(){
  if(!confirm(`¿Reiniciar el Territorio ${current}? Se borrará el progreso de lados/tramos guardado en este teléfono.`))return;
  const keep={driver:ts().driver||'',date:ts().date||''};
  state[current]={driver:keep.driver,date:keep.date,notes:'',done:{},labels:{},extras:[],updatedAt:new Date().toISOString()};
  save(); select(current,false);
}
mount();
window.CongElCalafateTerritoriosV150={version:'1.5.0',data:DATA,hotspots:HOT,select};
})();
/* V1.5.0 · mapa oficial: selector preciso sin hotspots estimados */
(()=>{
'use strict';
const api=window.CongElCalafateTerritoriosV150;
const root=document.querySelector('.cec-t15');
if(!api||!root)return;
const hot=document.getElementById('t15Hotspots');
if(hot){hot.innerHTML='';hot.style.display='none';}
const style=document.createElement('style');
style.id='cec-v150-map-grid-style';
style.textContent=`
.cec-territory-grid-wrap{padding:12px 14px;border-bottom:1px solid #e5eef1;background:#fbfdfe}.cec-territory-grid-head{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:9px}.cec-territory-grid-head strong{font-size:12px;color:#365d6e}.cec-territory-grid-head small{font-size:10px;color:#82959d;text-align:right}.cec-territory-grid{display:grid;grid-template-columns:repeat(12,minmax(0,1fr));gap:5px}.cec-tgrid{height:29px;border:1px solid #d9e4e8;border-radius:8px;background:#f0f4f6;color:#516a75;font-size:10px;font-weight:900;padding:0}.cec-tgrid.partial{background:#fff1d5;border-color:#efd7a3;color:#94620b}.cec-tgrid.done{background:#e3f5ec;border-color:#b9dfcf;color:#17704d}.cec-tgrid.selected{outline:2px solid #0b5fa5;outline-offset:1px;background:#e5f1fb;color:#0b5fa5}.cec-map-legend{border-top:0!important}.cec-map-note{padding-top:2px!important}.cec-map-stage:after{content:'Mapa oficial · use zoom e deslice para revisar calles y referencias';position:absolute;left:10px;bottom:10px;background:rgba(255,255,255,.9);border:1px solid #dce6ea;border-radius:9px;padding:5px 8px;font-size:9px;color:#5d747e;pointer-events:none}@media(max-width:520px){.cec-territory-grid{grid-template-columns:repeat(9,minmax(0,1fr));gap:4px}.cec-tgrid{height:28px;font-size:9px}}
`;
document.head.appendChild(style);
const mapCard=document.querySelector('.cec-map-card');
const mapScroll=document.getElementById('t15MapScroll');
const wrap=document.createElement('div');
wrap.className='cec-territory-grid-wrap';
wrap.innerHTML='<div class="cec-territory-grid-head"><strong>Elegir territorio</strong><small>El número seleccionado corresponde al plano original</small></div><div id="cecTerritoryGrid" class="cec-territory-grid"></div>';
if(mapCard&&mapScroll)mapCard.insertBefore(wrap,mapScroll);
const grid=document.getElementById('cecTerritoryGrid');
function state(){try{return JSON.parse(localStorage.getItem('cec_territory_official_v150')||'{}')||{};}catch(_){return{};}}
function metric(n){
 const d=api.data[String(n)],t=state()[String(n)]||{},done=t.done||{};if(!d)return{d:0,t:0};
 const keys=[];
 if(d.type==='tramos')d.items.forEach(x=>keys.push(x+'::territorio'));
 else d.items.forEach(x=>['N','E','S','O'].forEach(s=>keys.push(x+'::'+s)));
 return{d:keys.filter(k=>done[k]).length,t:keys.length};
}
function selected(){const s=document.getElementById('t15Select');return s?String(s.value):'1';}
function paint(){
 if(!grid)return;
 const sel=selected();
 Array.from(grid.children).forEach(b=>{const m=metric(b.dataset.n);b.className='cec-tgrid'+(m.t&&m.d===m.t?' done':m.d?' partial':'')+(b.dataset.n===sel?' selected':'');});
}
if(grid){
 grid.innerHTML=Array.from({length:102},(_,i)=>`<button class="cec-tgrid" data-n="${i+1}" aria-label="Territorio ${i+1}">${i+1}</button>`).join('');
 grid.querySelectorAll('button').forEach(b=>b.onclick=()=>{api.select(b.dataset.n,false);paint();document.querySelector('.cec-territory-panel')?.scrollIntoView({behavior:'smooth',block:'start'});});
}
const legend=document.querySelector('.cec-map-legend');
if(legend)legend.innerHTML='<span>Sin iniciar</span><span class="lpart">En curso</span><span class="ldone">Completado</span><span style="margin-left:auto">Los colores se aplican al selector, no alteran el plano original.</span>';
const note=document.querySelector('.cec-map-note');
if(note)note.textContent='Plano original disponible en la carpeta 2026. El archivo conserva internamente el rótulo “Mapa de territorio 2023”. Se muestra sin redibujar límites ni calles.';
const obs=new MutationObserver(paint);
['t15Title','t15Pct','t15Badge'].forEach(id=>{const el=document.getElementById(id);if(el)obs.observe(el,{childList:true,characterData:true,subtree:true,attributes:true});});
paint();
window.CongElCalafateTerritoriosMapGridV150={version:'1.5.0',paint};
})();
/* V1.6.0 · agenda útil: oculta días/horarios pasados por defecto */
;(function(){
'use strict';
const VERSION='1.6.0';
const DAY_INDEX={lunes:0,martes:1,miercoles:2,jueves:3,viernes:4,sabado:5,domingo:6};
const DAY_SHORT={lunes:'Lun',martes:'Mar',miercoles:'Mié',jueves:'Jue',viernes:'Vie',sabado:'Sáb',domingo:'Dom'};
const $=(s,r=document)=>r.querySelector(s);
const $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
let showAll=false,scheduled=false,autoSwitching=false;

function injectStyle(){
 if($('#cecV160CarritosStyle'))return;
 const s=document.createElement('style');s.id='cecV160CarritosStyle';s.textContent=`
 #cecShowPast{white-space:nowrap}.cec-day-date{display:block;font-size:9px;opacity:.68;margin-top:2px;font-weight:750}.cec-chip.cec-day-today{box-shadow:inset 0 0 0 2px rgba(11,79,108,.12)}.cec-chip.active .cec-day-date{opacity:.8}.cec-v160-hidden{display:none!important}.cec-next-note{background:#fff;border:1px dashed #c9dae1;border-radius:16px;padding:18px;text-align:center;color:#647d88;font-size:12px;line-height:1.45}
 @media(max-width:430px){.cec-c-tools{flex-wrap:wrap}.cec-c-search{flex:1 1 100%}.cec-c-toggle{flex:1}.cec-c-toggle#cecShowPast{flex:1}}
 `;document.head.appendChild(s);
}
function installButton(){
 const tools=$('.cec-c-tools');if(!tools||$('#cecShowPast'))return;
 const b=document.createElement('button');b.type='button';b.id='cecShowPast';b.className='cec-c-toggle';b.textContent='Mostrar todos';b.onclick=()=>{showAll=!showAll;b.classList.toggle('active',showAll);b.textContent=showAll?'Ver próximos':'Mostrar todos';schedulePatch();};
 tools.appendChild(b);
}
function mondayOf(date){
 const d=new Date(date);d.setHours(0,0,0,0);const day=d.getDay(),diff=(day+6)%7;d.setDate(d.getDate()-diff);return d;
}
function dateForDay(day){
 const m=mondayOf(new Date()),d=new Date(m);d.setDate(m.getDate()+(DAY_INDEX[day]??0));return d;
}
function sameDay(a,b){return a.getFullYear()===b.getFullYear()&&a.getMonth()===b.getMonth()&&a.getDate()===b.getDate();}
function pastDay(day){
 const d=dateForDay(day),today=new Date();today.setHours(0,0,0,0);return d<today;
}
function todayDayKey(){
 const keys=['domingo','lunes','martes','miercoles','jueves','viernes','sabado'];return keys[new Date().getDay()];
}
function endMinutes(text){
 const m=[...String(text||'').matchAll(/(\d{1,2})(?::(\d{2}))?/g)];if(!m.length)return null;
 const z=m[m.length-1],h=Number(z[1]),min=Number(z[2]||0);if(h>23||min>59)return null;return h*60+min;
}
function formatDate(d){return String(d.getDate()).padStart(2,'0')+'/'+String(d.getMonth()+1).padStart(2,'0');}
function patchDays(){
 const root=$('#cecCarritosDays');if(!root)return;
 const now=new Date(),today=todayDayKey();
 $$('[data-cec-day]',root).forEach(b=>{
   const day=b.dataset.cecDay,d=dateForDay(day),isToday=day===today;
   b.classList.toggle('cec-day-today',isToday);
   b.classList.toggle('cec-v160-hidden',!showAll&&pastDay(day));
   const label=DAY_SHORT[day]||day;
   b.innerHTML=`${isToday?'Hoy · ':''}${label}<span class="cec-day-date">${formatDate(d)}</span>`;
 });
 if(!showAll){
   const active=$('[data-cec-day].active',root);
   if(active?.classList.contains('cec-v160-hidden'))switchToFirstVisibleDay(root);
 }
}
function switchToFirstVisibleDay(root=$('#cecCarritosDays'),afterToday=false){
 if(autoSwitching||!root)return false;
 const todayIdx=DAY_INDEX[todayDayKey()];
 const candidates=$$('[data-cec-day]',root).filter(b=>!b.classList.contains('cec-v160-hidden')).filter(b=>!afterToday||(DAY_INDEX[b.dataset.cecDay]??0)>todayIdx);
 if(!candidates.length)return false;
 autoSwitching=true;candidates[0].click();setTimeout(()=>{autoSwitching=false;schedulePatch();},80);return true;
}
function patchShifts(){
 const root=$('#cecCarritosShifts'),days=$('#cecCarritosDays');if(!root||!days)return;
 $('#cecFutureEmpty')?.remove();
 const active=$('[data-cec-day].active',days),day=active?.dataset.cecDay||'',today=todayDayKey(),now=new Date(),mins=now.getHours()*60+now.getMinutes();
 const arts=$$('.cec-shift',root);
 let visible=0;
 arts.forEach(a=>{
   let hide=false;
   if(!showAll&&day===today){
     const t=$('.cec-shift-time',a)?.textContent||'',end=endMinutes(t);hide=end!==null&&end<=mins;
   }
   a.classList.toggle('cec-v160-hidden',hide);if(!hide)visible++;
 });
 if(!showAll&&day===today&&arts.length&&visible===0){
   if(switchToFirstVisibleDay(days,true))return;
   const note=document.createElement('div');note.id='cecFutureEmpty';note.className='cec-next-note';note.innerHTML='<strong>No quedan turnos futuros visibles esta semana.</strong><br>Use “Mostrar todos” para consultar días y horarios anteriores.';root.appendChild(note);
 }
}
function patch(){
 scheduled=false;injectStyle();installButton();patchDays();patchShifts();
 const screen=$('#cecCarritosScreen');if(screen?.classList.contains('open')&&!showAll){
   const days=$('#cecCarritosDays'),active=$('[data-cec-day].active',days);
   if(active?.classList.contains('cec-v160-hidden'))switchToFirstVisibleDay(days);
 }
}
function schedulePatch(){if(scheduled)return;scheduled=true;requestAnimationFrame(patch);}
function observe(){
 const target=$('#cecCarritosScreen');if(!target)return setTimeout(observe,100);
 const obs=new MutationObserver(()=>schedulePatch());obs.observe(target,{subtree:true,childList:true,attributes:true,attributeFilter:['class']});schedulePatch();
}
injectStyle();observe();setInterval(schedulePatch,60000);
const patchAbout=()=>{const strong=$('.about-card strong');if(strong)strong.textContent='Aplicación v1.6.0 · agenda de carritos y control de territorios';const p=$('.about-card p');if(p)p.textContent='Por defecto se muestran solamente días y horarios todavía útiles. “Mostrar todos” permite consultar la escala completa.';};setTimeout(patchAbout,800);
window.CongElCalafateCarritosV160={version:VERSION,refresh:schedulePatch,get showAll(){return showAll;}};
})();
/* V1.6.2 · informe infográfico + termómetro general y por territorio */
(()=>{
'use strict';
const VERSION='1.6.2';
const api=window.CongElCalafateTerritoriosV150,OFF=window.CongTerritoryOfficialData||{};if(!api||!OFF.data)return;
const DATA=OFF.data,STATE_KEY='cec_territory_official_v150';
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const sideKey=(i,s)=>i+'::'+s;let filter='all';
function state(){try{return JSON.parse(localStorage.getItem(STATE_KEY)||'{}')||{};}catch(_){return{};}}
function metric(n){n=String(n);const d=DATA[n],done=state()[n]?.done||{},keys=[];if(!d)return{done:0,total:0,pct:0};if(d.type==='tramos')d.items.forEach(x=>keys.push(sideKey(x,'territorio')));else d.items.forEach(x=>['N','E','S','O'].forEach(s=>keys.push(sideKey(x,s))));const c=keys.filter(k=>done[k]).length;return{done:c,total:keys.length,pct:keys.length?Math.round(c*100/keys.length):0};}
function aggregate(){let done=0,total=0,completed=0,active=0,empty=0;const rows=[];for(let n=1;n<=102;n++){const m=metric(n);done+=m.done;total+=m.total;if(m.pct===100&&m.total)completed++;else if(m.done)active++;else empty++;rows.push({n,...m});}return{done,total,pct:total?Math.round(done*100/total):0,completed,active,empty,rows};}
function inject(){if($('#cecV162ReportStyle'))return;const s=document.createElement('style');s.id='cecV162ReportStyle';s.textContent=`
.cec-v162-report-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}.cec-v162-report-btn{border:0;border-radius:13px;background:#0b5fa5;color:#fff;font-weight:900;padding:10px 13px}.cec-v162-mini{display:flex;align-items:center;gap:10px;margin-top:10px;padding:10px 12px;border:1px solid #dce7eb;border-radius:15px;background:#fbfdfe}.cec-v162-mini-t{width:14px;height:44px;border:2px solid #52707d;border-radius:9px;position:relative;background:#edf3f5;flex:0 0 auto}.cec-v162-mini-t:after{content:'';position:absolute;width:20px;height:20px;border-radius:50%;background:#52707d;left:50%;bottom:-8px;transform:translateX(-50%)}.cec-v162-mini-t i{position:absolute;z-index:1;left:2px;right:2px;bottom:2px;background:#16835d;border-radius:6px}.cec-v162-mini strong{display:block;color:#173e52;font-size:13px}.cec-v162-mini small{display:block;color:#728994;font-size:11px;margin-top:2px}
#cecV162Report{position:fixed;inset:0;z-index:9300;background:#f3f7f9;color:#183746;display:none;overflow:auto}#cecV162Report.open{display:block}.cec-v162-rhead{position:sticky;top:0;z-index:3;display:flex;align-items:center;gap:10px;background:#103f57;color:#fff;padding:10px 12px}.cec-v162-rback{width:44px;height:44px;border:0;border-radius:13px;background:rgba(255,255,255,.13);color:#fff;font-size:28px}.cec-v162-rhead div{flex:1}.cec-v162-rhead small{display:block;font-size:9px;opacity:.7;font-weight:900;letter-spacing:.08em}.cec-v162-rhead strong{display:block;font-size:18px}.cec-v162-rwrap{max-width:850px;margin:auto;padding:14px}.cec-v162-hero{display:grid;grid-template-columns:82px 1fr;align-items:center;gap:14px;padding:18px;border-radius:24px;background:linear-gradient(135deg,#0b4f6c,#16789e);color:#fff}.cec-v162-thermo{width:38px;height:126px;border:4px solid #fff;border-radius:25px;position:relative;margin:auto;background:rgba(255,255,255,.14)}.cec-v162-thermo:after{content:'';position:absolute;width:54px;height:54px;border-radius:50%;background:#fff;left:50%;bottom:-24px;transform:translateX(-50%);box-shadow:inset 0 0 0 9px #16835d}.cec-v162-thermo i{position:absolute;left:7px;right:7px;bottom:8px;background:#16835d;border-radius:15px}.cec-v162-hero .pct{font-size:48px;font-weight:950;line-height:1}.cec-v162-hero p{margin:6px 0 0;font-size:11px;opacity:.82}.cec-v162-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:12px}.cec-v162-stat{background:#fff;border:1px solid #dbe6eb;border-radius:16px;padding:11px}.cec-v162-stat strong{display:block;font-size:21px;color:#153e52}.cec-v162-stat span{display:block;font-size:9px;color:#738994;font-weight:900}.cec-v162-section{background:#fff;border:1px solid #dbe6eb;border-radius:20px;padding:13px;margin-top:12px}.cec-v162-section h3{margin:0 0 9px;font-size:15px;color:#173e52}.cec-v162-heat{display:grid;grid-template-columns:repeat(12,1fr);gap:5px}.cec-v162-heat button{aspect-ratio:1;border:0;border-radius:7px;font-size:9px;font-weight:900;background:#edf2f4;color:#617984}.cec-v162-heat button.p1{background:#fff1d5;color:#8c5c08}.cec-v162-heat button.p2{background:#dff1f6;color:#0b6687}.cec-v162-heat button.p3{background:#e1f5eb;color:#19724f}.cec-v162-heat button.done{background:#16835d;color:#fff}.cec-v162-search{width:100%;box-sizing:border-box;border:1px solid #d7e3e8;border-radius:13px;padding:10px 12px;margin-bottom:9px}.cec-v162-filters{display:flex;gap:6px;overflow:auto;margin-bottom:9px}.cec-v162-filter{border:1px solid #d7e3e8;background:#fff;border-radius:999px;padding:7px 10px;font-size:10px;font-weight:900;white-space:nowrap}.cec-v162-filter.active{background:#103f57;color:#fff}.cec-v162-list{display:grid;gap:7px}.cec-v162-row{display:grid;grid-template-columns:45px 1fr auto;gap:9px;align-items:center;border:1px solid #e0e9ed;border-radius:14px;padding:9px;background:#fbfdfe;text-align:left}.cec-v162-num{height:42px;border-radius:12px;background:#edf3f5;display:grid;place-items:center;font-weight:950}.cec-v162-row strong{display:block;font-size:11px;color:#173e52}.cec-v162-row small{font-size:9px;color:#7a8e97}.cec-v162-rbar{display:block;height:6px;background:#e8eff2;border-radius:99px;overflow:hidden;margin-top:5px}.cec-v162-rbar i{display:block;height:100%;background:#16835d}.cec-v162-rpct{font-weight:950;color:#1a654e}@media(max-width:520px){.cec-v162-heat{grid-template-columns:repeat(9,1fr)}}`;
document.head.appendChild(s);}
function install(){inject();const top=$('.cec-t15-top');if(top&&!$('#cecV162ReportActions')){const d=document.createElement('div');d.id='cecV162ReportActions';d.className='cec-v162-report-actions';d.innerHTML='<button id="cecV162OpenReport" class="cec-v162-report-btn" type="button">Informe + termómetro</button>';top.appendChild(d);const m=document.createElement('div');m.id='cecV162Mini';m.className='cec-v162-mini';m.innerHTML='<span class="cec-v162-mini-t"><i></i></span><div><strong>Termómetro del territorio</strong><small>0% realizado</small></div>';top.appendChild(m);$('#cecV162OpenReport').onclick=openReport;}if(!$('#cecV162Report')){const r=document.createElement('section');r.id='cecV162Report';r.innerHTML='<header class="cec-v162-rhead"><button class="cec-v162-rback" type="button">‹</button><div><small>INFORME INFOGRÁFICO</small><strong>Avance de territorios</strong></div></header><main id="cecV162ReportBody" class="cec-v162-rwrap"></main>';document.body.appendChild(r);$('.cec-v162-rback',r).onclick=closeReport;}updateMini();}
function updateMini(){const n=String($('#t15Select')?.value||'1'),m=metric(n),root=$('#cecV162Mini');if(!root)return;root.querySelector('i').style.height=Math.max(0,m.pct)+'%';root.querySelector('small').textContent=`Territorio ${n} · ${m.done}/${m.total} · ${m.pct}% realizado`;}
function openReport(){$('#cecV162Report').classList.add('open');render();}
function closeReport(){$('#cecV162Report')?.classList.remove('open');}
function render(){const a=aggregate(),root=$('#cecV162ReportBody');if(!root)return;root.innerHTML=`<section class="cec-v162-hero"><div class="cec-v162-thermo"><i style="height:${Math.max(0,a.pct)}%"></i></div><div><div style="font-size:10px;font-weight:900;opacity:.75">AVANCE GENERAL</div><div class="pct">${a.pct}%</div><p>${a.done} de ${a.total} lados/tramos realizados.</p></div></section><div class="cec-v162-stats"><div class="cec-v162-stat"><strong>${a.completed}</strong><span>COMPLETADOS</span></div><div class="cec-v162-stat"><strong>${a.active}</strong><span>EN CURSO</span></div><div class="cec-v162-stat"><strong>${a.empty}</strong><span>SIN INICIAR</span></div></div><section class="cec-v162-section"><h3>Mapa de avance · 1 a 102</h3><div class="cec-v162-heat">${a.rows.map(x=>`<button data-t="${x.n}" class="${x.pct===100?'done':x.pct>=67?'p3':x.pct>=34?'p2':x.done?'p1':''}">${x.n}</button>`).join('')}</div></section><section class="cec-v162-section"><h3>Termómetro por territorio</h3><input id="cecV162RSearch" class="cec-v162-search" inputmode="numeric" placeholder="Buscar territorio…"><div class="cec-v162-filters"><button class="cec-v162-filter active" data-f="all">Todos</button><button class="cec-v162-filter" data-f="pending">Pendientes</button><button class="cec-v162-filter" data-f="active">En curso</button><button class="cec-v162-filter" data-f="done">Completados</button></div><div id="cecV162RList" class="cec-v162-list"></div></section>`;$$('[data-t]',root).forEach(b=>b.onclick=()=>go(b.dataset.t));$$('[data-f]',root).forEach(b=>b.onclick=()=>{filter=b.dataset.f;$$('[data-f]',root).forEach(x=>x.classList.toggle('active',x===b));renderList();});$('#cecV162RSearch').oninput=renderList;renderList();}
function renderList(){const root=$('#cecV162RList');if(!root)return;const q=String($('#cecV162RSearch')?.value||''),rows=aggregate().rows.filter(x=>{if(q&&!String(x.n).includes(q))return false;if(filter==='done')return x.pct===100;if(filter==='active')return x.done&&x.pct<100;if(filter==='pending')return x.pct<100;return true;});root.innerHTML=rows.map(x=>`<button class="cec-v162-row" data-open="${x.n}"><span class="cec-v162-num">${x.n}</span><span><strong>${x.pct===100?'Completado':x.done?'En curso':'Sin iniciar'}</strong><small>${x.done} de ${x.total} lados/tramos</small><span class="cec-v162-rbar"><i style="width:${x.pct}%"></i></span></span><span class="cec-v162-rpct">${x.pct}%</span></button>`).join('');$$('[data-open]',root).forEach(b=>b.onclick=()=>go(b.dataset.open));}
function go(n){closeReport();api.select(String(n),false);setTimeout(()=>$('.cec-map-card')?.scrollIntoView({behavior:'smooth',block:'start'}),80);}
const obs=new MutationObserver(()=>{updateMini();if($('#cecV162Report')?.classList.contains('open'))render();});setTimeout(()=>{['t15Pct','t15Select','t15Title'].forEach(id=>{const e=document.getElementById(id);if(e)obs.observe(e,{subtree:true,childList:true,attributes:true,characterData:true});});},100);
install();setTimeout(install,500);window.CongElCalafateTerritoriosReportV162={version:VERSION,metric,aggregate,open:openReport,refresh:updateMini};
})();
/* V1.6.2 · plano individual oficial por territorio + dibujo sobre el plano */
(()=>{
'use strict';
const VERSION='1.6.2';
const api=window.CongElCalafateTerritoriosV150;
const OFF=window.CongTerritoryOfficialData||{};
if(!api||!OFF.data)return;
const DATA=OFF.data;
const STATE_KEY='cec_territory_official_v150';
const DRAW_KEY='cec_territory_individual_drawings_v162';
const OLD_DRAW_KEY='cec_territory_drawings_v160';
const $=(s,r=document)=>r.querySelector(s);
const $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const sideKey=(item,side)=>item+'::'+side;
const sideName=s=>({N:'Norte',E:'Este',S:'Sur',O:'Oeste',territorio:'Territorio'})[s]||s;
const PDF_IDS={1:'19GLkxRq8I97mSEEEfZhOkFT3fe2iUb3A',2:'1eXANR7FlyP9aAgPuthP2KKhbu6WpjRNY',3:'1sRlZOc-kZPHYLeqTHEIW63e6aEiTjZAo',4:'1BAGqGb3s2fwHjCqcf5SSjAIaIhbtSU8x',5:'1H0xPu0K1T3ycoQY560vJkW-MaIG0yf4l',6:'1HWzLgU2j3VvSyeh5c_-_h0wXVE01V6PF',7:'1DAp35KtfGZehSADvW7xlg_TGgT9VPV7J',8:'1YL3E-I9cZ-3xOoTOJ5SNEANXWVJMOZla',9:'1vmmjcM0yO_FNd3tgXnKtAOCO45uQTUMn',10:'1amyMrSFClzihTWLQMDv0MD-p9bceIiWq',11:'1wmrC-vHbv-YCX19CJfUSwK4b6rX2OQE9',12:'1H3fFgDOghcrMUQUHJ3eRZGKOO5IPVcFu',13:'1HfBMOYkGingKWcxPiGWPOAWD3JzcOXmt',14:'1cEmmNjWG_SgfgpiSqYEsTeSvjlZTmhbx',15:'17vc7I2D8J07CMwVhM2J5EEaHB1RArGi5',16:'18OERljZhBh0PEMjha9ASS96DTh-frf6h',17:'1syg5Slu0o-nTmV42fW_kTRhycTxaX14c',18:'1Y8fXfQGb9gJ93KnA24vep0Nn0Gw9h83g',19:'1MntHwVI-_FeTXkEGjYrOGbP_f2v0EyhO',20:'1WzLIUlkqZny6gE-zThCZJFCIegI3DoUe',21:'1omvoPiU_ZbhlZj_zekZv2yJdLC5q0zUO',22:'1_r6qSl1cf-4v-6D56WEoucmBNQslSepg',23:'1_Y_B2ZoWqXhCpnjUJA204qT8kU-d06yq',24:'1_aEiWzchiTcoYY2tKBP_i_FF-rv5UvDx',25:'1iNY9mqIlp18DoB1yFAMVHXZW1CnyTp7i',26:'1DkY7Ulv4SuBjhK2ZbEecWRkB9wk214v0',27:'1VR87n4t1hbQeoKpiYJop1njo6_goHJJO',28:'1zi4M6mjqCPryDJzklspt9qaftnq6jAv7',29:'1fajbuQiCXNQDuZcnLj7rdLOWrxpBpAbj',30:'1_SfIqXJw92sM4hLa8N48SE-OCeAKjdth',31:'1E7saW3hL7U1u76CnwZj1hDy6x1P-r6OF',32:'1Z6avXQtaCVmPUJuoo18rtXl1l3GgMP_G',33:'1SWivp-ht56mJco4UN2xxY2RDE7IuRDtc',34:'1tDwinNaMRVwHafj-b0U-gnN6zJNa0od0',35:'1TcnLGL2eE29aVNEvQdcS3l8U-Yww4k2r',36:'1BjtKKkVXQDZNwRs8Onxj-Bn918AzgVF0',37:'1z_Uov6KNqiGhqKGnWvCja2_BTpQglE0p',38:'1Bx-bs2_bVdp5E2xBGEJgNCMVBOgDDNIx',39:'1skvyvftZk-AfmtCJ_BuTNkK9WM-arJjw',40:'1phQle-Ya_ltLqJvBfX_GRqchPBsGLZvz',41:'1gcbXgu8VDTDRsrUYUvXEMrEhqFqrrq1Q',42:'1sLZ8TNjoGHG92SIbfeL3RP3wO0vkxcDO',43:'1LFz_rrMqUpWYyKG6xhhPTSra1zxZ9Asb',44:'1uHB6fEMirOFIYzqoMakFbgNrJ24UZcGO',45:'1OUpRdxrBZmSaYKA-ITMAjA1c4EmsBFNW',46:'1qTx3gdSa3RDNxEQKmSFOfgVvKbhH50_a',47:'1uhvQSsefabySwUoFLvY3hxBzyxMiEuWw',48:'1oniUp6fDAjsHEzyUuoohiY5-7vQhFJcF',49:'1yr8kY39YMgKD011_98P9cwfCMR2ZVkTP',50:'11q3rQhk6m3Eh_usA_hBIu2SFvlgDZfbm',51:'1dZdLQpYLC31SuvRdHgokCboLVtRu3UaP',52:'1UCBtu4PdBjA_7RSbKw0qrLSRIbvdgDYW',53:'16xcQnfL1xtNNr9U8wYqFxAYEt5u0Uzn1',54:'145iBLlUatRJ4UXoPRC1XHuSFQxO1C0u3',55:'12O4ki_r2fLIAZpf-VNw0UKfwdVUN--2u',56:'1QUnuWee2aziQM1Mm0eq_cy7YAZ2IVmy7',57:'1uE7Mld9_JcboUNdecM2z9ypF96rQ7as0',58:'1CQkSXSBeROH_yhm1YadEsPV3U5QL4Vkv',59:'1Lpbo5R5vJFRmLYyLj011aZcPmhvY10uN',60:'1xhw8770yIklrhT2dtHV3b20MaBt0oa6M',61:'1u3ak9ZHoQGa2dvj1jhBXwOF2wjMvywWw',62:'13AcnykJ097Ul_2_eVsAXsocpmt4xhuMc',63:'168FX44Qgc4ZkGypTqAbVQwcJDN158BIn',64:'1kvaNN7ra_TYHAalnS2zmqw5EHP2-Ov6Q',65:'1F6BvH0x8L4oztoodeUHLGXoQ3uIg-Uao',66:'12TWJ6n7IPn3fXQL-bdq85k_FptVcPXyu',67:'10fwxlCrUjHbaqsKndOk_ZH8AvUXcj4NG',68:'1zf3zYWKf2kEOAUwlv0ylOEEqiQovI088',69:'184Tja4GmRaMhafREtFUn85sxE4RaAh7O',70:'15dxlNoISXbYzaYUYCNLpN4K51oioWP6n',71:'1PwKxttv_BBhMic8UmbxlnJZGvfyjZl6O',72:'1VYqgID8xRTq_NkI4fp10vJCT7Mhc2o4r',73:'1OP2VphueosuVfRIdUlX4N3fYitSPK8RV',74:'1QQNURSOCGoB-dVaI5Llmju5Ff5KUPweS',75:'1AJ3flI3jZxHbC6D5jtTYchGvWUYKI5ms',76:'10rZ4SrSF2tdYAoZaTpeivpRtNxnhj3O-',77:'1anuwjcn_QYEUYEFz5jdZzuPmiglhoOIY',78:'1WyVovHTTXHWSnV_NFfYe71x01sXSl4YF',79:'1r9oQd-hupfnjwRHnHRS6naBdUBiEPxBd',80:'1zRq-x_uHVD6xuhoM0_YpVMISlJNpSUoy',81:'1Rbp4M0xeantJC8VcI2gxkl3FAKB4lp3X',82:'1f0E4Dfh876dXOQDyBmm9PdMUNawI1rE2',83:'1WDhMtf4Et6t_ERdLmsBqC-Bb-ynognbA',84:'1x-zj9ij15L7HoG4Xwwa3LUUcdmhZPvUl',85:'1otSGJ3hyPd77EF_zhdZTLRBNf_MzedKE',86:'1q3nwcUfqH4HlalWa7GMLC783AV2GDyvi',87:'1rOhRpxWK2vPoUK5dOMS6ikQAgI92ZE8d',88:'1-lFnuKPe_NQCbgxXlo7Ro99HU-nm6hdJ',89:'132kMXTBxiCRjFRn2-aSqxZ5bTdXGzU-5',90:'1Y9fox8TJp8oUPKgpGAWOvyZK6kN1f944',91:'1nyg_l4G9dX2bSiFc7EUkY6nXHWNI2gvd',92:'1NFuPKR7e-dFKDwzVp_vapJJofTlfQ2aL',93:'1wcTrPO0vELfCami-5YjRucdkCOU-dVnA',94:'1GV6Ok_xjWbnysK54jKpXNIuQofmoE5pG',95:'1xytcPprzyJUY2nUvtSOtkCrZPsQXQysj',96:'1PdVT91nqJRR2fxCYXLyDuhZzFwNSTEt9',97:'15o7pmfmegJJBJ0SQRDEXov4hm1ZFEts4',98:'1_5gKFZ02Qb4vEmoKdFzIb2XYmwys8KYZ',99:'1m-Nn_EuOlYgRMlfKDbKjuuuV09iDx-Cv',100:'1yZgJUPhHlqAC7LixhyRYdOJ5RJP3uO0j',101:'1UQd_uGB-WgNUMXf4bZVRflYNmBmfY4QG',102:'1Cfzfk7-AW8PtD1BcTsU8dHiSuSZYBeVj'};
if(DATA['32']&&DATA['32'].type==='manzanas')DATA['32'].items=['Mz 1528','Mz 1504a','Mz 1504b','Mz 1504c','Mz 1501','Mz 1503','Mz 1433','Mz 1502','Mz 1432','Mz 1431'];
let current='1',zoom=1,drawing=false,currentStroke=null,resolving=null,selectedKeys=new Set(),imageCache={};
function readJson(key,fallback){try{return JSON.parse(localStorage.getItem(key)||'')||fallback;}catch(_){return fallback;}}
function writeJson(key,v){localStorage.setItem(key,JSON.stringify(v));}function readState(){return readJson(STATE_KEY,{})}function writeState(v){writeJson(STATE_KEY,v)}function readDraw(){return readJson(DRAW_KEY,{})}function writeDraw(v){writeJson(DRAW_KEY,v)}function currentTerritory(){return String($('#t15Select')?.value||current||'1')}
function metric(n){n=String(n);const d=DATA[n],s=readState()[n]||{},done=s.done||{},keys=[];if(!d)return{done:0,total:0,pct:0};if(d.type==='tramos')d.items.forEach(x=>keys.push(sideKey(x,'territorio')));else d.items.forEach(x=>['N','E','S','O'].forEach(k=>keys.push(sideKey(x,k))));const c=keys.filter(k=>!!done[k]).length;return{done:c,total:keys.length,pct:keys.length?Math.round(c*100/keys.length):0}}
function installStyle(){if($('#cecV162Style'))return;const s=document.createElement('style');s.id='cecV162Style';s.textContent=`.cec-map-card.cec-v162-mode>.cec-map-tools,.cec-map-card.cec-v162-mode>.cec-territory-grid-wrap,.cec-map-card.cec-v162-mode>#cecDrawTools,.cec-map-card.cec-v162-mode>#t15MapScroll,.cec-map-card.cec-v162-mode>#cecV161FocusHint,.cec-map-card.cec-v162-mode>#cecDrawReadout,.cec-map-card.cec-v162-mode>.cec-map-legend,.cec-map-card.cec-v162-mode>.cec-map-note{display:none!important}.cec-v162-viewer{background:#eef3f5}.cec-v162-head{position:sticky;top:0;z-index:8;display:flex;align-items:center;gap:8px;padding:10px 11px;background:rgba(255,255,255,.97);border-bottom:1px solid #dce7eb}.cec-v162-title{min-width:0;flex:1}.cec-v162-title small{display:block;font-size:9px;font-weight:900;letter-spacing:.08em;color:#7a8f98}.cec-v162-title strong{display:block;font-size:16px;color:#163f53;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.cec-v162-tool{height:38px;min-width:38px;border:1px solid #d5e2e8;border-radius:11px;background:#f8fbfc;color:#365e6f;font-weight:900;padding:0 10px}.cec-v162-tool.active{background:#0b5fa5;color:#fff;border-color:#0b5fa5}.cec-v162-foot-tools button.select{background:#0b5fa5;color:#fff;border-color:#0b5fa5}.cec-v162-more{font-size:10px}.cec-v162-status{padding:8px 12px;font-size:11px;color:#617984;background:#fbfdfe;border-bottom:1px solid #e3ecef}.cec-v162-status strong{color:#164c63}.cec-v162-status.error{color:#9b3c3c;background:#fff8f8}.cec-v162-status.ok{color:#246c4e}.cec-v162-viewport{height:calc(100dvh - 255px);min-height:360px;max-height:none;overflow:auto;overscroll-behavior:contain;background:#fff;padding:0;box-sizing:border-box;touch-action:pan-x pan-y}.cec-v162-stage{position:relative;width:100%;margin:0;background:#fff;box-shadow:none;transform-origin:top left}.cec-v162-stage img{display:block;width:100%;height:auto;object-fit:contain;background:#fff;user-select:none;-webkit-user-drag:none}.cec-v162-svg{position:absolute;inset:0;width:100%;height:100%;z-index:4;pointer-events:none}.cec-v162-svg.drawing{pointer-events:auto;touch-action:none;cursor:crosshair}.cec-v162-svg polyline{fill:none;stroke:#d98b12;stroke-width:5.2;stroke-linecap:round;stroke-linejoin:round;vector-effect:non-scaling-stroke}.cec-v162-svg polyline.confirmed{stroke:#16835d;stroke-width:5}.cec-v162-svg polyline.current{stroke:#0b5fa5;stroke-width:5.4}.cec-v162-foot{padding:10px 11px 12px;background:#fff;border-top:1px solid #dce7eb}.cec-v162-foot-tools{display:flex;gap:6px;flex-wrap:wrap}.cec-v162-foot-tools button{border:1px solid #d6e3e8;border-radius:11px;background:#f8fbfc;color:#345b6c;padding:8px 10px;font-size:10px;font-weight:900}.cec-v162-foot-tools button.primary{background:#0b5fa5;color:#fff;border-color:#0b5fa5}.cec-v162-foot-tools button.active{background:#0b6b4f;color:#fff;border-color:#0b6b4f}.cec-v162-help{font-size:10px;line-height:1.45;color:#718690;margin:8px 1px 0}.cec-v162-help strong{color:#174c62}.cec-v162-progress{margin-top:9px;display:flex;align-items:center;gap:9px}.cec-v162-progress-bar{height:7px;flex:1;background:#e8eff2;border-radius:999px;overflow:hidden}.cec-v162-progress-bar i{display:block;height:100%;background:#16835d;border-radius:999px}.cec-v162-progress b{font-size:12px;color:#176b4b}.cec-v162-general .cec-v162-viewer{display:none}.cec-map-card.cec-v162-general>.cec-map-tools,.cec-map-card.cec-v162-general>.cec-territory-grid-wrap,.cec-map-card.cec-v162-general>#t15MapScroll,.cec-map-card.cec-v162-general>.cec-map-legend,.cec-map-card.cec-v162-general>.cec-map-note{display:flex!important}.cec-map-card.cec-v162-general>#t15MapScroll{display:block!important}.cec-map-card.cec-v162-general>.cec-territory-grid-wrap{display:block!important}.cec-map-card.cec-v162-general>.cec-map-note{display:block!important}#cecV162Resolve{position:fixed;inset:0;z-index:9400;background:rgba(8,31,42,.6);display:none;align-items:flex-end}#cecV162Resolve.open{display:flex}.cec-v162-sheet{width:100%;max-height:88vh;background:#fff;border-radius:24px 24px 0 0;padding:14px;display:flex;flex-direction:column;gap:10px;box-sizing:border-box}.cec-v162-sheet-head{display:flex;gap:8px;align-items:center}.cec-v162-sheet-head>div{min-width:0;flex:1}.cec-v162-sheet-head small{display:block;color:#78909a;font-size:9px;font-weight:900;letter-spacing:.08em}.cec-v162-sheet-head strong{display:block;color:#173e52;font-size:18px}.cec-v162-close{width:42px;height:42px;border:0;border-radius:12px;background:#edf3f5;font-size:22px}.cec-v162-search{height:44px;border:1px solid #d5e2e8;border-radius:13px;padding:0 12px;font-size:15px}.cec-v162-resolve-list{overflow:auto;display:grid;gap:8px;padding-bottom:5px}.cec-v162-item{border:1px solid #dfe8ec;border-radius:14px;padding:9px;background:#fbfdfe}.cec-v162-item strong{display:block;font-size:12px;color:#173e52;margin-bottom:7px}.cec-v162-sides{display:grid;grid-template-columns:repeat(4,1fr);gap:5px}.cec-v162-sides button,.cec-v162-tramo{border:1px solid #d6e3e8;border-radius:10px;background:#fff;color:#426170;padding:8px 5px;font-size:10px;font-weight:900}.cec-v162-sides button.sel,.cec-v162-tramo.sel{background:#0b5fa5;color:#fff;border-color:#0b5fa5}.cec-v162-sides button.done,.cec-v162-tramo.done{background:#e5f5ed;color:#1d7552;border-color:#bfe1d1}.cec-v162-tramo{width:100%;text-align:left;padding:10px;font-size:12px}.cec-v162-sheet-note{font-size:10px;line-height:1.45;color:#647b87;background:#f4f8fa;border-radius:12px;padding:9px}.cec-v162-sheet-actions{display:flex;gap:7px}.cec-v162-sheet-actions button{flex:1;min-height:42px;border:0;border-radius:12px;font-weight:900}.cec-v162-apply{background:#0b6b4f;color:#fff}.cec-v162-apply:disabled{opacity:.45}.cec-v162-only{background:#eef3f5;color:#48636f}@media(min-width:650px){.cec-v162-viewport{height:calc(100dvh - 225px);min-height:420px}.cec-v162-sheet{max-width:560px;border-radius:24px;max-height:82vh;margin:auto}#cecV162Resolve{align-items:center;justify-content:center}}`;document.head.appendChild(s)}
function ensureUi(){installStyle();const card=$('.cec-map-card');if(!card)return false;card.classList.add('cec-v162-mode');card.classList.remove('cec-v162-general');if(!$('#cecV162Viewer')){const v=document.createElement('section');v.id='cecV162Viewer';v.className='cec-v162-viewer';v.innerHTML=`<div class="cec-v162-head"><div class="cec-v162-title"><small>PLANO INDIVIDUAL OFICIAL</small><strong id="cecV162Title">Territorio</strong></div><button id="cecV162Minus" class="cec-v162-tool" type="button">−</button><button id="cecV162Fit" class="cec-v162-tool cec-v162-more" type="button">Ajustar</button><button id="cecV162Plus" class="cec-v162-tool" type="button">+</button></div><div id="cecV162Status" class="cec-v162-status">Preparando plano individual…</div><div id="cecV162Viewport" class="cec-v162-viewport"><div id="cecV162Stage" class="cec-v162-stage"><img id="cecV162Image" alt="Plano individual del territorio"><svg id="cecV162Svg" class="cec-v162-svg" viewBox="0 0 100 100" preserveAspectRatio="none"></svg></div></div><div class="cec-v162-foot"><div class="cec-v162-foot-tools"><button id="cecV162Select" class="select" type="button">☑ Marcar por botones</button><button id="cecV162Draw" type="button">✎ Dibujar manual</button><button id="cecV162Undo" type="button">↶ Deshacer</button><button id="cecV162Clear" type="button">Borrar trazos</button><button id="cecV162General" type="button">Mapa general</button></div><div id="cecV162Help" class="cec-v162-help"><strong>Elija “Marcar por botones” para seleccionar cada lado o tramo.</strong> El dibujo manual queda como alternativa.</div><div class="cec-v162-progress"><span id="cecV162ProgressText">0/0</span><span class="cec-v162-progress-bar"><i id="cecV162ProgressBar" style="width:0%"></i></span><b id="cecV162Pct">0%</b></div></div>`;card.insertBefore(v,card.firstElementChild);$('#cecV162Minus').onclick=()=>setZoom(zoom-.25);$('#cecV162Plus').onclick=()=>setZoom(zoom+.25);$('#cecV162Fit').onclick=()=>setZoom(1,true);$('#cecV162Select').onclick=()=>{setDrawing(false);openResolver(current,null,'buttons')};$('#cecV162Draw').onclick=()=>setDrawing(!drawing);$('#cecV162Undo').onclick=undoStroke;$('#cecV162Clear').onclick=clearStrokes;$('#cecV162General').onclick=showGeneral;bindDraw($('#cecV162Svg'))}ensureResolver();return true}
function setZoom(v,reset=false){zoom=Math.max(1,Math.min(4,+v||1));const stage=$('#cecV162Stage'),vp=$('#cecV162Viewport');if(stage)stage.style.width=(zoom*100)+'%';if(reset&&vp)vp.scrollTo({left:0,top:0,behavior:'smooth'})}function setStatus(text,kind=''){const e=$('#cecV162Status');if(!e)return;e.textContent=text;e.className='cec-v162-status'+(kind?' '+kind:'')}function updateProgress(){const m=metric(current);if($('#cecV162ProgressText'))$('#cecV162ProgressText').textContent=`${m.done} de ${m.total} lados/tramos`;if($('#cecV162ProgressBar'))$('#cecV162ProgressBar').style.width=m.pct+'%';if($('#cecV162Pct'))$('#cecV162Pct').textContent=m.pct+'%'}function showGeneral(){const c=$('.cec-map-card');if(!c)return;c.classList.remove('cec-v162-mode');c.classList.add('cec-v162-general');setDrawing(false)}function showIndividual(){const c=$('.cec-map-card');if(!c)return;c.classList.add('cec-v162-mode');c.classList.remove('cec-v162-general')}
function loadIndividual(n){if(!ensureUi())return;current=String(n||currentTerritory());showIndividual();setZoom(1,true);setDrawing(false);$('#cecV162Title').textContent='Territorio '+current;updateProgress();renderStrokes();const cached=imageCache[current];if(cached){applyImage(current,cached.src,cached.w,cached.h);return}const fileId=PDF_IDS[current];if(!fileId){setStatus('No se encontró el plano individual de este territorio.','error');return}$('#cecV162Image').removeAttribute('src');setStatus(`Cargando plano original del Territorio ${current}…`);if(window.AndroidBridge&&typeof window.AndroidBridge.loadTerritoryPdf==='function')window.AndroidBridge.loadTerritoryPdf(current,fileId);else setStatus('El plano individual se renderiza dentro del APK Android.','error')}
function applyImage(n,src,w,h){if(String(n)!==current)return;const img=$('#cecV162Image');if(!img)return;img.src=src;img.alt=`Plano individual oficial del Territorio ${n}`;setStatus(`Territorio ${n} · plano individual listo. Puede ampliar el plano y marcar los lados desde los botones o dibujar manualmente.`,'ok');setTimeout(()=>{renderStrokes();updateProgress()},40)}window.__cecReceiveTerritoryImage=function(n,b64,w,h){const src='data:image/png;base64,'+b64;imageCache[String(n)]={src,w:+w||0,h:+h||0};applyImage(String(n),src,w,h)};window.__cecTerritoryImageError=function(n,msg){if(String(n)!==current)return;setStatus(msg||'No se pudo cargar el plano individual.','error')};
function bindDraw(svg){if(!svg||svg.dataset.v162Bound)return;svg.dataset.v162Bound='1';svg.addEventListener('pointerdown',e=>{if(!drawing)return;e.preventDefault();svg.setPointerCapture?.(e.pointerId);currentStroke=[point(e,svg)];renderStrokes()});svg.addEventListener('pointermove',e=>{if(!drawing||!currentStroke)return;e.preventDefault();const p=point(e,svg),last=currentStroke[currentStroke.length-1];if(Math.hypot(p.x-last.x,p.y-last.y)>.15){currentStroke.push(p);renderStrokes()}});const end=e=>{if(!drawing||!currentStroke)return;e.preventDefault();const pts=currentStroke;currentStroke=null;if(pts.length>2)commitStroke(pts);else renderStrokes()};svg.addEventListener('pointerup',end);svg.addEventListener('pointercancel',end)}function point(e,svg){const r=svg.getBoundingClientRect();return{x:Math.max(0,Math.min(100,(e.clientX-r.left)/r.width*100)),y:Math.max(0,Math.min(100,(e.clientY-r.top)/r.height*100))}}function setDrawing(v){drawing=!!v;const svg=$('#cecV162Svg'),btn=$('#cecV162Draw'),vp=$('#cecV162Viewport');svg?.classList.toggle('drawing',drawing);btn?.classList.toggle('active',drawing);if(btn)btn.textContent=drawing?'✓ Finalizar dibujo':'✎ Dibujar manual';if(vp)vp.style.overflow=drawing?'hidden':'auto';const h=$('#cecV162Help');if(h&&drawing)h.innerHTML='<strong>Modo dibujo activo.</strong> Pase el dedo exactamente por el lado de calle trabajado. Al soltar, podrá indicar qué lado/tramo corresponde para sumarlo al termómetro.'}function straightenStroke(points){const pts=(points||[]).filter(p=>Number.isFinite(+p.x)&&Number.isFinite(+p.y));if(pts.length<2)return pts;const mx=pts.reduce((a,p)=>a+ +p.x,0)/pts.length,my=pts.reduce((a,p)=>a+ +p.y,0)/pts.length;let xx=0,yy=0,xy=0;pts.forEach(p=>{const x=+p.x-mx,y=+p.y-my;xx+=x*x;yy+=y*y;xy+=x*y});const angle=.5*Math.atan2(2*xy,xx-yy),ux=Math.cos(angle),uy=Math.sin(angle),projections=pts.map(p=>((+p.x-mx)*ux)+((+p.y-my)*uy)),lo=Math.min(...projections),hi=Math.max(...projections);if(hi-lo<.35)return[pts[0],pts[pts.length-1]];return Array.from({length:8},(_,i)=>{const t=lo+(hi-lo)*i/7;return{x:mx+ux*t,y:my+uy*t}})}function commitStroke(points){const all=readDraw();all[current]=Array.isArray(all[current])?all[current]:[];const straight=straightenStroke(points);const st={id:Date.now(),points:straight.map(p=>({x:+p.x.toFixed(3),y:+p.y.toFixed(3)})),keys:[],newlyMarked:[],createdAt:new Date().toISOString()};all[current].push(st);writeDraw(all);renderStrokes();openResolver(current,st.id)}function renderStrokes(){const svg=$('#cecV162Svg');if(!svg)return;const all=readDraw(),arr=Array.isArray(all[current])?all[current]:[];svg.innerHTML=arr.filter(st=>Array.isArray(st.points)&&st.points.length>1).map(st=>`<polyline class="${st.keys?.length?'confirmed':''}" points="${st.points.map(p=>`${p.x},${p.y}`).join(' ')}"></polyline>`).join('')+(currentStroke?`<polyline class="current" points="${currentStroke.map(p=>`${p.x},${p.y}`).join(' ')}"></polyline>`:'')}
function oldDrawingUses(n,k){const old=readJson(OLD_DRAW_KEY,{}),arr=Array.isArray(old[n])?old[n]:[];return arr.some(st=>(st.detected||[]).some(x=>x.key===k)||(st.newlyMarked||[]).includes(k))}function undoStroke(){const all=readDraw(),arr=Array.isArray(all[current])?all[current]:[];if(!arr.length)return;const st=arr.pop();all[current]=arr;writeDraw(all);if(st.newlyMarked?.length){const state=readState();state[current]=state[current]||{};state[current].done=state[current].done||{};st.newlyMarked.forEach(k=>{const still=arr.some(x=>(x.keys||[]).includes(k))||oldDrawingUses(current,k);if(!still)delete state[current].done[k]});state[current].updatedAt=new Date().toISOString();writeState(state)}renderStrokes();refreshTerritory()}function clearStrokes(){const all=readDraw(),arr=Array.isArray(all[current])?all[current]:[];if(!arr.length)return;if(!confirm(`¿Borrar los dibujos del Territorio ${current}? Las marcas ya confirmadas como realizadas permanecerán.`))return;all[current]=[];writeDraw(all);renderStrokes()}
function ensureResolver(){if($('#cecV162Resolve'))return;const r=document.createElement('div');r.id='cecV162Resolve';r.innerHTML=`<div class="cec-v162-sheet" role="dialog" aria-modal="true"><div class="cec-v162-sheet-head"><div><small id="cecV162ResolveMeta">TRAZO REALIZADO</small><strong>¿Qué lado o tramo fue trabajado?</strong></div><button class="cec-v162-close" type="button">×</button></div><input id="cecV162Search" class="cec-v162-search" type="search" placeholder="Buscar manzana o tramo…"><div class="cec-v162-sheet-note">Puede seleccionar uno o varios lados recorridos por este mismo trazo. Solo los seleccionados se suman al termómetro y un mismo lado nunca se cuenta dos veces.</div><div id="cecV162ResolveList" class="cec-v162-resolve-list"></div><div class="cec-v162-sheet-actions"><button id="cecV162OnlyDraw" class="cec-v162-only" type="button">Guardar solo dibujo</button><button id="cecV162Apply" class="cec-v162-apply" type="button" disabled>Sumar al termómetro</button></div></div>`;document.body.appendChild(r);$('.cec-v162-close',r).onclick=closeResolver;r.addEventListener('click',e=>{if(e.target===r)closeResolver()});$('#cecV162Search').addEventListener('input',renderResolver);$('#cecV162Apply').onclick=applyResolved;$('#cecV162OnlyDraw').onclick=closeResolver}function openResolver(n,strokeId,mode='draw'){resolving={n:String(n),strokeId:strokeId||null,mode};selectedKeys=new Set();$('#cecV162Search').value='';renderResolver();$('#cecV162Resolve').classList.add('open')}function closeResolver(){$('#cecV162Resolve')?.classList.remove('open');resolving=null;selectedKeys=new Set();renderStrokes()}
function renderResolver(){if(!resolving)return;const n=resolving.n,d=DATA[n],state=readState(),done=state[n]?.done||{},q=String($('#cecV162Search')?.value||'').trim().toLowerCase(),root=$('#cecV162ResolveList'),buttonMode=resolving.mode==='buttons';$('#cecV162ResolveMeta').textContent=`TERRITORIO ${n} · ${buttonMode?'SELECCIÓN POR BOTONES':'TRAZO PARA CONFIRMAR'}`;$('#cecV162Resolve .cec-v162-sheet-head strong').textContent=buttonMode?'¿Qué lado o tramo completó?':'¿Qué lado o tramo fue trabajado?';$('#cecV162Resolve .cec-v162-sheet-note').textContent=buttonMode?'Elija una o varias calles por manzana. Cada lado seleccionado se marcará como realizado y actualizará el progreso.':'Puede seleccionar uno o varios lados recorridos por este mismo trazo. Solo los seleccionados se suman al termómetro y un mismo lado nunca se cuenta dos veces.';$('#cecV162OnlyDraw').style.display=buttonMode?'none':'';if(d.type==='tramos')root.innerHTML=d.items.filter(x=>!q||x.toLowerCase().includes(q)).map(item=>{const k=sideKey(item,'territorio'),isDone=!!done[k],sel=selectedKeys.has(k);return`<button class="cec-v162-tramo ${isDone?'done':sel?'sel':''}" data-v162-key="${esc(k)}" ${isDone?'disabled':''}>${isDone?'✓ ':sel?'● ':''}${esc(item)}</button>`}).join('');else root.innerHTML=d.items.filter(x=>!q||x.toLowerCase().includes(q)).map(item=>`<div class="cec-v162-item"><strong>${esc(item)}</strong><div class="cec-v162-sides">${['N','E','S','O'].map(s=>{const k=sideKey(item,s),isDone=!!done[k],sel=selectedKeys.has(k);return`<button class="${isDone?'done':sel?'sel':''}" data-v162-key="${esc(k)}" ${isDone?'disabled':''}>${isDone?'✓ ':sel?'● ':''}${sideName(s)}</button>`}).join('')}</div></div>`).join('');$$('[data-v162-key]',root).forEach(b=>{if(!b.disabled)b.onclick=()=>{const k=b.dataset.v162Key;selectedKeys.has(k)?selectedKeys.delete(k):selectedKeys.add(k);renderResolver()}});const apply=$('#cecV162Apply');apply.disabled=!selectedKeys.size;apply.textContent=selectedKeys.size?(buttonMode?`Marcar ${selectedKeys.size} como realizadas`:`Sumar ${selectedKeys.size} al termómetro`):(buttonMode?'Marcar como realizadas':'Sumar al termómetro')}
function applyResolved(){if(!resolving||!selectedKeys.size)return;const {n,strokeId,mode='draw'}=resolving,state=readState(),all=readDraw();state[n]=state[n]||{};state[n].done=state[n].done||{};state[n].labels=state[n].labels||{};const arr=Array.isArray(all[n])?all[n]:[];let st=strokeId?arr.find(x=>String(x.id)===String(strokeId)):null;if(strokeId&&!st)return closeResolver();if(!st&&mode==='buttons'){st={id:Date.now(),points:[],keys:[],newlyMarked:[],mode:'buttons',createdAt:new Date().toISOString()};arr.push(st);all[n]=arr}if(st){st.keys=Array.from(new Set([...(st.keys||[]),...selectedKeys]));st.newlyMarked=st.newlyMarked||[]}selectedKeys.forEach(k=>{if(!state[n].done[k]){state[n].done[k]=true;if(st)st.newlyMarked.push(k)}if(!state[n].labels[k])state[n].labels[k]=mode==='buttons'?'Seleccionado por botones':'Trazado en plano individual'});state[n].updatedAt=new Date().toISOString();writeState(state);writeDraw(all);closeResolver();refreshTerritory();const m=metric(n),h=$('#cecV162Help');if(h)h.innerHTML=`<strong>${mode==='buttons'?'Selección confirmada.':'Trazo confirmado.'}</strong> Territorio ${n}: ${m.done}/${m.total} lados/tramos · <strong>${m.pct}% realizado</strong>.` }function refreshTerritory(){const n=current;api.select(n,false);setTimeout(()=>{showIndividual();updateProgress();renderStrokes();window.CongElCalafateTerritoriosMapGridV150?.paint?.();window.CongElCalafateTerritoriosReportV162?.refresh?.()},60)}
function wrapSelection(){const select=$('#t15Select');if(select&&!select.dataset.v162){select.dataset.v162='1';select.addEventListener('change',()=>setTimeout(()=>loadIndividual(select.value),90))}const orig=api.select;if(orig&&!api.__v162Wrapped){api.__v162Wrapped=true;api.select=function(n,focus){const r=orig.call(api,String(n),false);if(!window.CongElCalafateV174?.suppressMapReload)setTimeout(()=>loadIndividual(String(n)),60);return r}}}function patchAbout(){const s=$('.about-card strong'),p=$('.about-card p');if(s)s.textContent='Aplicación v1.6.2 · plano individual oficial con dibujo';if(p)p.textContent='Cada territorio abre su propio plano oficial en pantalla amplia. Puede ampliar y dibujar sobre las calles; los lados confirmados alimentan el termómetro.'}
if(ensureUi()){wrapSelection();patchAbout();setTimeout(()=>loadIndividual(currentTerritory()),150)}setTimeout(()=>{ensureUi();wrapSelection();patchAbout()},650);window.CongElCalafateTerritoriosV162={version:VERSION,pdfIds:PDF_IDS,load:loadIndividual,setDrawing,metric,showGeneral};
})();
/* V1.6.2 · cualquier selección visual de territorio abre el plano individual */
(()=>{
'use strict';
document.addEventListener('click',e=>{
  const b=e.target.closest?.('[data-territory]');
  const n=b?.dataset?.territory;
  if(!n||!/^\d{1,3}$/.test(n))return;
  setTimeout(()=>window.CongElCalafateTerritoriosV162?.load?.(n),90);
},false);
})();
/* V1.6.3 · diagnóstico exportable del app */
(()=>{
'use strict';
const VERSION='1.6.3';
const STARTED_AT=Date.now();
const MAX_EVENTS=40;
const events=[];
const $=(s,r=document)=>r.querySelector(s);
const $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const clip=(s,n=220)=>{s=String(s??'').replace(/\s+/g,' ').trim();return s.length>n?s.slice(0,n)+'…':s;};
const nowIso=()=>new Date().toISOString();
function addEvent(type,detail){events.push({at:nowIso(),type:String(type||'event'),detail:clip(detail,700)});if(events.length>MAX_EVENTS)events.splice(0,events.length-MAX_EVENTS);}
window.addEventListener('error',e=>addEvent('js_error',`${e.message||'Error'} @ ${e.filename||'?'}:${e.lineno||0}:${e.colno||0}`));
window.addEventListener('unhandledrejection',e=>addEvent('promise_rejection',e.reason?.stack||e.reason?.message||String(e.reason||'rechazo sin detalle')));
function wrapCallback(name,type,detailFn){const old=window[name];if(typeof old!=='function'||old.__cecDiagWrapped)return;const wrapped=function(...args){try{addEvent(type,detailFn?detailFn(args):name);}catch(_){ }return old.apply(this,args);};wrapped.__cecDiagWrapped=true;window[name]=wrapped;}
wrapCallback('__cecReceiveSheet','sheet_ok',a=>`${a[0]||'?'} · payload base64 ${String(a[1]||'').length} chars`);
wrapCallback('__cecSheetError','sheet_error',a=>`${a[0]||'?'} · ${a[1]||'sin detalle'}`);
wrapCallback('__cecReceiveTerritoryImage','territory_map_ok',a=>`Territorio ${a[0]||'?'} · ${a[2]||'?'}×${a[3]||'?'} px`);
wrapCallback('__cecTerritoryImageError','territory_map_error',a=>`Territorio ${a[0]||'?'} · ${a[1]||'sin detalle'}`);
function readJson(key,fallback){try{const raw=localStorage.getItem(key);return raw?JSON.parse(raw):fallback;}catch(e){return fallback;}}
function storageInventory(){const out=[];let chars=0;for(let i=0;i<localStorage.length;i++){const key=localStorage.key(i)||'';const val=localStorage.getItem(key)||'';chars+=key.length+val.length;if(/^cec_/i.test(key))out.push({key,chars:val.length});}out.sort((a,b)=>a.key.localeCompare(b.key));return{keys:out,totalKeys:localStorage.length,totalChars:chars};}
function activeScreen(){const candidates=['.screen.active','.app-screen.active','[data-screen].active','section.active','.page.active'];for(const q of candidates){const el=$(q);if(el)return el.id||el.getAttribute('data-screen')||clip(el.className,120);}const visible=$$('main section,main .screen,.screen').find(el=>{const st=getComputedStyle(el);return st.display!=='none'&&st.visibility!=='hidden'&&el.offsetHeight>0;});return visible?.id||'no_identificada';}
function nativeInfo(){try{if(window.AndroidBridge&&typeof AndroidBridge.getDiagnostics==='function'){const raw=AndroidBridge.getDiagnostics();return raw?JSON.parse(raw):{};}}catch(e){addEvent('native_diag_error',e.message||String(e));}return{};}
function moduleInfo(){const defs=[['Carritos','CongElCalafateCarritos'],['Carritos compactos','CongElCalafateCarritosCompact'],['Horarios compactos','CongElCalafateCarritosCompactShifts'],['Territorios base','CongElCalafateTerritoriosV150'],['Territorios mapa individual','CongElCalafateTerritoriosV162'],['Informe territorios','CongElCalafateTerritoriosReportV162'],['Datos oficiales','CongTerritoryOfficialData']];return defs.map(([label,k])=>{const v=window[k];return{label,key:k,ok:!!v,version:v?.version||v?.VERSION||''};});}
function territoryInfo(){const off=window.CongTerritoryOfficialData||{};const data=off.data||{};const selected=String($('#t15Select')?.value||$('.cec-v162-select')?.value||'');const n=selected||'—';const item=data[selected]||null;const state=readJson('cec_territory_official_v150',{});const st=state[selected]||{};const done=st.done||{};let total=0;if(item){total=item.type==='tramos'?(item.items||[]).length:(item.items||[]).length*4;}const doneCount=Object.values(done).filter(Boolean).length;const pct=total?Math.round(doneCount*100/total):0;const drawings=readJson('cec_territory_individual_drawings_v162',{});const strokeCount=Array.isArray(drawings[selected])?drawings[selected].length:0;const img=$('.cec-v162-stage img,#cecV162MapImg,.cec-v162-map-img');const mapStatus=img?`${img.complete&&img.naturalWidth>0?'cargado':'pendiente'}${img.naturalWidth?` · ${img.naturalWidth}×${img.naturalHeight}`:''}`:'visor no visible';return{selected:n,officialCount:Object.keys(data).length,type:item?.type||'—',items:item?.items?.length||0,done:doneCount,total,pct,strokeCount,mapStatus};}
function carritosInfo(){const active=$('#cecV141Overview .cec-v141-bar.active,.cec-v141-bar.active,.cec-chip.active');const day=$('.cec-c-day.active,.cec-day-chip.active,.cec-c-days .active');const overrides=readJson('cec_carritos_v140_overrides',{});const recents=readJson('cec_carritos_v140_recent',[]);const inv=storageInventory();const caches=inv.keys.filter(x=>x.key.startsWith('cec_carritos_v140_csv_'));let overrideCount=0;try{overrideCount=Object.keys(overrides||{}).length;}catch(_){ }return{active:clip(active?.textContent||'no visible',180),day:clip(day?.textContent||'no visible',120),overrideCount,recentCount:Array.isArray(recents)?recents.length:Object.keys(recents||{}).length,cacheCount:caches.length,cacheChars:caches.reduce((s,x)=>s+x.chars,0)};}
function uiSnapshot(){const id=activeScreen();let el=id&&id!=='no_identificada'?document.getElementById(id):null;if(!el)el=$('.screen.active,.app-screen.active,[data-screen].active,main')||document.body;return clip(el?.innerText||'',1800);}
function networkInfo(){const c=navigator.connection||navigator.mozConnection||navigator.webkitConnection;return{online:navigator.onLine,effectiveType:c?.effectiveType||'',downlink:c?.downlink??'',rtt:c?.rtt??'',saveData:c?.saveData??''};}
function checks(native,terr,mods){const arr=[];const add=(name,ok,detail)=>arr.push({name,ok:!!ok,detail});add('DOM listo',document.readyState==='complete'||document.readyState==='interactive',document.readyState);add('Puente Android',!!window.AndroidBridge,window.AndroidBridge?'disponible':'ausente');add('Datos territorios',terr.officialCount===102,`${terr.officialCount}/102`);add('Módulo mapa individual',!!window.CongElCalafateTerritoriosV162,window.CongElCalafateTerritoriosV162?.version||'ausente');add('Módulo carritos',!!window.CongElCalafateCarritos,window.CongElCalafateCarritos?.version||'presente sin versión');add('Exportación nativa',typeof window.AndroidBridge?.saveDiagnosticText==='function',typeof window.AndroidBridge?.saveDiagnosticText==='function'?'disponible':'fallback web');add('Versión nativa',!!native.appVersion,native.appVersion||'no informada');const missing=mods.filter(m=>!m.ok&&m.key!=='CongElCalafateTerritoriosReportV162').map(m=>m.label);add('Módulos esenciales',missing.length===0,missing.length?`faltan: ${missing.join(', ')}`:'OK');return arr;}
function report(){const native=nativeInfo();const terr=territoryInfo();const carts=carritosInfo();const mods=moduleInfo();const store=storageInventory();const net=networkInfo();const ck=checks(native,terr,mods);const ok=ck.filter(x=>x.ok).length;const lines=[];const p=(k,v)=>lines.push(`${k}: ${v===undefined||v===null?'':v}`);lines.push('=== DIAGNÓSTICO · CONG EL CALAFATE ===');p('Generado',new Date().toLocaleString());p('ISO',nowIso());p('Versión módulo diagnóstico',VERSION);p('Sesión abierta hace',`${Math.round((Date.now()-STARTED_AT)/1000)} s`);p('Resumen',`${ok}/${ck.length} comprobaciones OK`);lines.push('');lines.push('--- APP / DISPOSITIVO ---');p('App',native.appName||'Cong El Calafate');p('Versión app',native.appVersion||VERSION);p('VersionCode',native.versionCode||'—');p('Package',native.packageName||'app.congregacion.elcalafate');p('Android SDK',native.androidSdk||'—');p('Fabricante',native.manufacturer||'—');p('Modelo',native.model||'—');p('Idioma nativo',native.locale||'—');p('User-Agent',navigator.userAgent);p('Idioma WebView',navigator.language||'—');p('Viewport',`${innerWidth}×${innerHeight} · DPR ${devicePixelRatio||1}`);lines.push('');lines.push('--- CONECTIVIDAD ---');p('Online',net.online);p('Tipo efectivo',net.effectiveType||'—');p('Downlink',net.downlink===''?'—':net.downlink);p('RTT',net.rtt===''?'—':net.rtt);p('Ahorro de datos',net.saveData===''?'—':net.saveData);lines.push('');lines.push('--- PANTALLA / UI ---');p('Pantalla activa',activeScreen());p('URL local',location.href);p('Texto visible (recorte)',uiSnapshot()||'—');lines.push('');lines.push('--- TERRITORIOS ---');p('Territorio seleccionado',terr.selected);p('Territorios oficiales cargados',terr.officialCount);p('Tipo',terr.type);p('Elementos base',terr.items);p('Progreso',`${terr.done}/${terr.total} · ${terr.pct}%`);p('Trazos guardados',terr.strokeCount);p('Plano individual',terr.mapStatus);lines.push('');lines.push('--- CARRITOS ---');p('Carrito activo',carts.active);p('Día seleccionado',carts.day);p('Cambios locales',carts.overrideCount);p('Nombres recientes',carts.recentCount);p('Cachés CSV',`${carts.cacheCount} · ${carts.cacheChars} chars`);lines.push('');lines.push('--- MÓDULOS ---');mods.forEach(m=>p(m.label,`${m.ok?'OK':'AUSENTE'}${m.version?' · v'+m.version:''}`));lines.push('');lines.push('--- COMPROBACIONES ---');ck.forEach(c=>lines.push(`${c.ok?'OK':'FALLO'} · ${c.name} · ${c.detail}`));lines.push('');lines.push('--- ALMACENAMIENTO LOCAL ---');p('Claves totales',store.totalKeys);p('Tamaño aproximado',`${store.totalChars} chars`);store.keys.forEach(x=>lines.push(`- ${x.key}: ${x.chars} chars`));lines.push('');lines.push('--- EVENTOS / ERRORES RECIENTES ---');if(!events.length)lines.push('Sin errores o eventos de backend capturados desde que se cargó el diagnóstico.');else events.forEach(e=>lines.push(`${e.at} · ${e.type} · ${e.detail}`));lines.push('');lines.push('--- FIN DIAGNÓSTICO ---');lines.push('Nota: este informe evita contraseñas, identificadores únicos y ubicación precisa. Puede contener nombres/textos actualmente visibles en la pantalla para facilitar el diagnóstico.');return lines.join('\n');}
function installStyle(){if($('#cecDiagStyle'))return;const s=document.createElement('style');s.id='cecDiagStyle';s.textContent=`.cec-diag-fab{position:fixed;right:14px;bottom:calc(88px + env(safe-area-inset-bottom));z-index:9995;border:0;border-radius:999px;background:#163f53;color:#fff;font-weight:900;font-size:12px;padding:12px 15px;box-shadow:0 8px 24px rgba(15,52,68,.28);letter-spacing:.01em}.cec-diag-fab:active{transform:scale(.97)}.cec-diag-overlay{position:fixed;inset:0;z-index:10020;background:rgba(8,28,38,.55);display:none;align-items:flex-end;justify-content:center;padding:0}.cec-diag-overlay.open{display:flex}.cec-diag-panel{width:min(100%,760px);height:min(92vh,880px);background:#f7fafb;border-radius:24px 24px 0 0;box-shadow:0 -12px 40px rgba(0,0,0,.22);display:flex;flex-direction:column;overflow:hidden}.cec-diag-head{display:flex;align-items:center;gap:10px;padding:16px 16px 12px;background:#fff;border-bottom:1px solid #dbe7eb}.cec-diag-head>div{flex:1;min-width:0}.cec-diag-head strong{display:block;color:#163f53;font-size:18px}.cec-diag-head small{display:block;color:#6d828c;font-size:11px;margin-top:2px}.cec-diag-close{border:1px solid #d7e2e6;background:#f5f8f9;color:#274e5e;border-radius:12px;height:40px;padding:0 13px;font-weight:900}.cec-diag-summary{display:flex;gap:8px;flex-wrap:wrap;padding:10px 14px;background:#eef5f7;border-bottom:1px solid #dce7ea;font-size:11px;color:#466573}.cec-diag-chip{background:#fff;border:1px solid #d7e4e8;border-radius:999px;padding:6px 9px;font-weight:800}.cec-diag-text{flex:1;width:100%;box-sizing:border-box;border:0;resize:none;outline:0;padding:14px;background:#102832;color:#eaf4f7;font:11px/1.5 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;white-space:pre;overflow:auto}.cec-diag-actions{display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;padding:12px 14px calc(12px + env(safe-area-inset-bottom));background:#fff;border-top:1px solid #dce7ea}.cec-diag-btn{min-height:44px;border-radius:12px;border:1px solid #cfdee4;background:#f5f9fa;color:#244f60;font-weight:900;font-size:12px}.cec-diag-btn.primary{background:#0b6e55;border-color:#0b6e55;color:#fff}.cec-diag-btn.download{background:#0b5fa5;border-color:#0b5fa5;color:#fff}.cec-diag-toast{position:fixed;left:50%;bottom:calc(155px + env(safe-area-inset-bottom));transform:translateX(-50%);z-index:10050;background:#102f3d;color:#fff;border-radius:999px;padding:9px 13px;font-size:11px;font-weight:800;opacity:0;pointer-events:none;transition:opacity .18s}.cec-diag-toast.show{opacity:1}@media(max-width:430px){.cec-diag-actions{grid-template-columns:1fr 1fr}.cec-diag-actions .refresh{grid-column:1/-1;order:3}.cec-diag-panel{height:94vh}}`;document.head.appendChild(s);}
function toast(msg){let t=$('#cecDiagToast');if(!t){t=document.createElement('div');t.id='cecDiagToast';t.className='cec-diag-toast';document.body.appendChild(t);}t.textContent=msg;t.classList.add('show');clearTimeout(t._timer);t._timer=setTimeout(()=>t.classList.remove('show'),1800);}
function filename(){return `diagnostico_cong_el_calafate_${new Date().toISOString().replace(/[:.]/g,'-')}.txt`;}
function refresh(){const ta=$('#cecDiagText');if(!ta)return;ta.value=report();const terr=territoryInfo();const sum=$('#cecDiagSummary');if(sum)sum.innerHTML=`<span class="cec-diag-chip">App ${esc(nativeInfo().appVersion||VERSION)}</span><span class="cec-diag-chip">Pantalla: ${esc(activeScreen())}</span><span class="cec-diag-chip">Territorio ${esc(terr.selected)} · ${terr.pct}%</span><span class="cec-diag-chip">Eventos: ${events.length}</span>`;}
async function copyReport(){const text=$('#cecDiagText')?.value||report();try{if(window.AndroidBridge&&typeof AndroidBridge.copyText==='function'){AndroidBridge.copyText(text);toast('Diagnóstico copiado');return;}}catch(_){ }try{await navigator.clipboard.writeText(text);toast('Diagnóstico copiado');return;}catch(_){ }const ta=$('#cecDiagText');if(ta){ta.focus();ta.select();try{document.execCommand('copy');toast('Diagnóstico copiado');return;}catch(_){ }}toast('No se pudo copiar automáticamente');}
function downloadReport(){const text=$('#cecDiagText')?.value||report(),name=filename();try{if(window.AndroidBridge&&typeof AndroidBridge.saveDiagnosticText==='function'){AndroidBridge.saveDiagnosticText(name,text);toast('Guardando TXT en Descargas…');return;}}catch(e){addEvent('download_native_error',e.message||String(e));}try{const blob=new Blob([text],{type:'text/plain;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);toast('Descarga iniciada');}catch(e){addEvent('download_web_error',e.message||String(e));toast('No se pudo descargar; use Copiar');}}
function open(){const o=$('#cecDiagOverlay');if(!o)return;refresh();o.classList.add('open');document.body.style.overflow='hidden';}
function close(){const o=$('#cecDiagOverlay');if(o)o.classList.remove('open');document.body.style.overflow='';}
function installUI(){if($('#cecDiagFab'))return;installStyle();const fab=document.createElement('button');fab.id='cecDiagFab';fab.className='cec-diag-fab';fab.type='button';fab.textContent='Diagnóstico';fab.setAttribute('aria-label','Abrir diagnóstico del app');fab.addEventListener('click',open);document.body.appendChild(fab);const ov=document.createElement('div');ov.id='cecDiagOverlay';ov.className='cec-diag-overlay';ov.innerHTML=`<section class="cec-diag-panel" role="dialog" aria-modal="true" aria-label="Diagnóstico del app"><header class="cec-diag-head"><div><strong>Diagnóstico del app</strong><small>Copie o descargue el TXT y reenvíelo para revisar errores.</small></div><button type="button" class="cec-diag-close" id="cecDiagClose">Cerrar</button></header><div class="cec-diag-summary" id="cecDiagSummary"></div><textarea id="cecDiagText" class="cec-diag-text" readonly spellcheck="false"></textarea><footer class="cec-diag-actions"><button type="button" class="cec-diag-btn primary" id="cecDiagCopy">Copiar</button><button type="button" class="cec-diag-btn download" id="cecDiagDownload">Descargar TXT</button><button type="button" class="cec-diag-btn refresh" id="cecDiagRefresh">Actualizar diagnóstico</button></footer></section>`;ov.addEventListener('click',e=>{if(e.target===ov)close();});document.body.appendChild(ov);$('#cecDiagClose').addEventListener('click',close);$('#cecDiagCopy').addEventListener('click',copyReport);$('#cecDiagDownload').addEventListener('click',downloadReport);$('#cecDiagRefresh').addEventListener('click',()=>{refresh();toast('Diagnóstico actualizado');});}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',installUI,{once:true});else installUI();
window.CongElCalafateDiagnostico={version:VERSION,report,open,refresh,log:addEvent};
addEvent('diagnostic_ready',`V${VERSION}`);
})();
/* V1.6.4 · UX territorios: dibujo obligatorio al marcar + modal accesible + info compacta */
(()=>{
'use strict';
const VERSION='1.6.4';
const STATE_KEY='cec_territory_official_v150';
const DRAW_KEY='cec_territory_individual_drawings_v162';
let pendingKey=null,pendingTerritory=null,pendingTimer=null;
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
function readJson(k,f){try{return JSON.parse(localStorage.getItem(k)||'')||f}catch(_){return f}}
function writeJson(k,v){localStorage.setItem(k,JSON.stringify(v))}
function currentTerritory(){return String($('#t15Select')?.value||'1')}
function isDone(n,k){return !!(readJson(STATE_KEY,{})[n]?.done||{})[k]}
function labelForKey(k){const [item,side]=String(k).split('::');const names={N:'Norte',E:'Este',S:'Sur',O:'Oeste',territorio:'Territorio'};return `${item||'Tramo'} · ${names[side]||side||''}`}
function installStyle(){if($('#cecV164Style'))return;const s=document.createElement('style');s.id='cecV164Style';s.textContent=`
#cecV162Resolve{padding-bottom:24px!important;box-sizing:border-box}
#cecV162Resolve .cec-v162-sheet{height:min(86dvh,820px)!important;max-height:calc(100dvh - 38px)!important;padding:12px 14px 0!important;gap:8px!important;overflow:hidden!important}
#cecV162Resolve .cec-v162-sheet-head{flex:0 0 auto!important}
#cecV162Resolve .cec-v162-search{flex:0 0 44px!important}
#cecV162Resolve .cec-v162-resolve-list{flex:1 1 auto!important;min-height:0!important;overflow:auto!important;padding-bottom:12px!important;overscroll-behavior:contain}
#cecV162Resolve .cec-v162-sheet-actions{position:sticky!important;bottom:0!important;z-index:6!important;flex:0 0 auto!important;background:#fff!important;padding:10px 0 calc(22px + env(safe-area-inset-bottom))!important;border-top:1px solid #e0e9ed!important;box-shadow:0 -8px 18px rgba(20,55,70,.08)!important}
#cecV162Resolve .cec-v162-sheet-note{display:none!important;margin:0!important}
#cecV162Resolve .cec-v162-sheet.info-open .cec-v162-sheet-note{display:block!important;position:absolute!important;left:14px!important;right:14px!important;bottom:calc(82px + env(safe-area-inset-bottom))!important;z-index:8!important;background:#102f3d!important;color:#fff!important;border-radius:14px!important;padding:11px 13px!important;box-shadow:0 8px 24px rgba(0,0,0,.22)!important;font-size:11px!important;line-height:1.45!important}
.cec-v164-info-btn{width:40px;height:40px;border:1px solid #d7e3e8;border-radius:12px;background:#f5f9fa;color:#19546c;font-size:18px;font-weight:900;flex:0 0 auto}
.cec-v164-draw-prompt{position:sticky;top:0;z-index:12;display:none;align-items:center;gap:8px;background:#fff8e9;border:1px solid #efcf8c;color:#6b4a08;padding:9px 10px;font-size:11px;line-height:1.35}
.cec-v164-draw-prompt.show{display:flex}.cec-v164-draw-prompt strong{color:#4f3605}.cec-v164-draw-prompt span{flex:1}.cec-v164-draw-prompt button{border:0;background:#fff;border-radius:10px;padding:7px 9px;color:#795719;font-weight:900}
.cec-v164-footer-info{display:flex;justify-content:flex-end;margin:6px 0 0}.cec-v164-footer-info button{width:34px;height:34px;border:1px solid #d6e3e8;border-radius:999px;background:#f8fbfc;color:#2e6174;font-weight:900;font-size:15px}
.cec-v164-info-toast{position:fixed;left:14px;right:14px;bottom:calc(94px + env(safe-area-inset-bottom));z-index:10030;background:#123543;color:#fff;border-radius:16px;padding:12px 14px;box-shadow:0 10px 30px rgba(0,0,0,.26);font-size:11px;line-height:1.45;display:none}.cec-v164-info-toast.show{display:block}
@media(max-width:430px){#cecV162Resolve .cec-v162-sheet{height:calc(100dvh - 36px)!important;max-height:calc(100dvh - 36px)!important;border-radius:22px 22px 0 0!important}#cecV162Resolve{align-items:flex-end!important}.cec-v162-sides{grid-template-columns:repeat(2,1fr)!important}}
`;document.head.appendChild(s)}
function infoToast(text){let t=$('#cecV164InfoToast');if(!t){t=document.createElement('div');t.id='cecV164InfoToast';t.className='cec-v164-info-toast';document.body.appendChild(t)}t.textContent=text;t.classList.add('show');clearTimeout(t._tm);t._tm=setTimeout(()=>t.classList.remove('show'),5200)}
function upgradeResolver(){const r=$('#cecV162Resolve');if(!r)return;const sh=$('.cec-v162-sheet',r),head=$('.cec-v162-sheet-head',r);if(!sh||!head)return;if(!$('.cec-v164-info-btn',head)){const b=document.createElement('button');b.type='button';b.className='cec-v164-info-btn';b.textContent='i';b.setAttribute('aria-label','Información');const close=$('.cec-v162-close',head);head.insertBefore(b,close||null);b.onclick=()=>sh.classList.toggle('info-open')}if(r.classList.contains('open')&&pendingKey){const btn=$$('[data-v162-key]',r).find(x=>x.dataset.v162Key===pendingKey&&!x.disabled);if(btn){btn.click();setTimeout(()=>{$('#cecV162Apply')?.click();clearPending(false)},70)}else if(isDone(pendingTerritory,pendingKey)){setTimeout(()=>{r.classList.remove('open');clearPending(false)},50)}}}
function ensurePrompt(){let p=$('#cecV164DrawPrompt');if(p)return p;const viewer=$('#cecV162Viewer');if(!viewer)return null;p=document.createElement('div');p.id='cecV164DrawPrompt';p.className='cec-v164-draw-prompt';p.innerHTML='<span></span><button type="button">Cancelar</button>';viewer.prepend(p);$('button',p).onclick=()=>clearPending(true);return p}
function showPrompt(){const p=ensurePrompt();if(!p)return;$('span',p).innerHTML=`<strong>Dibuje este lado en el plano:</strong> ${labelForKey(pendingKey)}. Al soltar, se marcará automáticamente.`;p.classList.add('show')}
function clearPending(stopDrawing=true){window.CongElCalafateV174Pending=null;clearTimeout(pendingTimer);pendingTimer=null;pendingKey=null;pendingTerritory=null;$('#cecV164DrawPrompt')?.classList.remove('show');if(stopDrawing)window.CongElCalafateTerritoriosV162?.setDrawing?.(false)}
function removeStrokeForKey(n,k){const all=readJson(DRAW_KEY,{}),arr=Array.isArray(all[n])?all[n]:[];let changed=false;all[n]=arr.flatMap(st=>{const keys=Array.isArray(st.keys)?st.keys:[];if(!keys.includes(k))return[st];changed=true;const rest=keys.filter(x=>x!==k);if(!rest.length)return[];st.keys=rest;st.newlyMarked=(st.newlyMarked||[]).filter(x=>x!==k);return[st]});if(changed){writeJson(DRAW_KEY,all);setTimeout(()=>window.CongElCalafateTerritoriosV162?.load?.(n),80)}}
function beginDrawForKey(k){const n=currentTerritory();window.CongElCalafateV174Pending={n,k,at:Date.now()};pendingKey=k;pendingTerritory=n;window.CongElCalafateTerritoriosV162?.load?.(n);setTimeout(()=>{window.CongElCalafateTerritoriosV162?.setDrawing?.(true);showPrompt();$('#cecV162Viewer')?.scrollIntoView({behavior:'smooth',block:'start'})},120);pendingTimer=setTimeout(()=>clearPending(true),90000)}
function captureMarks(){document.addEventListener('click',e=>{const b=e.target.closest?.('[data-side-toggle],[data-tramo]');if(!b)return;const n=currentTerritory();const k=b.dataset.sideToggle||`${b.dataset.tramo}::territorio`;if(isDone(n,k)){setTimeout(()=>{if(!isDone(n,k))removeStrokeForKey(n,k)},80);return}e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();beginDrawForKey(k)},true)}
function compactNotes(){const pairs=[['.cec-local-note','.cec-territory-panel'],['.cec-map-note','.cec-map-card']];pairs.forEach(([sel,hostSel])=>{$$(sel).forEach(el=>{if(el.dataset.v164)return;el.dataset.v164='1';const text=(el.textContent||'').trim();el.style.display='none';const host=el.closest(hostSel)||el.parentElement;if(!host)return;const wrap=document.createElement('div');wrap.className='cec-v164-footer-info';const b=document.createElement('button');b.type='button';b.textContent='i';b.setAttribute('aria-label','Información');b.onclick=()=>infoToast(text);wrap.appendChild(b);host.appendChild(wrap)})});const h=$('#cecV162Help');if(h&&!h.dataset.v164){h.dataset.v164='1';const text=(h.textContent||'').trim();h.style.display='none';const head=$('.cec-v162-head');if(head&&!$('.cec-v164-info-btn.map',head)){const b=document.createElement('button');b.type='button';b.className='cec-v164-info-btn map';b.textContent='i';b.setAttribute('aria-label','Ayuda del mapa');b.onclick=()=>infoToast(text||'Dibuje sobre el lado de calle trabajado y luego confirme el tramo.');head.appendChild(b)}}}
function observe(){upgradeResolver();compactNotes();ensurePrompt();document.addEventListener('click',()=>setTimeout(()=>{upgradeResolver();compactNotes();ensurePrompt()},130),false)}
installStyle();captureMarks();if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',observe,{once:true});else observe();
window.CongElCalafateTerritoriosV164={version:VERSION,beginDrawForKey,clearPending};
})();
/* V1.6.4 · corrección de diagnóstico nativo + exportación consistente */
(()=>{
'use strict';
const VERSION='1.6.4';
const $=(s,r=document)=>r.querySelector(s);
function nativeV2(){try{if(!window.AndroidBridge||typeof AndroidBridge.getDiagnosticsV2!=='function')return null;const p=String(AndroidBridge.getDiagnosticsV2()||'').split('\t');if(p.length<7)return null;return{appVersion:p[0],versionCode:p[1],androidSdk:p[2],manufacturer:p[3],model:p[4],locale:p[5],packageName:p[6]};}catch(_){return null}}
function patchText(text){const n=nativeV2();let t=String(text||'');t=t.replace(/Versión módulo diagnóstico: .*$/m,`Versión módulo diagnóstico: ${VERSION}`);if(!n)return t;t=t.replace(/Versión app: .*$/m,`Versión app: ${n.appVersion}`)
.replace(/VersionCode: .*$/m,`VersionCode: ${n.versionCode}`)
.replace(/Package: .*$/m,`Package: ${n.packageName}`)
.replace(/Android SDK: .*$/m,`Android SDK: ${n.androidSdk}`)
.replace(/Fabricante: .*$/m,`Fabricante: ${n.manufacturer}`)
.replace(/Modelo: .*$/m,`Modelo: ${n.model}`)
.replace(/Idioma nativo: .*$/m,`Idioma nativo: ${n.locale}`)
.replace(/FALLO · Versión nativa · no informada/g,`OK · Versión nativa · ${n.appVersion}`)
.replace(/Resumen: 7\/8 comprobaciones OK/g,'Resumen: 8/8 comprobaciones OK');return t}
function updateTextarea(){const ta=$('#cecDiagText');if(ta)ta.value=patchText(ta.value);const sum=$('#cecDiagSummary');if(sum&&nativeV2()){const bad=[...sum.querySelectorAll('*')].find(x=>/7\/8|FALLO/i.test(x.textContent||''));if(bad)bad.textContent=(bad.textContent||'').replace('7/8','8/8').replace('FALLO','OK')}}
function fileName(){return `diagnostico_cong_el_calafate_${new Date().toISOString().replace(/[:.]/g,'-')}.txt`}
document.addEventListener('click',e=>{const copy=e.target.closest?.('#cecDiagCopy'),down=e.target.closest?.('#cecDiagDownload'),refresh=e.target.closest?.('#cecDiagRefresh');if(refresh){setTimeout(updateTextarea,80);return}if(copy||down){e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();updateTextarea();const txt=$('#cecDiagText')?.value||'';if(copy){try{if(typeof AndroidBridge?.copyText==='function')AndroidBridge.copyText(txt);else navigator.clipboard?.writeText(txt)}catch(_){}}else{try{if(typeof AndroidBridge?.saveDiagnosticText==='function')AndroidBridge.saveDiagnosticText(fileName(),txt)}catch(_){}}}},true);
const mo=new MutationObserver(()=>{const o=$('#cecDiagOverlay');if(o?.classList.contains('open'))setTimeout(updateTextarea,80)});mo.observe(document.body,{subtree:true,attributes:true,attributeFilter:['class']});
window.CongElCalafateDiagnosticoV164={version:VERSION,nativeV2,patchText};
})();
/* V1.6.5 · foco inteligente + mapa/lista bidireccional */
(()=>{
'use strict';
const VERSION='1.6.5', STATE_KEY='cec_territory_official_v150', DRAW_KEY='cec_territory_individual_drawings_v162', LEARN_KEY='cec_territory_focus_v165';
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const DATA=window.CongTerritoryOfficialData?.data||{};
const STATIC={
 '1':{'Mz 89c':[54.3,29.6],'Mz 104':[76.2,52.6],'Mz 105':[76.3,42.8],'Mz 106':[81.7,33.3],'Mz 109':[76.9,62.1],'Mz 110':[74.3,71.3],'Mz 110a':[70.7,78.6],'Mz 127a':[19.8,19.4],'Mz 8903':[46.5,27.7]},
 '32':{'Mz 1528':[24.2,39.1],'Mz 1504a':[48,30.5],'Mz 1504b':[72.6,29.5],'Mz 1504c':[48.5,40.9],'Mz 1501':[61.0,48.7],'Mz 1503':[44.5,56.9],'Mz 1433':[81,50],'Mz 1502':[58,69],'Mz 1432':[79,69],'Mz 1431':[76,84]}
};
let requestedKey=null,requestedAt=0,autoBusy=false;
function read(k,f){try{return JSON.parse(localStorage.getItem(k)||'')||f}catch(_){return f}}
function write(k,v){localStorage.setItem(k,JSON.stringify(v))}
function territory(){return String($('#t15Select')?.value||'1')}
function parts(k){const a=String(k||'').split('::');return{item:a[0]||'',side:a[1]||'territorio'}}
function done(n,k){return !!(read(STATE_KEY,{})[n]?.done||{})[k]}
function centroid(points){if(!points?.length)return{x:50,y:50};return points.reduce((a,p)=>({x:a.x+(+p.x||0)/points.length,y:a.y+(+p.y||0)/points.length}),{x:0,y:0})}
function installStyle(){if($('#cecV165Style'))return;const s=document.createElement('style');s.id='cecV165Style';s.textContent=`
#cecV165Guide{position:absolute;inset:0;width:100%;height:100%;z-index:5;pointer-events:none;overflow:visible}#cecV165Guide line{stroke:#ef8b00;stroke-width:2.2;stroke-linecap:round;vector-effect:non-scaling-stroke;filter:drop-shadow(0 0 2px rgba(255,255,255,.9));animation:cecV165Pulse .8s ease-in-out infinite alternate}#cecV165Guide circle{fill:rgba(239,139,0,.13);stroke:#ef8b00;stroke-width:1.4;vector-effect:non-scaling-stroke;animation:cecV165Pulse .8s ease-in-out infinite alternate}@keyframes cecV165Pulse{to{opacity:.35}}
.cec-v165-focus-note{position:absolute;left:50%;top:12px;transform:translateX(-50%);z-index:7;background:#173f52;color:#fff;border-radius:999px;padding:7px 11px;font-size:10px;font-weight:900;box-shadow:0 5px 18px rgba(0,0,0,.18);pointer-events:none;white-space:nowrap}.cec-v165-autook{position:fixed;left:50%;bottom:calc(100px + env(safe-area-inset-bottom));transform:translateX(-50%);z-index:10050;background:#0b6e55;color:#fff;border-radius:999px;padding:9px 13px;font-size:11px;font-weight:900;box-shadow:0 8px 22px rgba(0,0,0,.24);opacity:0;transition:opacity .18s;pointer-events:none}.cec-v165-autook.show{opacity:1}`;document.head.appendChild(s)}
function learned(){return read(LEARN_KEY,{})}
function learnKey(n,k,p){if(!k||!p)return;const all=learned();all[n]=all[n]||{};all[n][k]={x:+p.x.toFixed(2),y:+p.y.toFixed(2),at:new Date().toISOString()};write(LEARN_KEY,all)}
function learnLatest(n){const arr=read(DRAW_KEY,{})[n]||[],st=arr[arr.length-1];if(!st?.points?.length||!st.keys?.length)return;const c=centroid(st.points);st.keys.forEach(k=>learnKey(n,k,c))}
function baseAnchor(n,item){const l=learned()[n]||{};const exact=Object.entries(l).filter(([k])=>parts(k).item===item).map(([,v])=>v);if(exact.length){return{x:exact.reduce((s,v)=>s+v.x,0)/exact.length,y:exact.reduce((s,v)=>s+v.y,0)/exact.length,source:'learned'}}
 const st=STATIC[n]?.[item];if(st)return{x:st[0],y:st[1],source:'static'};
 const d=DATA[n],items=d?.items||[],idx=Math.max(0,items.indexOf(item)),count=Math.max(1,items.length);if(d?.type==='tramos')return{x:50,y:20+idx*(62/Math.max(1,count-1)),source:'fallback'};
 const cols=count>12?3:count>5?2:1,rows=Math.ceil(count/cols),col=idx%cols,row=Math.floor(idx/cols);return{x:cols===1?50:cols===2?(col?68:34):(25+col*25),y:22+row*(62/Math.max(1,rows-1)),source:'fallback'} }
function anchorFor(n,k){const l=learned()[n]?.[k];if(l)return{x:l.x,y:l.y,source:'learned'};const {item,side}=parts(k),b=baseAnchor(n,item),o={N:[0,-5.5],S:[0,5.5],E:[7,0],O:[-7,0],territorio:[0,0]}[side]||[0,0];return{x:Math.max(3,Math.min(97,b.x+o[0])),y:Math.max(3,Math.min(97,b.y+o[1])),source:b.source}}
function guide(k){const stage=$('#cecV162Stage');if(!stage)return;$('#cecV165Guide')?.remove();$('.cec-v165-focus-note',stage)?.remove();const n=territory(),{side}=parts(k),a=anchorFor(n,k),svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.id='cecV165Guide';svg.setAttribute('viewBox','0 0 100 100');if(side==='N'||side==='S'){svg.innerHTML=`<line x1="${a.x-8}" y1="${a.y}" x2="${a.x+8}" y2="${a.y}"/>`}else if(side==='E'||side==='O'){svg.innerHTML=`<line x1="${a.x}" y1="${a.y-7}" x2="${a.x}" y2="${a.y+7}"/>`}else svg.innerHTML=`<circle cx="${a.x}" cy="${a.y}" r="5"/>`;stage.appendChild(svg);const note=document.createElement('div');note.className='cec-v165-focus-note';note.textContent='Área a marcar';stage.appendChild(note)}
function zoomFocus(k){const n=territory(),a=anchorFor(n,k),api=window.CongElCalafateTerritoriosV162;api?.load?.(n);let tries=0;const run=()=>{const vp=$('#cecV162Viewport'),stage=$('#cecV162Stage'),img=$('#cecV162Image');if(!vp||!stage||!img?.naturalWidth){if(tries++<18)return setTimeout(run,120);return}$('#cecV162Fit')?.click();for(let i=0;i<6;i++)$('#cecV162Plus')?.click();guide(k);requestAnimationFrame(()=>{const x=a.x/100*stage.scrollWidth-vp.clientWidth/2,y=a.y/100*stage.scrollHeight-vp.clientHeight/2;vp.scrollTo({left:Math.max(0,x),top:Math.max(0,y),behavior:'smooth'});api?.setDrawing?.(true)})};setTimeout(run,120)}
function toast(msg){let e=$('#cecV165Toast');if(!e){e=document.createElement('div');e.id='cecV165Toast';e.className='cec-v165-autook';document.body.appendChild(e)}e.textContent=msg;e.classList.add('show');clearTimeout(e._t);e._t=setTimeout(()=>e.classList.remove('show'),1800)}
function candidates(n){const d=DATA[n];if(!d)return[];const out=[];if(d.type==='tramos')d.items.forEach(item=>{const k=item+'::territorio',a=anchorFor(n,k);out.push({k,item,side:'territorio',...a})});else d.items.forEach(item=>['N','E','S','O'].forEach(side=>{const k=item+'::'+side,a=anchorFor(n,k);out.push({k,item,side,...a})}));return out}
function strokeShape(st){const pts=st.points||[],c=centroid(pts),xs=pts.map(p=>+p.x),ys=pts.map(p=>+p.y),minx=Math.min(...xs),maxx=Math.max(...xs),miny=Math.min(...ys),maxy=Math.max(...ys),w=maxx-minx,h=maxy-miny;let len=0;for(let i=1;i<pts.length;i++)len+=Math.hypot(pts[i].x-pts[i-1].x,pts[i].y-pts[i-1].y);const end=pts.length>1?Math.hypot(pts[0].x-pts.at(-1).x,pts[0].y-pts.at(-1).y):99;return{c,w,h,len,closed:end<Math.max(6,Math.hypot(w,h)*.45)}}
function autoResolve(){if(autoBusy||requestedKey&&Date.now()-requestedAt<2500)return;const r=$('#cecV162Resolve');if(!r?.classList.contains('open'))return;const n=territory(),arr=read(DRAW_KEY,{})[n]||[],st=arr[arr.length-1];if(!st||st.keys?.length||!st.points?.length)return;const sh=strokeShape(st),d=DATA[n];if(!d)return;let keys=[];
 if(d.type!=='tramos'&&sh.closed&&sh.w>8&&sh.h>7){let best=null;for(const item of d.items){const a=baseAnchor(n,item),dist=Math.hypot(a.x-sh.c.x,a.y-sh.c.y);if(!best||dist<best.dist)best={item,dist,source:a.source}}if(best&&best.dist<(best.source==='fallback'?8:16))keys=['N','E','S','O'].map(s=>best.item+'::'+s).filter(k=>!done(n,k));}
 if(!keys.length){let best=null;for(const c of candidates(n)){const dist=Math.hypot(c.x-sh.c.x,c.y-sh.c.y);if(!best||dist<best.dist)best={...c,dist}}if(best&&best.dist<(best.source==='fallback'?7.5:14))keys=[best.k].filter(k=>!done(n,k));}
 if(!keys.length)return;autoBusy=true;let clicked=0;keys.forEach(k=>{const b=$$('[data-v162-key]',r).find(x=>x.dataset.v162Key===k&&!x.disabled);if(b){b.click();clicked++}});if(clicked){setTimeout(()=>{$('#cecV162Apply')?.click();setTimeout(()=>{learnLatest(n);window.CongElCalafateTerritoriosV150?.select?.(n,false);toast(clicked>1?`${clicked} lados marcados en la lista`:'Lado marcado en la lista')},140)},60)}setTimeout(()=>autoBusy=false,500)}
function capture(){window.addEventListener('click',e=>{const b=e.target.closest?.('[data-side-toggle],[data-tramo]');if(!b)return;const n=territory(),k=b.dataset.sideToggle||`${b.dataset.tramo}::territorio`;if(done(n,k))return;requestedKey=k;requestedAt=Date.now();setTimeout(()=>zoomFocus(k),150);setTimeout(()=>{requestedKey=null},5000)},true);
 window.addEventListener('pointerup',e=>{if(e.target?.id==='cecV162Svg'||e.target?.closest?.('#cecV162Svg')){setTimeout(()=>{if(!window.CongElCalafateV174?.active)autoResolve()},120);setTimeout(()=>learnLatest(territory()),450)}},true);
 document.addEventListener('click',e=>{if(e.target?.id==='cecV162Apply')setTimeout(()=>learnLatest(territory()),180)},true)}
function observe(){/* Se evita el observador global: V1.7.4 vincula trazos por evento. */}
installStyle();capture();if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',observe,{once:true});else observe();
window.CongElCalafateTerritoriosV165={version:VERSION,focusKey:zoomFocus,autoResolve,anchors:STATIC};
})();/* Congregación El Calafate · Visual System 2026 · V1.7.0 */
(()=>{
'use strict';
const VERSION='1.7.0';
const STATE_KEY='cec_territory_official_v150';
const $=(s,r=document)=>r.querySelector(s);
const $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const read=(k,f)=>{try{return JSON.parse(localStorage.getItem(k)||'')||f}catch(_){return f}};
function icon(name){const common='viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.85" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"';const p={home:'<path d="M3.5 10.8 12 3.8l8.5 7v9.4H14v-5.7h-4v5.7H3.5z"/>',calendar:'<rect x="3.5" y="5" width="17" height="15" rx="2.5"/><path d="M7 3v4M17 3v4M3.5 9h17M8 13h2M14 13h2M8 16.5h2M14 16.5h2"/>',pin:'<path d="M12 21s6-5.1 6-11a6 6 0 1 0-12 0c0 5.9 6 11 6 11Z"/><circle cx="12" cy="10" r="2.2"/>',docs:'<path d="M7 3.5h7l4 4v13H7z"/><path d="M14 3.5v4h4M10 12h5M10 15.5h5"/>',more:'<circle cx="5" cy="12" r="1.2" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.2" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="1.2" fill="currentColor" stroke="none"/>',map:'<path d="m4 5 5-2 6 2 5-2v16l-5 2-6-2-5 2zM9 3v16M15 5v16"/>',users:'<path d="M8.4 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM3 19c.4-3.2 2.2-5 5.4-5s5 1.8 5.4 5M16.6 10.5a2.5 2.5 0 1 0 0-5M15.4 14c3.2 0 5 1.5 5.6 4.5"/>',shield:'<path d="M12 3 19 6v5.1c0 4.4-2.6 7.7-7 9.9-4.4-2.2-7-5.5-7-9.9V6z"/><path d="m9 12 2 2 4-4"/>',back:'<path d="m14.5 6-6 6 6 6"/>',chevron:'<path d="m9 5 7 7-7 7"/>',refresh:'<path d="M20 7v5h-5M4 17v-5h5"/><path d="M6.1 8.5A7 7 0 0 1 18.7 7M17.9 15.5A7 7 0 0 1 5.3 17"/>',move:'<path d="M12 2v20M2 12h20M12 2l-2.5 2.5M12 2l2.5 2.5M12 22l-2.5-2.5M12 22l2.5-2.5M2 12l2.5-2.5M2 12l2.5 2.5M22 12l-2.5-2.5M22 12l-2.5 2.5"/>',file:'<path d="M7 3.5h7l4 4v13H7z"/><path d="M14 3.5v4h4"/>'};return `<svg ${common}>${p[name]||p.file}</svg>`}
function addStyles(){if($('#p170Styles'))return;const l=document.createElement('link');l.id='p170Styles';l.rel='stylesheet';l.href='premium-v170.css';document.head.appendChild(l)}
function greeting(){const h=new Date().getHours();return h<12?'Buenos días':h<20?'Buenas tardes':'Buenas noches'}
function navigateByButton(target){const b=$(`.nav-item[data-target="${target}"]`);if(b)b.click();else{$$('.view').forEach(v=>v.classList.toggle('active',v.dataset.view===target));window.scrollTo({top:0,behavior:'smooth'})}}
function upgradeHome(){const home=$('#inicio'),hero=$('#inicio .hero');if(!home||!hero)return;if(!hero.querySelector('.p170-hero-photo'))hero.innerHTML='<img class="p170-hero-photo" src="congregacion-home.jpg" alt="Congregación El Calafate"><div class="p170-hero-grid"></div><div class="p170-hero-wash"></div><div class="p170-hero-tech"></div><div class="p170-hero-top"><div class="p170-hero-brand">CONGREGACIÓN<br>EL CALAFATE</div><div class="p170-hero-coord">50.339° S<br>72.276° O</div></div>';if(!$('.p170-greeting',home)){const g=document.createElement('section');g.className='p170-greeting';g.innerHTML=`<p class="p170-kicker">CONGREGACIÓN EL CALAFATE</p><h1><span id="p170Greeting">${greeting()}</span><i></i></h1><p>Todo lo importante para hoy, en un solo lugar.</p><button type="button" class="p170-system-card" data-p170-system><span class="p170-system-dot"></span><strong>Sistema actualizado · Octubre 2026</strong><span>›</span></button>`;hero.insertAdjacentElement('afterend',g)}else $('#p170Greeting').textContent=greeting();const q=$('#quickGrid');if(q&&!q.querySelector('[data-p170-quick]')){const items=[['reuniones','Reuniones','Programas y calendario','calendar'],['territorios','Territorios','Mapa y progreso','pin'],['carritos','Carritos','Turnos y vacantes','users'],['recursos','Recursos','Documentos y formularios','docs']];q.innerHTML=items.map((x,i)=>`<button type="button" class="quick-card" data-p170-quick="${x[0]}"><span class="p170-q-no">0${i+1}</span><span class="quick-card-icon">${icon(x[3])}</span><span><strong>${x[1]}</strong><small>${x[2]}</small></span><span class="p170-q-arrow">${icon('chevron')}</span></button>`).join('')}const qs=q?.closest('.section-block');if(qs){const k=$('.section-kicker',qs),h=$('h2',qs);if(k&&k.textContent)k.textContent='';if(h&&h.textContent!=='Accesos rápidos')h.textContent='Accesos rápidos';const row=$('.section-title-row',qs);if(row&&!$('.p170-section-index',row)){const s=document.createElement('span');s.className='p170-section-index';s.textContent='// 04';row.appendChild(s)}}const news=$('.news-list',home);if(news){const sec=news.closest('.section-block'),k=$('.section-kicker',sec),h=$('h2',sec),pill=$('.pill',sec);if(k&&k.textContent)k.textContent='';if(h&&h.textContent!=='Actividad reciente')h.textContent='Actividad reciente';if(pill&&pill.textContent!=='// 04')pill.textContent='// 04'}const em=$('.emergency-card',home),ei=$('.emergency-icon',em);if(ei&&!ei.dataset.p170){ei.dataset.p170='1';ei.innerHTML=icon('shield')}}
function bindPremiumActions(){if(document.body.dataset.p170Bound)return;document.body.dataset.p170Bound='1';document.addEventListener('click',e=>{const q=e.target.closest?.('[data-p170-quick]');if(q){const a=q.dataset.p170Quick;if(a==='carritos')window.CongElCalafateCarritos?.open?.('carrito-anonima');else navigateByButton(a);return}if(e.target.closest?.('[data-p170-system]'))navigateByButton('recursos')})}
function activeView(){return $('.view.active')?.dataset?.view||'inicio'}function syncView(){document.body.dataset.p170View=activeView()}
function upgradeHeaders(){const cfg={reuniones:['Reuniones','Programas, calendario y organización','calendar'],territorios:['Territorios','Estado de predicación','pin'],recursos:['Recursos','Documentos y herramientas','docs'],mas:['Más','Otros accesos y ajustes','more']};Object.entries(cfg).forEach(([id,[t,s,ic]])=>{const h=$('.page-head',$('#'+id));if(!h)return;const h1=$('h1',h),p=$('p:not(.section-kicker)',h),i=$('.page-icon',h);if(h1&&h1.textContent!==t)h1.textContent=t;if(p&&p.textContent!==s)p.textContent=s;if(i&&!i.dataset.p170){i.dataset.p170='1';i.innerHTML=icon(ic)}})}
function upgradeNav(){const map={inicio:'home',reuniones:'calendar',territorios:'pin',recursos:'docs',mas:'more'};$$('.nav-item').forEach(b=>{const s=$('span',b),n=map[b.dataset.target];if(s&&n&&!s.dataset.p170){s.dataset.p170='1';s.innerHTML=icon(n)}})}
function upgradeResourceIcons(){$$('.resource-card').forEach(c=>{const i=$('.resource-icon',c);if(!i||i.dataset.p170)return;i.dataset.p170='1';const t=(c.textContent||'').toLowerCase();let n='file';if(/calend|reuni|programa/.test(t))n='calendar';else if(/territ|mapa/.test(t))n='map';else if(/carrito/.test(t))n='users';else if(/seguridad|evacu/.test(t))n='shield';else if(/form|solicitud|document|carta|informe|planilla/.test(t))n='docs';i.innerHTML=icon(n)})}
function addMeetingFeature(){const v=$('#reuniones'),list=$('#meetingResources');if(!v||!list||$('.p170-meeting-feature',v))return;const b=document.createElement('button');b.type='button';b.className='p170-meeting-feature';b.dataset.resource='calendario';b.innerHTML=`<span class="p170-meeting-date">${icon('calendar')}</span><span class="p170-meeting-copy"><small>Próxima reunión</small><strong>Calendario y programa actual</strong><span>Consultar horario, programa y próximos eventos</span></span><span class="p170-meeting-arrow">${icon('chevron')}</span>`;list.parentNode.insertBefore(b,list)}
function territoryMetric(n){const DATA=window.CongTerritoryOfficialData?.data||{},d=DATA[String(n)];if(!d)return{done:0,total:0,pct:0};const state=read(STATE_KEY,{}),done=state[String(n)]?.done||{};let keys=[];if(d.type==='tramos')keys=(d.items||[]).map(x=>x+'::territorio');else(d.items||[]).forEach(x=>['N','E','S','O'].forEach(s=>keys.push(x+'::'+s)));const c=keys.filter(k=>!!done[k]).length;return{done:c,total:keys.length,pct:keys.length?Math.round(c*100/keys.length):0}}
function territoryStats(){let complete=0,progress=0,pending=0;for(let n=1;n<=102;n++){const m=territoryMetric(n);if(m.total&&m.done>=m.total)complete++;else if(m.done>0)progress++;else pending++}return{complete,progress,pending,total:102}}
function addTerritoryOverview(){const v=$('#territorios'),head=$('.page-head',v);if(!v||!head)return;let o=$('.p170-territory-overview',v);if(!o){o=document.createElement('section');o.className='p170-territory-overview';head.insertAdjacentElement('afterend',o)}const s=territoryStats(),sig=`${s.total}|${s.complete}|${s.progress}|${s.pending}`;if(o.dataset.sig===sig)return;o.dataset.sig=sig;o.innerHTML=`<div class="p170-tstat primary"><strong>${s.total}</strong><span>territorios</span></div><div class="p170-tstat done"><strong>${s.complete}</strong><span>completados</span></div><div class="p170-tstat progress"><strong>${s.progress}</strong><span>en progreso</span></div><div class="p170-tstat"><strong>${s.pending}</strong><span>pendientes</span></div>`}
function territoryStatus(n){const m=territoryMetric(n);return m.total&&m.done>=m.total?'done':m.done>0?'progress':'pending'}
function installTerritoryFilters(){const wrap=$('.cec-territory-grid-wrap'),grid=$('#cecTerritoryGrid');if(!wrap||!grid)return;let f=$('.p170-territory-filter',wrap);if(!f){f=document.createElement('div');f.className='p170-territory-filter';f.dataset.filter='all';f.innerHTML='<button class="active" data-p170-tfilter="all">Todos</button><button data-p170-tfilter="pending">Pendientes</button><button data-p170-tfilter="progress">En progreso</button><button data-p170-tfilter="done">Completados</button>';$('.cec-territory-grid-head',wrap)?.insertAdjacentElement('afterend',f);f.addEventListener('click',e=>{const b=e.target.closest('[data-p170-tfilter]');if(!b)return;f.dataset.filter=b.dataset.p170Tfilter;$$('button',f).forEach(x=>x.classList.toggle('active',x===b));applyTerritoryFilter()})}applyTerritoryFilter()}
function applyTerritoryFilter(){const f=$('.p170-territory-filter'),grid=$('#cecTerritoryGrid');if(!f||!grid)return;const mode=f.dataset.filter||'all';$$('[data-n]',grid).forEach(b=>{b.hidden=mode!=='all'&&territoryStatus(b.dataset.n)!==mode})}
function enhanceMapTouch(){const vp=$('#cecV162Viewport'),head=$('.cec-v162-head'),svg=$('#cecV162Svg');if(!vp||!head)return;let pan=$('#p170MapPan');if(!pan){pan=document.createElement('button');pan.id='p170MapPan';pan.type='button';pan.className='p170-map-pan';pan.innerHTML=`${icon('move')}<span>Mover</span>`;head.insertBefore(pan,$('#cecV162Fit')||null);pan.onclick=()=>{vp.classList.toggle('p170-pan-mode');pan.classList.toggle('active',vp.classList.contains('p170-pan-mode'));if(!vp.classList.contains('p170-pan-mode'))$('#cecV162Fit')?.click()}}if(!vp.dataset.p170Touch){vp.dataset.p170Touch='1';$('#cecV162Plus')?.addEventListener('click',()=>{vp.classList.add('p170-pan-mode');pan?.classList.add('active')},true);$('#cecV162Minus')?.addEventListener('click',()=>{vp.classList.add('p170-pan-mode');pan?.classList.add('active')},true);$('#cecV162Fit')?.addEventListener('click',()=>{vp.classList.remove('p170-pan-mode');pan?.classList.remove('active')},true)}const drawing=!!svg?.classList.contains('drawing');vp.classList.toggle('p170-drawing',drawing);if(drawing){vp.classList.remove('p170-pan-mode');pan?.classList.remove('active')}}
function premiumCarritos(){const s=$('#cecCarritosScreen');if(!s)return;const t=$('.cec-c-head-title strong',s),sm=$('.cec-c-head-title small',s);if(t&&t.textContent!=='Carritos')t.textContent='Carritos';if(sm&&sm.textContent!=='TURNOS Y VACANTES')sm.textContent='TURNOS Y VACANTES';const back=$('.cec-c-back',s),ref=$('.cec-c-refresh',s);if(back&&!back.dataset.p170){back.dataset.p170='1';back.innerHTML=icon('back')}if(ref&&!ref.dataset.p170){ref.dataset.p170='1';ref.innerHTML=icon('refresh');ref.setAttribute('aria-label','Actualizar')}$$('.cec-v141-icon',s).forEach(i=>{if(!i.dataset.p170){i.dataset.p170='1';i.innerHTML=icon('users')}})}
function patchAbout(){const s=$('.about-card strong'),p=$('.about-card p'),st='Aplicación v1.7.0 · Visual System 2026',pt='Nueva identidad visual premium aplicada a Inicio, Reuniones, Territorios, mapas, Carritos, Recursos, modales y navegación. Se preservan las funciones y datos existentes.';if(s&&s.textContent!==st)s.textContent=st;if(p&&p.textContent!==pt)p.textContent=pt}
function patchDiagnostic(){const ta=$('#cecDiagText');if(ta)ta.value=String(ta.value||'').replace(/Versión módulo diagnóstico: .*$/m,'Versión módulo diagnóstico: 1.7.0 · Visual System 2026').replace(/Versión app: 1\.6\.4/g,'Versión app: 1.7.0').replace(/VersionCode: 22/g,'VersionCode: 24');const sum=$('#cecDiagSummary');if(sum){const chip=$$('.cec-diag-chip',sum).find(x=>/^App\s/.test(x.textContent||''));if(chip&&chip.textContent!=='App 1.7.0')chip.textContent='App 1.7.0'}}
function refresh(){addStyles();document.body.classList.add('p170');syncView();upgradeHome();upgradeHeaders();upgradeNav();upgradeResourceIcons();addMeetingFeature();addTerritoryOverview();installTerritoryFilters();enhanceMapTouch();premiumCarritos();patchAbout();if($('#cecDiagOverlay')?.classList.contains('open'))setTimeout(patchDiagnostic,120)}
addStyles();bindPremiumActions();if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',refresh,{once:true});else refresh();document.addEventListener('click',()=>setTimeout(refresh,90),true);document.addEventListener('change',()=>setTimeout(refresh,90),true);setInterval(()=>{const g=$('#p170Greeting');if(g&&g.textContent!==greeting())g.textContent=greeting();},60000);window.CongElCalafateVisualV170={version:VERSION,refresh,metric:territoryMetric};
})();
/* Congregación El Calafate · V1.7.1 behavior refinements */
(()=>{
'use strict';
const VERSION='1.7.2';
const STATE_KEY='cec_territory_official_v150';
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const read=(k,f)=>{try{return JSON.parse(localStorage.getItem(k)||'')||f}catch(_){return f}};
function iconPin(){return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.85" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 21s6-5.1 6-11a6 6 0 1 0-12 0c0 5.9 6 11 6 11Z"/><circle cx="12" cy="10" r="2.2"/></svg>'}
function sideKeys(d){const out=[];if(!d)return out;if(d.type==='tramos')(d.items||[]).forEach(x=>out.push(x+'::territorio'));else(d.items||[]).forEach(x=>['N','E','S','O'].forEach(s=>out.push(x+'::'+s)));return out}
function globalMetric(){const data=window.CongTerritoryOfficialData?.data||{},state=read(STATE_KEY,{});let total=0,done=0;for(let n=1;n<=102;n++){const keys=sideKeys(data[String(n)]);total+=keys.length;const d=state[String(n)]?.done||{};done+=keys.filter(k=>!!d[k]).length}return{total,done,pct:total?Math.round(done*100/total):0}}
function navigate(target){const b=$(`.nav-item[data-target="${target}"]`);if(b)b.click();else{$$('.view').forEach(v=>v.classList.toggle('active',v.dataset.view===target));window.scrollTo({top:0,behavior:'smooth'})}}
function addTerritoryShortcut(){const home=$('#inicio'),g=$('.p170-greeting',home);if(!home||!g)return;let b=$('#p171TerritoryShortcut');const m=globalMetric();if(!b){b=document.createElement('button');b.type='button';b.id='p171TerritoryShortcut';b.className='p171-territory-shortcut';const sys=$('.p170-system-card',g);if(sys)sys.insertAdjacentElement('afterend',b);else g.appendChild(b);b.addEventListener('click',()=>{navigate('territorios');setTimeout(()=>{const picker=$('.cec-territory-grid-wrap')||$('#t15Select')||$('#cecTerritoryGrid');picker?.scrollIntoView({behavior:'smooth',block:'start'})},260)})}
if(b.dataset.pct===String(m.pct))return;b.dataset.pct=String(m.pct);b.style.setProperty('--p171-pct',m.pct+'%');b.innerHTML=`<span class="p171-territory-icon">${iconPin()}</span><span class="p171-territory-copy"><small>Acceso directo</small><strong>Marcar territorio realizado</strong><span>Elegir territorio, marcar calles/tramos y actualizar el termómetro.</span></span><span class="p171-territory-meter"><strong>${m.pct}%</strong><i></i></span>`}
function improveMapScroll(){const vp=$('#cecV162Viewport');if(!vp)return;if(!$('#p171MapScrollHint')){const h=document.createElement('div');h.id='p171MapScrollHint';h.className='p171-map-scroll-hint';h.textContent='Deslice verticalmente para continuar la página · use Mover para desplazar el plano';vp.insertAdjacentElement('beforebegin',h)}const svg=$('#cecV162Svg');const drawing=!!svg?.classList.contains('drawing');vp.classList.toggle('p170-drawing',drawing);if(drawing)vp.classList.remove('p170-pan-mode')}
function refresh(){addTerritoryShortcut();improveMapScroll();const about=$('.about-card strong');if(about)about.textContent='Aplicación v1.7.2 · Visual System 2026';}
function observe(){refresh();document.addEventListener('click',()=>setTimeout(refresh,140),false);document.addEventListener('change',()=>setTimeout(refresh,140),false);setInterval(()=>{if(!document.hidden){addTerritoryShortcut();improveMapScroll()}},30000)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',observe,{once:true});else observe();
window.CongElCalafateVisualV171={version:VERSION,globalMetric,refresh};
})();



/* Congregación El Calafate · V1.7.2: mapa restaurado, ES-AR y calendario sin feriados */
(()=>{
'use strict';
const VERSION='1.7.2',$=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const calendarUrl='https://calendar.google.com/calendar/embed?src=congcalafate%40gmail.com&ctz=America%2FArgentina%2FRio_Gallegos&showTitle=0&showPrint=0&showTabs=0&showCalendars=0&showTz=0';
function calendarOnly(){
  try{
    const r=typeof resources!=='undefined'&&resources.find(x=>x.id==='calendario');
    if(r){r.url=calendarUrl;r.title='Calendario de la congregación';r.desc='Solo el calendario congregacional, sin los feriados automáticos de Google.';}
    if(typeof currentResource!=='undefined'&&currentResource&&currentResource.id==='calendario'){
      const a=$('#dialogOpen');if(a)a.href=calendarUrl;
      const h=$('#dialogTitle');if(h)h.textContent='Calendario de la congregación';
    }
  }catch(e){console.warn('Calendario V1.7.2:',e)}
}
function localize(){
  const screen=$('#cecCarritosScreen');
  if(screen){
    const walker=document.createTreeWalker(screen,NodeFilter.SHOW_TEXT);
    let n;while((n=walker.nextNode())){
      const t=n.nodeValue,next=t.replace(/\bvagas\b/g,'vacantes').replace(/\bVaga\b/g,'Vacante').replace(/\bHoje\b/g,'Hoy');
      if(t!==next)n.nodeValue=next;
    }
  }
  const meta=$('#cecPickerMeta');if(meta&&meta.textContent==='Vaga')meta.textContent='Vacante';
}
function ensureTerritories(){
  const page=$('#territorios'),head=$('.page-head',page),card=$('.territory-control-card',page);
  if(!page||!head||!card)return;
  card.style.setProperty('display','block','important');
  if(card.hasAttribute('hidden'))card.removeAttribute('hidden');
  if(!$('#cecV172Actions')){
    const actions=document.createElement('div');actions.id='cecV172Actions';actions.className='cec-v172-actions';
    actions.innerHTML='<button id="cecV172MapGo" type="button" class="cec-v172-action"><span class="v172-icon">⌖</span><span class="v172-copy"><strong>ABRIR MAPA PARA MARCAR</strong><small>Elegí un territorio y marcá los lados o tramos realizados</small></span><span class="v172-arrow">›</span></button><button id="cecV172ThermoGo" type="button" class="cec-v172-action secondary"><span class="v172-icon">▥</span><span class="v172-copy"><strong>Informe y termómetro</strong><small>Consultá el progreso de los 102 territorios</small></span><span class="v172-arrow">›</span></button>';
    ($('.p170-territory-overview',page)||head).insertAdjacentElement('afterend',actions);
  }
  const mapCard=$('.cec-map-card',card);
  if(mapCard&&!$('#cecV172GeneralMap')){
    const d=document.createElement('details');d.id='cecV172GeneralMap';d.className='cec-v172-map';
    d.innerHTML='<summary><span style="font-size:23px;color:#087cf0">▧</span><span><strong>Plano general oficial · 102 territorios</strong><small>Disponible sin conexión · tocá para desplegarlo</small></span><span style="margin-left:auto;color:#087cf0">⌄</span></summary><div class="v172-general-tools"><button type="button" data-v172-zoom="out">− Alejar</button><span id="cecV172Zoom">100%</span><button type="button" data-v172-zoom="in">+ Acercar</button></div><div class="v172-general-frame"><img id="cecV172GeneralImg" src="territory-map-2026.png" alt="Plano oficial de El Calafate con 102 territorios" loading="lazy"></div><p>Para marcar un lado o tramo, primero elegí el número en el selector de arriba. El plano individual te permite registrar lo realizado.</p>';
    mapCard.insertAdjacentElement('afterend',d);
  }
  const version=$('.about-card strong');if(version&&version.textContent!=='Aplicación v1.7.2 · Visual System 2026')version.textContent='Aplicación v1.7.2 · Visual System 2026';
}
function navigate(){const b=$('.nav-item[data-target="territorios"]');if(b)b.click();}
function openMap(){
  navigate();setTimeout(()=>{ensureTerritories();const target=$('.cec-t15-top')||$('#t15Select')||$('.territory-control-card');if(target){target.scrollIntoView({behavior:'smooth',block:'start'});target.classList.add('cec-v172-flash');setTimeout(()=>target.classList.remove('cec-v172-flash'),1250)}},300);
}
function progress(){navigate();setTimeout(()=>{const b=$('#cecV162OpenReport');if(b)b.click();else $('#cecV172Actions')?.scrollIntoView({block:'start',behavior:'smooth'})},300);}
let zoom=1;
function changeZoom(way){zoom=Math.min(4,Math.max(1,zoom+(way==='in'?.5:-.5)));const image=$('#cecV172GeneralImg');if(image)image.style.width=Math.round(zoom*100)+'%';const text=$('#cecV172Zoom');if(text)text.textContent=Math.round(zoom*100)+'%';}
document.addEventListener('click',e=>{
  const z=e.target.closest?.('[data-v172-zoom]');if(z){e.preventDefault();changeZoom(z.dataset.v172Zoom);return;}
  const home=e.target.closest?.('#p171TerritoryShortcut'),map=e.target.closest?.('#cecV172MapGo'),thermo=e.target.closest?.('#cecV172ThermoGo');
  if(home||map){e.preventDefault();e.stopImmediatePropagation();openMap();}
  else if(thermo){e.preventDefault();e.stopImmediatePropagation();progress();}
},true);
let queued=false;
function refresh(){calendarOnly();ensureTerritories();localize();}
function start(){refresh();document.addEventListener('click',()=>setTimeout(refresh,150),false);document.addEventListener('change',()=>setTimeout(refresh,150),false);}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
window.CongElCalafateVisualV172={version:VERSION,refresh,openMap,progress,calendarUrl};
})();
/* Congregación El Calafate · V1.7.3 · Estabilidad y diagnóstico de interacción
   Sin MutationObserver global; actualizaciones bajo demanda y señales nativas.
*/
(()=>{
'use strict';
const V='1.7.3';
const $=s=>document.querySelector(s);
let lastPulse=Date.now(),stallCount=0,maxDelay=0,touches=0,lastTouch=0,lastNav='',exceptions=[];
const recent=(x)=>{exceptions.push(String(x).slice(0,260));if(exceptions.length>10)exceptions.shift()};
window.addEventListener('error',e=>recent('ERROR '+(e.message||'')+' @ '+(e.filename||'')+':'+(e.lineno||'')));
window.addEventListener('unhandledrejection',e=>recent('PROMISE '+String(e.reason||'')));
document.addEventListener('pointerdown',()=>{touches++;lastTouch=Date.now()},{capture:true,passive:true});
function view(){return $('.view.active')?.id||'sin-pantalla'}
function sendPulse(){let now=Date.now(),delay=Math.max(0,now-lastPulse-5000);lastPulse=now;maxDelay=Math.max(maxDelay,delay);if(delay>4000)stallCount++;try{
  if(window.AndroidBridge&&typeof AndroidBridge.heartbeat==='function')AndroidBridge.heartbeat('pantalla='+view()+'; ralentizaciones='+stallCount+'; eventos_táctiles='+touches+'; última_navegación='+lastNav);
}catch(e){recent('native heartbeat: '+e.message)}}
function info(){
const age=lastTouch?Math.floor((Date.now()-lastTouch)/1000)+' s':'sin toques';
return ['','--- INTERACCIÓN / ESTABILIDAD (V1.7.3) ---','Último toque: '+age,'Toques registrados: '+touches,'Demoras de UI detectadas (>4 s): '+stallCount,'Demora máxima: '+Math.round(maxDelay)+' ms','Última navegación: '+(lastNav||'ninguna'),'Pantalla visible: '+view(),'Modo dibujo: '+!!$('#cecV162Svg.drawing'),'Mapa ampliado: '+!!$('#cecV162Viewport.p170-pan-mode'),'Errores capturados: '+exceptions.length,...exceptions.map(x=>'- '+x),'Nota: 8/8 comprobaciones correctas NO garantizan respuesta táctil.'].join('\n');
}
function extendReport(){
 const t=$('#cecDiagText');if(!t)return;
 t.value=t.value.replace(/\n--- INTERACCIÓN \/ ESTABILIDAD \(V1\.7\.3\) ---[\s\S]*$/,'')+info();
}
document.addEventListener('click',e=>{
 if(e.target.closest?.('#cecDiagCopy,#cecDiagDownload,#cecDiagRefresh'))extendReport();
 const nav=e.target.closest?.('.nav-item');
 if(nav)lastNav=nav.dataset.target||'indefinida';
},{capture:true});
function sync(){const title=$('.about-card strong');if(title&&title.textContent!=='Aplicación v1.7.5-work · territorios y sistema')title.textContent='Aplicación v1.7.5-work · territorios y sistema';}
function start(){
 sync();sendPulse();
 setInterval(()=>{if(!document.hidden)sendPulse()},5000);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden){lastPulse=Date.now();sendPulse()}});
 document.addEventListener('click',()=>setTimeout(sync,180));
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
window.CongElCalafateRescateV173={version:V,info,extendReport};
})();/* Cong El Calafate · V1.7.5-work · Vinculación mapa ↔ lista verificable */
(()=>{
'use strict';
const STATE='cec_territory_official_v150',DRAW='cec_territory_individual_drawings_v162';
const $=s=>document.querySelector(s);
const data=window.CongTerritoryOfficialData?.data||{};
const norm=s=>String(s||'').toLowerCase().replace(/\s+/g,'');
const read=k=>{try{return JSON.parse(localStorage.getItem(k)||'{}')||{}}catch(_){return {}}};
const save=(k,v)=>localStorage.setItem(k,JSON.stringify(v));
const api={active:true,suppressMapReload:false,version:'1.7.5-work',autolink:0,manual:0,uncertain:0};
window.CongElCalafateV174=api;
const BASE_1={
 'Mz 106':[67.1,29.65,84.6,35.95],
 'Mz 105':[67.25,38.2,84.8,45.7],
 'Mz 104':[67.25,48.1,84.8,55.5],
 'Mz 109':[67.25,58.45,84.8,64.8],
 'Mz 110':[67.2,67.2,85.1,73.55],
 'Mz 110a':[67.25,74.9,85.1,80.0]
}; // Coordenadas porcentuales trazadas sobre Territorio 1.pdf original
let pending=false,lastId='';
function valid(n,k){const d=data[String(n)],item=String(k).split('::')[0],side=String(k).split('::')[1];
 return !!(d&&(d.items||[]).includes(item)&&(d.type==='tramos'?side==='territorio':['N','E','S','O'].includes(side)))}
function drawInfo(n){const all=read(DRAW),arr=Array.isArray(all[n])?all[n]:[];return {all,arr,stroke:arr[arr.length-1]}}
function infer(n,st){
 if(n!=='1'||!Array.isArray(st.points)||st.points.length<4)return [];
 let boxes=[];
 for(const [item,[x1,y1,x2,y2]] of Object.entries(BASE_1)){
   const hits={N:[],E:[],S:[],O:[]},pts=st.points;
   pts.forEach((p,i)=>{
     const x=+p.x,y=+p.y;
     if(x<x1-5.5||x>x2+5.5||y<y1-5.5||y>y2+5.5)return;
     const ds={N:Math.abs(y-y1),S:Math.abs(y-y2),O:Math.abs(x-x1),E:Math.abs(x-x2)};
     const sorted=Object.keys(ds).sort((a,b)=>ds[a]-ds[b]);const side=sorted[0];
     if(ds[side]<4.1)hits[side].push(p);
   });
   const selected=[];
   for(const [side,pts] of Object.entries(hits)){
     if(pts.length<Math.max(3,Math.floor(st.points.length*.055)))continue;
     const spread=side==='N'||side==='S'
       ?Math.max(...pts.map(p=>p.x))-Math.min(...pts.map(p=>p.x))
       :Math.max(...pts.map(p=>p.y))-Math.min(...pts.map(p=>p.y));
     if(spread>=Math.max(2.1,(side==='N'||side==='S'?x2-x1:y2-y1)*.22))selected.push(item+'::'+side);
   }
   const total=selected.reduce((acc,k)=>acc+hits[k.split('::')[1]].length,0);
   if(selected.length)boxes.push({item,keys:selected,hits:total});
 }
 boxes.sort((a,b)=>b.hits-a.hits);
 if(!boxes.length)return [];
 if(boxes[1]&&boxes[1].hits>boxes[0].hits*.68)return []; // no inferir dos manzanas en calles compartidas
 return boxes[0].keys.filter(k=>valid(n,k));
}
function refresh(n){
 try{
  const original=window.CongElCalafateTerritoriosV150;
  api.suppressMapReload=true;
  original?.select?.(String(n),false);
  api.suppressMapReload=false;
  const d=data[n],t=read(STATE)[n]?.done||{},keys=d?.type==='tramos'?(d.items||[]).map(x=>x+'::territorio'):(d?.items||[]).flatMap(x=>['N','E','S','O'].map(s=>x+'::'+s));
  const done=keys.filter(k=>t[k]).length,total=keys.length,pct=total?Math.round(100*done/total):0;
  const set=(id,value)=>{const el=$(id);if(el)el.textContent=value};
  set('#cecV162ProgressText',done+' de '+total+' lados/tramos');set('#cecV162Pct',pct+'%');
  const p=$('#cecV162ProgressBar');if(p)p.style.width=pct+'%';
  window.CongElCalafateTerritoriosReportV162?.refresh?.();
  document.dispatchEvent(new CustomEvent('cec:territory-progress',{detail:{n,done,total,pct}}));
 }finally{api.suppressMapReload=false}
}
function toast(message){
 let el=$('#cecV174Toast');if(!el){el=document.createElement('div');el.id='cecV174Toast';el.style.cssText='position:fixed;left:12px;right:12px;bottom:calc(83px + env(safe-area-inset-bottom));border-radius:15px;padding:12px 16px;background:#073d4b;color:white;box-shadow:0 6px 22px #0003;font:700 12px system-ui;z-index:99998;text-align:center;pointer-events:none';document.body.appendChild(el)}
 el.textContent=message;el.hidden=false;clearTimeout(el._t);el._t=setTimeout(()=>el.hidden=true,3200)
}
function reconcile(n,st,keys){
 if(!st||!keys?.length)return false;
 keys=Array.from(new Set(keys.filter(k=>valid(n,k))));
 if(!keys.length)return false;
 const {all,arr}=drawInfo(n),record=arr.find(x=>String(x.id)===String(st.id));if(!record)return false;
 const state=read(STATE),territory=state[n]||(state[n]={});
 const done=territory.done||(territory.done={});const labels=territory.labels||(territory.labels={});
 const added=[],linked=new Set(record.keys||[]);
 keys.forEach(k=>{linked.add(k);if(!done[k]){done[k]=true;added.push(k)};if(!labels[k])labels[k]='Marcado en el plano individual'});
 record.keys=[...linked];record.newlyMarked=[...new Set([...(record.newlyMarked||[]),...added])];
 territory.updatedAt=new Date().toISOString();save(STATE,state);save(DRAW,all);
 $('#cecV162Resolve.open .cec-v162-close')?.click();
 window.CongElCalafateTerritoriosV164?.clearPending?.(false);
 const pending=window.CongElCalafateV174Pending;
 if(pending&&pending.n===n)window.CongElCalafateV174Pending=null;
 refresh(n);
 const count=record.keys.length;toast((added.length?'Marcado en la lista: ':'Ya registrado: ')+count+' lado'+(count===1?'':'s')+' / tramo'+(count===1?'':'s'));
 api.autolink++;
 return true
}
function handleStroke(){
 if(pending)return;pending=true;
 setTimeout(()=>{
  try{
   const n=String($('#t15Select')?.value||'1'),{stroke}=drawInfo(n);
   if(!stroke)return;
   const code=n+':'+stroke.id;
   if(lastId===code)return;lastId=code;
   if(stroke.keys?.length){refresh(n);return;}
   const current=window.CongElCalafateV174Pending;
   if(current&&current.n===n&&Date.now()-current.at<110000&&valid(n,current.k)){
    reconcile(n,stroke,[current.k]);return;
   }
   const keys=infer(n,stroke);
   if(keys.length){reconcile(n,stroke,keys);return}
   api.uncertain++;
   // Mantener el cuadro oficial para seleccionar una manzana y su lado sin adivinar.
   // Resolver oficial abierto por el trazado: no adivinar calles ni lados sin geometría.
   toast('Elegí el lado correcto en la lista de confirmación');
  }catch(e){console.warn('V174 mapa/lista:',e);toast('No se pudo identificar. Seleccioná el tramo en la lista.')}
  finally{pending=false}
 },260)
}
function syncConfirmed(){
 const n=String($('#t15Select')?.value||'1'),{arr}=drawInfo(n),state=read(STATE);
 // Recuperar trazos antiguos no asociados, solo con coincidencia geométrica segura.
 if(!api.recovered)api.recovered={};
 if(!api.recovered[n]){api.recovered[n]=true;let linked=0;for(const st of arr){if(st.points?.length&&!(st.keys||[]).length){const keys=infer(n,st);if(keys.length&&reconcile(n,st,keys))linked++}}if(linked)console.info('V174: recuperados '+linked+' trazos previos del Territorio '+n);}
 let changed=false,done=state[n]?.done||{};
 arr.forEach(st=>(st.keys||[]).forEach(k=>{if(valid(n,k)&&!done[k]){done[k]=true;changed=true}}));
 if(changed){state[n]=state[n]||{};state[n].done=done;save(STATE,state);refresh(n)}
}
function start(){
 document.addEventListener('pointerup',e=>{if(e.target?.closest?.('#cecV162Svg'))handleStroke()},true);
 document.addEventListener('click',e=>{const id=e.target?.id;
   if(id==='cecV162Apply'){api.manual++;setTimeout(()=>{syncConfirmed();refresh(String($('#t15Select')?.value||'1'))},130);}
 },true);
 document.addEventListener('change',e=>{if(e.target?.id==='t15Select')setTimeout(syncConfirmed,500)},true);
 setTimeout(syncConfirmed,1300);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();