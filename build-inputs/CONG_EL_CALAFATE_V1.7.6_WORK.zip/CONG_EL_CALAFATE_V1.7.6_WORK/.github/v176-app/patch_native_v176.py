from pathlib import Path
import re

gradle=Path("cong_el_calafate_android/app/build.gradle")
s=gradle.read_text(encoding="utf-8")
s=re.sub(r"versionCode\s+\d+", "versionCode 30", s, count=1)
s=re.sub(r"versionName\s+['\"][^'\"]+['\"]", "versionName '1.7.6-work'", s, count=1)
gradle.write_text(s, encoding="utf-8")

java=Path("cong_el_calafate_android/app/src/main/java/app/congregacion/elcalafate/MainActivity.java")
s=java.read_text(encoding="utf-8")
s=s.replace("Versión: 1.7.5-work · 29", "Versión: 1.7.6-work · 30")
s=s.replace("1.7.5-work\\t29\\t", "1.7.6-work\\t30\\t")
s=s.replace("1.7.5-work\t29\t", "1.7.6-work\t30\t")
s=s.replace("CongElCalafate/1.7.5-work Android", "CongElCalafate/1.7.6-work Android")
java.write_text(s, encoding="utf-8")
print("V1.7.6-work: versionCode, versionName and native diagnostics updated")
